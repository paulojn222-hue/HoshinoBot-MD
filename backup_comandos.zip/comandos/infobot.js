const config = require("../config.js");
const os = require("os");
const fs = require("fs");
const path = require("path");
const axios = require("axios");

const tempoInicial = Date.now();
const CAMINHO_ALUGUEIS = path.join(__dirname, "..", "dados", "alugueis.json");

// ⏰ Formato EXATO: 0d 0h 0m 0s
function formatarTempo(ms) {
  if (ms <= 0) return "0d 0h 0m 0s";
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  const d = Math.floor(h / 24);
  return `${d}d ${h % 24}h ${m % 60}m ${s % 60}s`;
}

function carregarAlugueis() {
  if (!fs.existsSync(CAMINHO_ALUGUEIS)) return {};
  try { return JSON.parse(fs.readFileSync(CAMINHO_ALUGUEIS, "utf-8")); }
  catch { return {}; }
}

module.exports = {
  nome: "infobot",
  comandos: {
    infobot: async (sock, msg, args, dados) => {
      const idChat = dados.idChat;
      
      // ⚡ Ping
      const inicio = Date.now();
      const tempMsg = await sock.sendMessage(idChat, { text: "⏱️" });
      const ping = Date.now() - inicio;
      await sock.sendMessage(idChat, { delete: tempMsg.key });
      
      // 💾 RAM
      const memoria = (process.memoryUsage().rss / 1024 / 1024).toFixed(1);
      
      // 📸 Foto do perfil do bot
      let fotoBuffer = null;
      try {
        const urlFoto = await sock.profilePictureUrl(sock.user.id, "image");
        if (urlFoto) {
          const res = await axios.get(urlFoto, { responseType: "arraybuffer", timeout: 10000 });
          fotoBuffer = Buffer.from(res.data);
        }
      } catch (erro) {
        console.log("⚠️ Foto do bot:", erro.message);
      }
      
      // 👑 Dados dono
      const nomeDono = config.donoNome || "Moon";
      const numeroDono = config.numeroDonoVisivel || config.numeroDono || "—";
      const numeroDonoLimpo = String(config.numeroDono).replace(/\D/g, "");
      
      // 🕸️ Status do Aluguel — formato 0d 0h 0m 0s
      let infoAluguel = "";
      if (idChat.includes("@g.us")) {
        const alugueis = carregarAlugueis();
        const aluguelGrupo = alugueis[idChat];
        
        if (aluguelGrupo) {
          const restante = aluguelGrupo.fim - Date.now();
          const tempoDisponivel = formatarTempo(Math.max(0, restante));
          const status = restante > 0 ? "✅ ATIVO" : "⚠️ VENCIDO";
          
          infoAluguel = `
🕸️ *ALUGUEL DO GRUPO*
├─ Status: ${status}
├─ ⏳ Tempo disponível: ${tempoDisponivel}
└─ 📅 Válido até: ${new Date(aluguelGrupo.fim).toLocaleString("pt-BR")}
`;
        } else {
          infoAluguel = `
🕸️ *ALUGUEL DO GRUPO*
└─ ⏳ Tempo disponível: 0d 0h 0m 0s
`;
        }
      } else {
        infoAluguel = `
🕸️ *ALUGUEL*
└─ ℹ️ Use em um grupo para ver o tempo
`;
      }
      
      const legenda = `
🤖 *INFORMAÇÕES DO BOT* 🕸

1️⃣ *Nome:* ${config.nomeBot || "Bot-MD"}
2️⃣ *⚡ Velocidade:* ${ping}ms
3️⃣ *⏰ Tempo Online:* ${formatarTempo(Date.now() - tempoInicial)}
4️⃣ *👑 Dono:* ${nomeDono}
5️⃣ *📱 Número:* ${numeroDono}
6️⃣ *🔤 Prefixo:* ${config.prefixo || "!"}
7️⃣ *💾 RAM:* ${memoria} MB
8️⃣ *🖥️ Sistema:* ${os.platform()}
9️⃣ *📦 Node:* ${process.version}
🔟 *🎯 Status:* 🟢 Online

${infoAluguel}
`.trim();
      
      // 📤 Envia com foto ou sem
      if (fotoBuffer) {
        return sock.sendMessage(idChat, {
          image: fotoBuffer,
          caption: legenda
        });
      }
      
      return sock.sendMessage(idChat, { text: legenda });
    }
  }
};

