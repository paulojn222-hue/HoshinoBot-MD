const config = require("../config.js");
const fs = require("fs");
const path = require("path");
const https = require("https");
const axios = require("axios");

const PREFIXO = config.prefixo || "!";
const NOME_BOT = config.nomeBot || "MoonBot-MD";
const DONO = config.dono || "5581995647053@s.whatsapp.net";

// 📂 Caminhos dos dados
const CAMINHO_ESTATS = path.join(__dirname, "..", "dados", "estatisticas_usuarios.json");
const CAMINHO_AVALIACOES = path.join(__dirname, "..", "dados", "avaliacoes.json");

// 📂 Garante pastas/arquivos
if (!fs.existsSync(path.dirname(CAMINHO_ESTATS))) {
  fs.mkdirSync(path.dirname(CAMINHO_ESTATS), { recursive: true });
}
if (!fs.existsSync(CAMINHO_ESTATS)) fs.writeFileSync(CAMINHO_ESTATS, JSON.stringify({}));
if (!fs.existsSync(CAMINHO_AVALIACOES)) fs.writeFileSync(CAMINHO_AVALIACOES, JSON.stringify([]));

// 📖 Funções de carregar/salvar
function carregarEstats() {
  try { return JSON.parse(fs.readFileSync(CAMINHO_ESTATS, "utf-8")); }
  catch { return {}; }
}
function salvarEstats(dados) {
  fs.writeFileSync(CAMINHO_ESTATS, JSON.stringify(dados, null, 2));
}

function carregarAvaliacoes() {
  try { return JSON.parse(fs.readFileSync(CAMINHO_AVALIACOES, "utf-8")); }
  catch { return []; }
}
function salvarAvaliacoes(dados) {
  fs.writeFileSync(CAMINHO_AVALIACOES, JSON.stringify(dados, null, 2));
}

// 🔤 Formata usuário
function formatarUsuario(jid) {
  if (!jid) return "Desconhecido";
  return jid.split("@")[0].split(":")[0];
}

// 📊 Atualiza estatísticas do usuário
function atualizarEstatisticas(remetente, msg) {
  const estats = carregarEstats();
  if (!estats[remetente]) {
    estats[remetente] = {
      totalMensagens: 0,
      textos: 0,
      fotos: 0,
      videos: 0,
      figurinhas: 0,
      audios: 0,
      documentos: 0,
      ultimaMensagem: Date.now()
    };
  }

  const u = estats[remetente];
  u.totalMensagens++;
  u.ultimaMensagem = Date.now();

  if (msg.message?.imageMessage) u.fotos++;
  else if (msg.message?.videoMessage) u.videos++;
  else if (msg.message?.stickerMessage) u.figurinhas++;
  else if (msg.message?.audioMessage || msg.message?.ptt) u.audios++;
  else if (msg.message?.documentMessage) u.documentos++;
  else u.textos++;

  salvarEstats(estats);
}

// 💬 Lista de cantadas
const CANTADAS = [
  "Você acredita em amor à primeira vista, ou eu tenho que passar por aqui de novo? 😍",
  "Seu nome é Wi-Fi? Porque eu sinto uma conexão forte aqui! 📶❤️",
  "Você não é Google, mas tem tudo o que eu procuro! 🔍💕",
  "Deve ser doloroso cair do céu, né? Porque você é um anjo! 👼✨",
  "Se a beleza fosse crime, você já estava cumprindo pena perpétua! 😈❤️",
  "Você tem um mapa? Porque eu me perdi nos seus olhos! 🗺️👀",
  "Eu não sou fotógrafo, mas consigo facilmente imaginar nós dois juntos! 📸💕",
  "Seu pai é padeiro? Porque você é um pãozinho! 🍞😍",
  "Você tem um lápis? Porque eu quero apagar o seu passado e escrever o nosso futuro! ✏️📖",
  "Deve estar cansado(a), porque você passou o dia todo na minha cabeça! 😴💭❤️",
  "Se você fosse uma fruta, seria uma uva-passa... porque é a mais gostosa! 🍇😋",
  "Eu não sou religioso, mas quando te vi, acreditei em anjos! 🙏👼",
  "Você sabe qual é o meu lugar preferido no mundo? O seu abraço! 🤗❤️",
  "Se beijar fosse crime, eu já estava na lista dos mais procurados por você! 😘🚔"
];

// 🧠 Lista de fatos aleatórios
const FATOS = [
  "🧠 O cérebro humano usa cerca de 20% da energia total do corpo.",
  "🐙 Os polvos têm 3 corações e sangue azul!",
  "🌙 A Lua está se afastando da Terra a uma velocidade de 3,8 cm por ano.",
  "🦩 Os flamingos são naturalmente brancos — ficam rosas por causa da comida que comem.",
  "🌍 A Terra não é perfeitamente redonda — ela é achatada nos polos.",
  "🐝 Uma abelha produz cerca de 1/12 de colher de chá de mel em toda a sua vida.",
  "💀 O corpo humano tem 206 ossos quando adulto, mas nasce com cerca de 270!",
  "🌊 O oceano contém cerca de 20 milhões de toneladas de ouro dissolvido.",
  "🐢 As tartarugas podem respirar pelo traseiro (em algumas espécies).",
  "⚡ Um raio é 5 vezes mais quente que a superfície do Sol.",
  "🌱 As plantas também podem 'sentir' dor e se comunicar entre si.",
  "🌌 Existem mais estrelas no universo do que grãos de areia em todas as praias da Terra.",
  "🐧 Os pinguins se propõem de casamento dando uma pedrinha para a parceira.",
  "💓 O coração de um beija-flor bate cerca de 1.200 vezes por minuto.",
  "🏔️ O Monte Everest cresce cerca de 4 mm por ano devido ao movimento das placas tectônicas."
];

// 📊 Cotações de moedas
const COTACOES_MOEDAS = {
  "USD": { nome: "Dólar Americano", simbolo: "$", valorBRL: 5.45, bandeira: "🇺🇸" },
  "EUR": { nome: "Euro", simbolo: "€", valorBRL: 5.92, bandeira: "🇪🇺" },
  "GBP": { nome: "Libra Esterlina", simbolo: "£", valorBRL: 6.89, bandeira: "🇬🇧" },
  "ARS": { nome: "Peso Argentino", simbolo: "$", valorBRL: 0.006, bandeira: "🇦🇷" },
  "PYG": { nome: "Guarani Paraguaio", simbolo: "₲", valorBRL: 0.00075, bandeira: "🇵🇾" },
  "UYU": { nome: "Peso Uruguaio", simbolo: "$", valorBRL: 0.13, bandeira: "🇺🇾" },
  "JPY": { nome: "Iene Japonês", simbolo: "¥", valorBRL: 0.036, bandeira: "🇯🇵" },
  "BTC": { nome: "Bitcoin", simbolo: "₿", valorBRL: 325000, bandeira: "🪙" }
};

// 🔍 Verifica se é grupo
function ehGrupo(idChat) {
  return idChat.includes("@g.us");
}

// 🔍 Verifica se é admin
async function ehAdmin(sock, idGrupo, idUsuario) {
  if (!ehGrupo(idGrupo)) return false;
  try {
    const meta = await sock.groupMetadata(idGrupo);
    return meta.participants.some(p => p.id === idUsuario && p.admin);
  } catch { return false; }
}

module.exports = {
  atualizarEstatisticas,

  comandos: {
    // ==========================================
    // 👤 !perfil — Informações da pessoa
    // ==========================================
    perfil: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const mencionados = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
      const alvo = mencionados[0] || remetente;

      const estats = carregarEstats();
      const dados = estats[alvo] || {
        totalMensagens: 0, textos: 0, fotos: 0, videos: 0,
        figurinhas: 0, audios: 0, documentos: 0, ultimaMensagem: null
      };

      const ehAdm = ehGrupo(idChat) ? await ehAdmin(sock, idChat, alvo) : false;
      const ultima = dados.ultimaMensagem ? new Date(dados.ultimaMensagem).toLocaleString("pt-BR") : "Nunca";
      const nome = formatarUsuario(alvo);

      // 🎲 Função para gerar porcentagem aleatória
      const pct = () => Math.floor(Math.random() * 101);

      const texto = `╭━━━━━━━━━━━━━━━━━━━━━━━╮
┃ ✨ 𝐏𝐄𝐑𝐅𝐈𝐋 𝐈𝐍𝐓𝐄𝐑𝐄𝐒𝐒𝐀𝐍𝐓𝐄 ✨
╰━━━━━━━━━━━━━━━━━━━━━━━╯

👤 @${nome}
${ehAdm ? "👑 𝐀𝐝𝐦𝐢𝐧𝐢𝐬𝐭𝐫𝐚𝐝𝐨𝐫(𝐚) 𝐝𝐨 𝐠𝐫𝐮𝐩𝐨" : "👤 𝐌𝐞𝐦𝐛𝐫𝐨 𝐝𝐨 𝐠𝐫𝐮𝐩𝐨"}

╭━━━━━━━━━━━━━━━━━━━━╮
┃ 📊 𝐄𝐒𝐓𝐀𝐓𝐈́𝐒𝐓𝐈𝐂𝐀𝐒
┣━━━━━━━━━━━━━━━━━━━━┫
┃ 💬 𝐓𝐢𝐚𝐥𝐨𝐠𝐨𝐬: ${dados.totalMensagens}
┃ 📝 𝐓𝐞𝐱𝐭𝐨𝐬: ${dados.textos}
┃ 🖼️  𝐅𝐨𝐭𝐨𝐬: ${dados.fotos}
┃ 🎥  𝐕𝐢́𝐝𝐞𝐨𝐬: ${dados.videos}
┃ 🎨  𝐅𝐢𝐠𝐮𝐫𝐢𝐧𝐡𝐚𝐬: ${dados.figurinhas}
┃ 🎤  𝐀́𝐮𝐝𝐢𝐨𝐬: ${dados.audios}
┃ 📄  𝐃𝐨𝐜𝐮𝐦𝐞𝐧𝐭𝐨𝐬: ${dados.documentos}
┃ ⏰  𝐔́𝐥𝐭𝐢𝐦𝐚 𝐦𝐞𝐧𝐬𝐬𝐚𝐠𝐞𝐦:
┃    ${ultima}
╰━━━━━━━━━━━━━━━━━━━━╯

╭━━━━━━━━━━━━━━━━━━━━╮
┃ ✨ 𝐐𝐔𝐀𝐋𝐈𝐃𝐀𝐃𝐄𝐒
┣━━━━━━━━━━━━━━━━━━━━┫
┃ 😄 Engraçado(a):     ${pct()}%
┃ 🧠 Inteligente(a):   ${pct()}%
┃ 💪 Confiante:        ${pct()}%
┃ ✏️ Criativo(a):      ${pct()}%
┃ 💬 Comunicativo(a):  ${pct()}%
┃ 🎯 Determinado(a):   ${pct()}%
┃ ⚔️ Corajoso(a):      ${pct()}%
┃ 💎 Sincero(a):       ${pct()}%
┃ 🎩 Educado(a):       ${pct()}%
╰━━━━━━━━━━━━━━━━━━━━╯`;

      try {
        const fotoPerfil = await sock.profilePictureUrl(alvo, "image");
        await sock.sendMessage(idChat, {
          image: { url: fotoPerfil },
          caption: texto,
          mentions: [alvo]
        }, { quoted: msg });
      } catch {
        await sock.sendMessage(idChat, {
          text: texto + "\n\n📷 (Sem foto de perfil visível)",
          mentions: [alvo]
        }, { quoted: msg });
      }
    },

    // ==========================================
    // 🔤 !traduzir — Traduzir texto ✅ Formato correto
    // ==========================================
    traduzir: async (sock, msg, args, dados) => {
      const idChat = dados?.idChat || msg.key.remoteJid;
      const citada = msg.message?.extendedTextMessage?.contextInfo;
      const textoCompleto = args.join(" ").trim() ||
        (citada?.quotedMessage?.conversation) ||
        (citada?.quotedMessage?.extendedTextMessage?.text) || "";

      if (!textoCompleto) {
        return sock.sendMessage(idChat, {
          text: `┏━━━━━⪩🌏⪨━━━━━┓
┃ 🔤 𝐓𝐑𝐀𝐃𝐔𝐙𝐈𝐑
┣━━━━━━━━━━━━━━┫
┃ ⚙️ Uso: ${PREFIXO}traduzir <destino> <texto>
┃ ⚙️ Ou: ${PREFIXO}traduzir <origem> <destino> <texto>
┃
┃ 📌 Exemplos:
┃ ${PREFIXO}traduzir pt hello
┃ ${PREFIXO}traduzir en bom dia
┃ ${PREFIXO}traduzir es pt hola
┗━━━━━━━━━━━━━━━━━━━━━━━━┛`,
          quoted: msg
        });
      }

      const partes = textoCompleto.split(" ");
      let idiomaOrigem = "auto";
      let idiomaDestino = "pt";
      let frase = "";

      if (partes.length >= 2 && partes[0].length === 2) {
        if (partes.length >= 3 && partes[1].length === 2) {
          idiomaOrigem = partes[0].toLowerCase();
          idiomaDestino = partes[1].toLowerCase();
          frase = partes.slice(2).join(" ");
        } else {
          idiomaDestino = partes[0].toLowerCase();
          frase = partes.slice(1).join(" ");
        }
      } else {
        frase = textoCompleto;
      }

      if (!frase) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Digite o texto para traduzir!\nExemplo: ${PREFIXO}traduzir pt hello`,
          quoted: msg
        });
      }

      try {
        const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${idiomaOrigem}&tl=${idiomaDestino}&dt=t&q=${encodeURIComponent(frase)}`;

        const { data: res } = await axios.get(url, { timeout: 10000 });

        if (!res || !res[0]) throw new Error("Sem resposta");
        const traducao = res[0].map(item => item[0]).join("");
        const idiomaDetectado = (res[2] || idiomaOrigem).toUpperCase();

        await sock.sendMessage(idChat, {
          text: `┏━━━━━⪩🌍⪨━━━━━┓
┃ 🔤 𝐓𝐑𝐀𝐃𝐔𝐂̧𝐀̃𝐎
┣━━━━━━━━━━━━━━┫
┃ 📝 Original: ${frase}
┃ 🌍 Idioma: ${idiomaDetectado} ➡️ ${idiomaDestino.toUpperCase()}
┃ ✅ Tradução: ${traducao}
┗━━━━━━━━━━━━━━━━━━━━━━━━┛`,
          quoted: msg
        });
      } catch (erro) {
        console.log("❌ Erro tradução:", erro.message);
        return sock.sendMessage(idChat, {
          text: `❌ Erro ao traduzir!\n\n📌 Verifique:\n• pt=Português | en=Inglês | es=Espanhol | fr=Francês\n• Conexão com a internet`,
          quoted: msg
        });
      }
    },

    // ==========================================
    // 😍 !cantadas — Cantada aleatória
    // ==========================================
    cantadas: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const mencionados = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
      const cantada = CANTADAS[Math.floor(Math.random() * CANTADAS.length)];

      let texto = `😍 *CANTADA DO DIA* 😍\n\n${cantada}`;
      if (mencionados.length > 0) {
        texto = `😍 *CANTADA PARA @${formatarUsuario(mencionados[0])}* 😍\n\n${cantada}`;
      }

      await sock.sendMessage(idChat, {
        text: texto,
        mentions: mencionados
      }, { quoted: msg });
    },

    // ==========================================
    // 🧠 !fatos — Fato aleatório
    // ==========================================
    fatos: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const fato = FATOS[Math.floor(Math.random() * FATOS.length)];

      await sock.sendMessage(idChat, {
        text: `🧠 *VOCÊ SABIA?* 🧠\n\n${fato}\n\n💡 Fato aleatório de hoje!`
      }, { quoted: msg });
    },

    // ==========================================
    // 💰 !moedas — Cotação das moedas
    // ==========================================
    moedas: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;

      let texto = `💰 *COTAÇÃO DAS MOEDAS* 💰\n📅 Valores aproximados em Reais (BRL)\n\n`;

      Object.entries(COTACOES_MOEDAS).forEach(([codigo, info]) => {
        const valorFormatado = info.valorBRL >= 1
          ? info.valorBRL.toFixed(2)
          : info.valorBRL.toFixed(6);
        texto += `${info.bandeira} ${info.nome} (${codigo})\n   1 ${codigo} = R$ ${valorFormatado}\n\n`;
      });

      texto += `⚠️ *Observação:* Estes valores são aproximados e podem não estar em tempo real.`;

      await sock.sendMessage(idChat, { text: texto }, { quoted: msg });
    },

    // ==========================================
    // 🔤 !contar_letras — Conta letras do texto
    // ==========================================
    contar_letras: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const texto = args.join(" ").trim();
      const citada = msg.message?.extendedTextMessage?.contextInfo;

      const textoParaContar = texto ||
        (citada?.quotedMessage?.conversation) ||
        (citada?.quotedMessage?.extendedTextMessage?.text) || "";

      if (!textoParaContar) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Digite ou marque um texto para contar!\n\nExemplos:\n${PREFIXO}contar_letras Olá mundo\n\nOu responda uma mensagem com ${PREFIXO}contar_letras`
        }, { quoted: msg });
      }

      const totalLetras = textoParaContar.replace(/\s/g, "").length;
      const totalComEspacos = textoParaContar.length;
      const totalPalavras = textoParaContar.trim().split(/\s+/).filter(Boolean).length;
      const totalVogais = (textoParaContar.match(/[aeiouáéíóúãõâêîôûàèìòù]/gi) || []).length;
      const totalConsoantes = (textoParaContar.match(/[bcdfghjklmnpqrstvwxyz]/gi) || []).length;
      const totalNumeros = (textoParaContar.match(/[0-9]/g) || []).length;

      await sock.sendMessage(idChat, {
        text: `🔤 *CONTAGEM DE TEXTO* 🔤

📝 Texto: "${textoParaContar.length > 50 ? textoParaContar.slice(0, 50) + '...' : textoParaContar}"

📊 *RESULTADOS:*
🔤 Total de letras (sem espaços): ${totalLetras}
📏 Total com espaços: ${totalComEspacos}
📝 Palavras: ${totalPalavras}
🔴 Vogais: ${totalVogais}
🔵 Consoantes: ${totalConsoantes}
🔢 Números: ${totalNumeros}`
      }, { quoted: msg });
    },

    // ==========================================
    // 🐛 !bug — Enviar bug pro dono
    // ==========================================
    bug: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const descricao = args.join(" ").trim();

      if (!descricao) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Descreva o bug!\n\nExemplo:\n${PREFIXO}bug Erro no comando !menu não carrega a foto`
        }, { quoted: msg });
      }

      try {
        await sock.sendMessage(DONO, {
          text: `🐛 *NOVO RELATO DE BUG* 🐛

👤 Usuário: @${formatarUsuario(remetente)}
📅 Data: ${new Date().toLocaleString("pt-BR")}
📍 Chat: ${ehGrupo(idChat) ? "Grupo" : "PV"}

📝 Descrição:
"${descricao}"`
        });

        await sock.sendMessage(idChat, {
          text: `✅ *BUG ENVIADO COM SUCESSO!* ✅

Obrigado por ajudar a melhorar o ${NOME_BOT}! 🙏

📝 Seu relato foi enviado para o desenvolvedor e será analisado em breve.`
        }, { quoted: msg });

      } catch (e) {
        await sock.sendMessage(idChat, {
          text: `❌ Erro ao enviar o bug: ${e.message}\n\nTente novamente mais tarde!`
        }, { quoted: msg });
      }
    },

    // ==========================================
    // ⭐ !avaliar — Avaliar o bot (1-10)
    // ==========================================
    avaliar: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const nota = parseInt(args[0]);

      if (!nota || nota < 1 || nota > 10) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Dê uma nota de 1 a 10!\n\nExemplo:\n${PREFIXO}avaliar 10\n${PREFIXO}avaliar 8`
        }, { quoted: msg });
      }

      const comentario = args.slice(1).join(" ").trim() || "Sem comentário";

      try {
        const avaliacoes = carregarAvaliacoes();
        avaliacoes.push({
          usuario: remetente,
          nota,
          comentario,
          data: Date.now()
        });
        salvarAvaliacoes(avaliacoes);

        const media = (avaliacoes.reduce((s, a) => s + a.nota, 0) / avaliacoes.length).toFixed(1);

        await sock.sendMessage(DONO, {
          text: `⭐ *NOVA AVALIAÇÃO RECEBIDA!* ⭐

👤 Usuário: @${formatarUsuario(remetente)}
📅 Data: ${new Date().toLocaleString("pt-BR")}
⭐ Nota: ${nota}/10
💬 Comentário: "${comentario}"

📊 Média geral: ${media}/10 (${avaliacoes.length} avaliações)`
        });

        await sock.sendMessage(idChat, {
          text: `⭐ *OBRIGADO PELA AVALIAÇÃO!* ⭐

Você deu nota: ${nota}/10 💫

Sua opinião é muito importante para melhorarmos o ${NOME_BOT}! 🙏`
        }, { quoted: msg });

      } catch (e) {
        await sock.sendMessage(idChat, {
          text: `❌ Erro: ${e.message}`
        }, { quoted: msg });
      }
    },

    // ==========================================
    // 🧮 !calcular — Calculadora simples
    // ==========================================
    calcular: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const expressao = args.join(" ").trim();

      if (!expressao) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Digite uma operação matemática!\n\nExemplos:\n${PREFIXO}calcular 1+1\n${PREFIXO}calcular 5*3\n${PREFIXO}calcular 10/2\n${PREFIXO}calcular 15-7\n${PREFIXO}calcular (2+3)*4`
        }, { quoted: msg });
      }

      try {
        if (!/^[\d+\-*/().\s]+$/.test(expressao)) {
          throw new Error("Expressão inválida! Use apenas números e + - * / ( )");
        }

        const resultado = eval(expressao);

        if (!isFinite(resultado)) {
          throw new Error("Resultado inválido (divisão por zero?)");
        }

        await sock.sendMessage(idChat, {
          text: `🧮 *CALCULADORA* 🧮

📝 Operação: ${expressao}
✅ Resultado: ${resultado}`
        }, { quoted: msg });

      } catch (e) {
        await sock.sendMessage(idChat, {
          text: `❌ Erro no cálculo!\n${e.message}\n\n💡 Use: + (soma), - (subtração), * (multiplicação), / (divisão)`
        }, { quoted: msg });
      }
    },

    // ==========================================
    // 🤝 !alugar_bot — Número do dono para alugar
    // ==========================================
    alugar_bot: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const numeroDono = formatarUsuario(DONO);

      await sock.sendMessage(idChat, {
        text: `🤝 *QUER ALUGAR O BOT?* 🤝

Olá! 👋 Que bom que você se interessou em ter o ${NOME_BOT} no seu grupo!

✨ O que você ganha ao alugar:
✅ Bot exclusivo para o seu grupo
✅ Todos os comandos e jogos
✅ Atualizações e suporte
✅ Sistema de economia e família
✅ Moderação automática

📞 Para mais informações e valores, chame o dono no PV:
👤 @${numeroDono}

💬 Estamos ansiosos para atendê-lo! 😊`
      }, { quoted: msg });
    },

    // ==========================================
    // 🛒 !comprar_bot — Contato do criador
    // ==========================================
    comprar_bot: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;

      await sock.sendMessage(idChat, {
        text: `🛒 *QUER TER SEU PRÓPRIO BOT?* 🛒

👋 Olá! Imagina ter um bot *exclusivo só para você*, com todos os comandos, jogos e sistemas que você quiser?

✨ *O que você ganha ao comprar:*
✅ Bot 100% seu e exclusivo
✅ Personalização total (nome, foto, comandos)
✅ Todos os jogos e sistemas inclusos
✅ Suporte e atualizações
✅ Instalação e configuração completa
✅ Hospedagem 24h online

👨‍💻 *Criador:* Moon
📱 *WhatsApp:* +55 81 99564-7053
🔗 *Contato:* wa.me/5581995647053

💬 Não perca tempo! Chame agora e tenha o bot dos seus sonhos! 🚀

*${NOME_BOT}* — Feito com ❤️ para você!`
      }, { quoted: msg });
    }
  }
};

