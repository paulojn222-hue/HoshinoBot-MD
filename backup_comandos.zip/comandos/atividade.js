const config = require("../config.js");
const os = require("os");
const fs = require("fs");
const path = require("path");
const axios = require("axios");

const tempoInicial = Date.now();
const CAMINHO_ALUGUEIS = path.join(__dirname, "..", "dados", "alugueis.json");

function formatarTempo(ms) {
  if (ms <= 0) return "⚠️ Vencido!";
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  const d = Math.floor(h / 24);
  return `${d}d ${h % 24}h ${m % 60}m`;
}

function carregarAlugueis() {
  if (!fs.existsSync(CAMINHO_ALUGUEIS)) return {};
  try { return JSON.parse(fs.readFileSync(CAMINHO_ALUGUEIS, "utf-8")); }
  catch { return {}; }
}

// 🆔 Pega o ID do bot de forma segura
function pegarIdBot(sock) {
  return sock?.user?.id || sock?.user?.jid || sock?.authState?.creds?.me?.id || null;
}

module.exports = {
  nome: "infobot",
  comandos: {
    infobot: async (sock, msg, args, dados) => {
      const idChat = dados.idChat;
      
      // ⚡ Ping
      const inicio = Date.now();
      const tempMsg = await sock.sendMessage(idChat, { text: "⏱️" });
      const ping = Date.now() - inicio;
      await sock.sendMessage(idChat, { delete: tempMsg.key });
      
      // 💾 RAM
      const memoria = (process.memoryUsage().rss / 1024 / 1024).toFixed(1);
      
      // 📸 PEGA FOTO DO PERFIL ATUAL DO BOT
      let fotoBuffer = null;
      const idBot = pegarIdBot(sock);
      
      console.log("🤖 ID do bot detectado:", idBot);
      
      if (idBot) {
        try {
          // Pega a URL da foto de perfil ATUAL
          const urlFoto = await sock.profilePictureUrl(idBot, "image");
          console.log("📸 URL da foto:", urlFoto ? "✅ Encontrada" : "❌ Não encontrada");
          
          if (urlFoto) {
            // Baixa a foto como buffer
            const resposta = await axios.get(urlFoto, { 
              responseType: "arraybuffer",
              timeout: 10000
            });
            fotoBuffer = Buffer.from(resposta.data);
            console.log("✅ Foto baixada com sucesso!");
          }
        } catch (erro) {
          console.log("⚠️ Erro ao pegar foto do perfil:", erro.message);
        }
      }
      
      // 👑 Dados dono
      const nomeDono = config.donoNome || "Moon";
      const numeroDono = config.numeroDonoVisivel || config.numeroDono || "—";
      const numeroDonoLimpo = String(config.numeroDono).replace(/\D/g, "");
      
      // 🕸️ Aluguel
      let infoAluguel = "";
      if (idChat.includes("@g.us")) {
        const alugueis = carregarAlugueis();
        const aluguelGrupo = alugueis[idChat];
        
        if (aluguelGrupo) {
          const restante = aluguelGrupo.fim - Date.now();
          const tempoRestante = formatarTempo(restante);
          const status = restante > 0 ? "✅ ATIVO" : "⚠️ VENCIDO";
          
          infoAluguel = `
🕸️ *ALUGUEL DO GRUPO*
├─ Status: ${status}
├─ ⏳ Tempo restante: ${tempoRestante}
└─ 📅 Válido até: ${new Date(aluguelGrupo.fim).toLocaleString("pt-BR")}
`;
        } else {
          infoAluguel = `
🕸️ *ALUGUEL DO GRUPO*
└─ ⚠️ Grupo SEM aluguel registrado
`;
        }
      } else {
        infoAluguel = `
🕸️ *ALUGUEL*
└─ ℹ️ Use em um grupo para ver o status
`;
      }
      
      const legenda = `
🤖 *INFORMAÇÕES DO BOT* 🕸

1️⃣ *Nome:* ${config.nomeBot || "Bot-MD"}
2️⃣ *⚡ Velocidade:* ${ping}ms
3️⃣ *⏰ Tempo Online:* ${formatarTempo(Date.now() - tempoInicial)}
4️⃣ *👑 Dono:* ${nomeDono}
5️⃣ *📱 Número:* ${numeroDono}
6️⃣ *🔤 Prefixo:* ${config.prefixo || "!"}
7️⃣ *💾 RAM:* ${memoria} MB
8️⃣ *🖥️ Sistema:* ${os.platform()}
9️⃣ *📦 Node:* ${process.version}
🔟 *🎯 Status:* 🟢 Online

${infoAluguel}
👤 *Contato dono:* wa.me/${numeroDonoLimpo}
`.trim();
      
      // 📤 ENVIA A FOTO COMPLETA + LEGENDA
      if (fotoBuffer) {
        return sock.sendMessage(idChat, {
          image: fotoBuffer,
          caption: legenda,
          jpegThumbnail: fotoBuffer // Miniatura para quem não carregou a foto ainda
        });
      }
      
      // 📤 Se não conseguir pegar a foto, avisa e envia só texto
      console.log("⚠️ Enviando sem foto...");
      return sock.sendMessage(idChat, { 
        text: `⚠️ *Não consegui carregar a foto do perfil!*\n\nVerifique se:\n• O bot tem foto de perfil\n• A conta está conectada corretamente\n\n${legenda}` 
      });
    }
  }
};

