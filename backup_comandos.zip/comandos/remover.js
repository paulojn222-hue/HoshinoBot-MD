module.exports = {
  nome: "remover",
  comandos: {
    r: async (sock, msg, args, dados) => {
      const idChat = dados.idChat;
      
      // 🗑️ Primeiro apaga a mensagem do comando (!r)
      try {
        await sock.sendMessage(idChat, { delete: msg.key });
      } catch {}
      
      // 📨 Verifica se tem mensagem marcada/citada
      const citada = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const chaveCitada = msg.message?.extendedTextMessage?.contextInfo?.stanzaId;
      const participanteCitado = msg.message?.extendedTextMessage?.contextInfo?.participant;
      
      if (!citada || !chaveCitada) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Marque uma mensagem para apagar!\n\n💡 Responda uma mensagem com ${dados.prefixo || "!"}r`
        }, { ephemeralExpiration: 5000 });
      }
      
      // 🗑️ Apaga a mensagem marcada
      try {
        await sock.sendMessage(idChat, {
          delete: {
            remoteJid: idChat,
            fromMe: false,
            id: chaveCitada,
            participant: participanteCitado
          }
        });
      } catch (erro) {
        return sock.sendMessage(idChat, {
          text: `❌ Não consegui apagar!\n\nMotivo: Preciso ser ADMIN do grupo ou a mensagem tem que ser minha.`
        }, { ephemeralExpiration: 5000 });
      }
    }
  }
};

