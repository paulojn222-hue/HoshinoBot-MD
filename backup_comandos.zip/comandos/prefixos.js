const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const CAMINHO_PREFIXOS = path.join(__dirname, "..", "dados", "prefixos_extra.json");

// ✅ Garante arquivo
if (!fs.existsSync(path.dirname(CAMINHO_PREFIXOS))) {
  fs.mkdirSync(path.dirname(CAMINHO_PREFIXOS), { recursive: true });
}
if (!fs.existsSync(CAMINHO_PREFIXOS)) {
  fs.writeFileSync(CAMINHO_PREFIXOS, JSON.stringify([]));
}

function carregarPrefixos() {
  try { return JSON.parse(fs.readFileSync(CAMINHO_PREFIXOS, "utf-8")); }
  catch { return []; }
}
function salvarPrefixos(dados) {
  fs.writeFileSync(CAMINHO_PREFIXOS, JSON.stringify(dados, null, 2));
}

function ehDono(idUsuario) {
  if (!idUsuario) return false;
  return String(idUsuario).replace(/\D/g, "") === String(config.numeroDono).replace(/\D/g, "");
}

module.exports = {
  nome: "prefixos",
  comandos: {
    // ➕ !addprefixo_extra (SÓ DONO)
    addprefixo_extra: async (sock, msg, args, dados) => {
      const idChat = dados.idChat;
      
      if (!ehDono(dados.remetente)) {
        return sock.sendMessage(idChat, { text: `👑 *COMANDO EXCLUSIVO DO DONO!*` });
      }
      
      const novoPrefixo = args[0]?.trim();
      if (!novoPrefixo) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Informe o prefixo!\n\nUso: ${config.prefixo || "!"}addprefixo_extra .`
        });
      }
      
      const prefixos = carregarPrefixos();
      if (prefixos.includes(novoPrefixo)) {
        return sock.sendMessage(idChat, { text: `⚠️ Esse prefixo já existe!` });
      }
      
      prefixos.push(novoPrefixo);
      salvarPrefixos(prefixos);
      
      return sock.sendMessage(idChat, {
        text: `✅ *PREFIXO ADICIONADO!*\n\n🔤 Novo prefixo: \`${novoPrefixo}\`\n📋 Total: ${prefixos.length} prefixos extras`
      });
    },
    
    // 📋 !lista_prefixos (TODOS)
    lista_prefixos: async (sock, msg, args, dados) => {
      const idChat = dados.idChat;
      const prefixos = carregarPrefixos();
      const prefixoPrincipal = config.prefixo || "!";
      
      let texto = `📋 *PREFIXOS DISPONÍVEIS* 🕸\n\n⭐ *Principal:* \`${prefixoPrincipal}\`\n`;
      
      if (prefixos.length > 0) {
        texto += `\n➕ *Extras:*\n`;
        prefixos.forEach((p, i) => {
          texto += `${i + 1}. \`${p}\`\n`;
        });
      } else {
        texto += `\n⚠️ Nenhum prefixo extra cadastrado!`;
      }
      
      return sock.sendMessage(idChat, { text: texto });
    }
  }
};

