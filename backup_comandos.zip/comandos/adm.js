const { downloadMediaMessage } = require("@whiskeysockets/baileys");
const config = require("../config.js");
const fs = require("fs");
const path = require("path");

// ==========================================
// 📁 CAMINHOS DOS ARQUIVOS
// ==========================================
const CAMINHO_MUTADOS = path.join(__dirname, "..", "dados", "mutados.json");
const CAMINHO_ADVERTENCIAS = path.join(__dirname, "..", "dados", "advertencias.json");
const CAMINHO_SUBDONOS = path.join(__dirname, "..", "dados", "subdonos.json");
const CAMINHO_PARCERIAS = path.join(__dirname, "..", "dados", "parcerias.json");
const CAMINHO_BEMVINDO = path.join(__dirname, "..", "dados", "bemvindo.json");
const CAMINHO_LISTA_NEGRA = path.join(__dirname, "..", "dados", "lista_negra.json");
const CAMINHO_AGENDAMENTOS = path.join(__dirname, "..", "dados", "agendamentos.json");
const CAMINHO_CFG_GRUPO = path.join(__dirname, "..", "dados", "config_grupo.json");
const PASTA_MIDIAS = path.join(__dirname, "..", "midias");

// ✅ Garante pastas e arquivos
function garantir(caminho, conteudo = "{}") {
  if (!fs.existsSync(path.dirname(caminho))) fs.mkdirSync(path.dirname(caminho), { recursive: true });
  if (!fs.existsSync(caminho)) fs.writeFileSync(caminho, conteudo, "utf-8");
}
garantir(CAMINHO_MUTADOS);
garantir(CAMINHO_ADVERTENCIAS);
garantir(CAMINHO_SUBDONOS, "[]");
garantir(CAMINHO_PARCERIAS);
garantir(CAMINHO_BEMVINDO);
garantir(CAMINHO_LISTA_NEGRA, "[]");
garantir(CAMINHO_AGENDAMENTOS);
garantir(CAMINHO_CFG_GRUPO);
if (!fs.existsSync(PASTA_MIDIAS)) fs.mkdirSync(PASTA_MIDIAS, { recursive: true });

// ==========================================
// 📖 FUNÇÕES AUXILIARES
// ==========================================
function carregarJson(caminho) {
  try {
    const d = JSON.parse(fs.readFileSync(caminho, "utf-8"));
    return Array.isArray(d) ? d : { ...d };
  } catch { return caminho.endsWith(".json") && fs.readFileSync(caminho, "utf-8").trim() === "[]" ? [] : {}; }
}
function salvarJson(caminho, dados) {
  fs.writeFileSync(caminho, JSON.stringify(dados, null, 2), "utf-8");
}
function carregarListaNegra() { return carregarJson(CAMINHO_LISTA_NEGRA); }
function salvarListaNegra(lista) { salvarJson(CAMINHO_LISTA_NEGRA, lista); }
function carregarSubdonos() { return carregarJson(CAMINHO_SUBDONOS); }

const PREFIXO = config.prefixo || "!";
const DONO_LIMPO = String(config.numeroDono || "").replace(/\D/g, "");
function ehDono(id) { return String(id || "").replace(/\D/g, "") === DONO_LIMPO; }
function ehDonoOuSubdono(id) {
  if (!id) return false;
  if (ehDono(id)) return true;
  return carregarSubdonos().some(s => String(s).replace(/\D/g, "") === String(id).replace(/\D/g, ""));
}

async function ehAdminGrupo(sock, idGrupo, idUsuario) {
  try {
    const meta = await sock.groupMetadata(idGrupo);
    return meta.participants.some(p => p.id === idUsuario && p.admin) || ehDonoOuSubdono(idUsuario);
  } catch { return ehDonoOuSubdono(idUsuario); }
}
function pegarMencao(msg) {
  const cit = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  if (cit) return msg.message.extendedTextMessage.contextInfo.participant;
  const m = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
  return m?.length ? m[0] : null;
}
function horarioParaMinutos(horario) {
  if (!/^\d{1,2}:\d{2}$/.test(horario)) return null;
  const [h, m] = horario.split(":").map(Number);
  if (h < 0 || h > 23 || m < 0 || m > 59) return null;
  return h * 60 + m;
}

// 🔇 Sistema de Mute
function estaMutado(idGrupo, idUsuario) {
  const m = carregarJson(CAMINHO_MUTADOS);
  return !!m[`${idGrupo}_${idUsuario}`];
}
function mutarGrupo(idGrupo, idUsuario) {
  const m = carregarJson(CAMINHO_MUTADOS);
  m[`${idGrupo}_${idUsuario}`] = true;
  salvarJson(CAMINHO_MUTADOS, m);
}
function desmutarGrupo(idGrupo, idUsuario) {
  const m = carregarJson(CAMINHO_MUTADOS);
  delete m[`${idGrupo}_${idUsuario}`];
  salvarJson(CAMINHO_MUTADOS, m);
}

// ==========================================
// 📋 COMANDOS
// ==========================================
module.exports = {
  nome: "adm",
  estaMutado,

  comandos: {

    // 👑 !menudono
    menudono: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return sock.sendMessage(idChat, { text: "⚠️ Use em grupo!" });
      if (!ehDonoOuSubdono(remetente)) return sock.sendMessage(idChat, { text: "🚫 Apenas donos!" });

      const mencao = `@${remetente.split("@")[0]}`;
      const caminhoMenu = path.join(__dirname, "..", "menus", "menu_dono.txt");
      const caminhoFoto = path.join(__dirname, "..", "midias", "foto_menu.jpg");
      let texto = "⚠️ Arquivo menus/menu_dono.txt não encontrado!";

      if (fs.existsSync(caminhoMenu)) {
        texto = fs.readFileSync(caminhoMenu, "utf-8")
          .replace(/{NOME_BOT}/g, config.nomeBot || "SukunaBot-MD")
          .replace(/{PREFIXO}/g, PREFIXO)
          .replace(/{USUARIO}/g, mencao)
          .replace(/{DONO_NOME}/g, config.nomeDono || "Moon")
          .replace(/{DONO_NUMERO_VISIVEL}/g, config.numeroDonoVisivel || "+55 81 99564-7053")
          .replace(/{VERSAO}/g, config.versao || "1.0.0");
      }

      if (fs.existsSync(caminhoFoto)) {
        return sock.sendMessage(idChat, { image: fs.readFileSync(caminhoFoto), caption: texto, mentions: [remetente] });
      }
      return sock.sendMessage(idChat, { text, mentions: [remetente] });
    },

    // 🤝 !delparceria
    delparceria: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, remetente)) return;

      const alvo = pegarMencao(msg);
      if (!alvo) return sock.sendMessage(idChat, { text: "⚠️ Marque a pessoa!\nExemplo: !delparceria @pessoa" });

      const p = carregarJson(CAMINHO_PARCERIAS);
      const chave = `${idChat}_${alvo}`;
      if (!p[chave]) return sock.sendMessage(idChat, { text: "⚠️ Não é parceiro!" });
      delete p[chave];
      salvarJson(CAMINHO_PARCERIAS, p);
      return sock.sendMessage(idChat, { text: `✅ Parceiro removido!\n👤 @${alvo.split("@")[0]}`, mentions: [alvo] });
    },

    // 📢 !totag
    totag: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return sock.sendMessage(idChat, { text: "❌ Use em grupo!" });
      const meta = await sock.groupMetadata(idChat);
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!meta.participants.find(p => p.id === remetente)?.admin) return;

      const texto = args.length ? args.join(" ") : "📢 Atenção a todos!";
      const todos = meta.participants.map(p => p.id);
      return sock.sendMessage(idChat, { text, mentions: todos });
    },

    // ⛔ !add_listanegra
    add_listanegra: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!await ehAdminGrupo(sock, idChat, remetente)) return;

      const alvo = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
      if (!alvo) return sock.sendMessage(idChat, { text: "⚠️ Mencione: !add_listanegra @usuario" });

      let lista = carregarListaNegra();
      if (lista.some(i => i.id === alvo)) return sock.sendMessage(idChat, { text: "⚠️ Já está na lista!" });

      lista.push({ id: alvo, adicionadoPor: remetente, data: new Date().toLocaleString("pt-BR") });
      salvarListaNegra(lista);

      const meta = await sock.groupMetadata(idChat);
      if (meta.participants.find(p => p.id === alvo)) {
        await sock.groupParticipantsUpdate(idChat, [alvo], "remove");
      }
      return sock.sendMessage(idChat, { text: `🚫 Adicionado à lista negra:\n👤 @${alvo.split("@")[0]}`, mentions: [alvo] });
    },

    // ✅ !rm_listanegra
    rm_listanegra: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!await ehAdminGrupo(sock, idChat, remetente)) return;

      const lista = carregarListaNegra();
      const entrada = args[0];
      if (/^\d+$/.test(entrada)) {
        const idx = parseInt(entrada) - 1;
        if (idx < 0 || idx >= lista.length) return sock.sendMessage(idChat, { text: "⚠️ Número inválido!" });
        const rem = lista.splice(idx, 1)[0];
        salvarListaNegra(lista);
        return sock.sendMessage(idChat, { text: `✅ Removido:\n👤 @${rem.id.split("@")[0]}`, mentions: [rem.id] });
      }
      const idx = lista.findIndex(i => i.id === entrada);
      if (idx === -1) return sock.sendMessage(idChat, { text: "⚠️ Não encontrado!" });
      const rem = lista.splice(idx, 1)[0];
      salvarListaNegra(lista);
      return sock.sendMessage(idChat, { text: `✅ Removido:\n👤 @${rem.id.split("@")[0]}`, mentions: [rem.id] });
    },

    // 📋 !listanegra
    listanegra: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!await ehAdminGrupo(sock, idChat, remetente)) return;

      const lista = carregarListaNegra();
      if (!lista.length) return sock.sendMessage(idChat, { text: "📋 Lista negra vazia!" });

      let texto = "⛔ *LISTA NEGRA*\n\n";
      const mencoes = [];
      lista.forEach((item, i) => {
        texto += `${i+1}. 👤 @${item.id.split("@")[0]}\n⏳ ${item.data}\n\n`;
        mencoes.push(item.id);
      });
      return sock.sendMessage(idChat, { text: texto.trim(), mentions: mencoes });
    },

    // 👋 Bem-vindo
    ativar_bemvindo: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;

      const cfg = carregarJson(CAMINHO_BEMVINDO);
      cfg[idChat] = cfg[idChat] || { ativo: false, texto: "👋 Bem-vindo(a) @usuario!", textoSaiu: "👋 @usuario saiu!" };
      cfg[idChat].ativo = true;
      salvarJson(CAMINHO_BEMVINDO, cfg);
      return sock.sendMessage(idChat, { text: "✅ Bem-vindo ativado!" });
    },
    desativar_bemvindo: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;

      const cfg = carregarJson(CAMINHO_BEMVINDO);
      if (!cfg[idChat]) return sock.sendMessage(idChat, { text: "⚠️ Não configurado!" });
      cfg[idChat].ativo = false;
      salvarJson(CAMINHO_BEMVINDO, cfg);
      return sock.sendMessage(idChat, { text: "✅ Bem-vindo desativado!" });
    },
    textobemvindo: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;

      const texto = args.join(" ");
      if (!texto) return sock.sendMessage(idChat, { text: "⚠️ Use: !textobemvindo Bem-vindo @usuario!" });

      const cfg = carregarJson(CAMINHO_BEMVINDO);
      cfg[idChat] = cfg[idChat] || { ativo: false };
      cfg[idChat].texto = texto;
      salvarJson(CAMINHO_BEMVINDO, cfg);
      return sock.sendMessage(idChat, { text: `✅ Texto definido:\n${texto}` });
    },
    textosaiu: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;

      const texto = args.join(" ");
      if (!texto) return sock.sendMessage(idChat, { text: "⚠️ Use: !textosaiu Adeus @usuario!" });

      const cfg = carregarJson(CAMINHO_BEMVINDO);
      cfg[idChat] = cfg[idChat] || {};
      cfg[idChat].textoSaiu = texto;
      salvarJson(CAMINHO_BEMVINDO, cfg);
      return sock.sendMessage(idChat, { text: `✅ Texto de saída definido:\n${texto}` });
    },
    midiabemvindo: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;

      const cit = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      if (!cit?.imageMessage && !cit?.videoMessage) {
        return sock.sendMessage(idChat, { text: "⚠️ Responda uma imagem/vídeo!" });
      }

      const cfg = carregarJson(CAMINHO_BEMVINDO);
      cfg[idChat] = cfg[idChat] || {};
      const midia = await downloadMediaMessage({ key: msg.key, message: cit }, "buffer", {});
      if (cit.imageMessage) {
        cfg[idChat].midia = `data:image/jpeg;base64,${midia.toString("base64")}`;
        cfg[idChat].tipoMidia = "imagem";
      } else {
        cfg[idChat].midia = `data:video/mp4;base64,${midia.toString("base64")}`;
        cfg[idChat].tipoMidia = "video";
      }
      salvarJson(CAMINHO_BEMVINDO, cfg);
      return sock.sendMessage(idChat, { text: "✅ Mídia de bem-vindo salva!" });
    },
    midiasaiu: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;

      const cit = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      if (!cit?.imageMessage && !cit?.videoMessage) {
        return sock.sendMessage(idChat, { text: "⚠️ Responda uma imagem/vídeo!" });
      }

      const cfg = carregarJson(CAMINHO_BEMVINDO);
      cfg[idChat] = cfg[idChat] || {};
      const midia = await downloadMediaMessage({ key: msg.key, message: cit }, "buffer", {});
      if (cit.imageMessage) {
        cfg[idChat].midiaSaiu = `data:image/jpeg;base64,${midia.toString("base64")}`;
        cfg[idChat].tipoMidiaSaiu = "imagem";
      } else {
        cfg[idChat].midiaSaiu = `data:video/mp4;base64,${midia.toString("base64")}`;
        cfg[idChat].tipoMidiaSaiu = "video";
      }
      salvarJson(CAMINHO_BEMVINDO, cfg);
      return sock.sendMessage(idChat, { text: "✅ Mídia de saída salva!" });
    },

    // 📋 !listaparceria
    listaparceria: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const p = carregarJson(CAMINHO_PARCERIAS);
      let texto = `📋 *LISTA DE PARCEIROS*\n\n👤 Solicitado por: @${remetente.split("@")[0]}\n\n`;
      const mencoes = [remetente];
      let tem = false;
      for (const chave in p) {
        if (chave.startsWith(idChat)) {
          tem = true;
          const usuario = p[chave];
          texto += `👤 @${usuario.idUsuario.split("@")[0]} — ${usuario.vezesRestantes}/${usuario.vezesTotal} vez(es)\n`;
          mencoes.push(usuario.idUsuario);
        }
      }
      if (!tem) texto += "Nenhum parceiro cadastrado!";
      return sock.sendMessage(idChat, { text, mentions: mencoes });
    },

    // 🛡️ Sistemas de proteção
    antiimg: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;
      const cfg = carregarJson(CAMINHO_CFG_GRUPO);
      cfg[idChat] = cfg[idChat] || {};
      cfg[idChat].antiImg = !cfg[idChat].antiImg;
      salvarJson(CAMINHO_CFG_GRUPO, cfg);
      return sock.sendMessage(idChat, { text: cfg[idChat].antiImg ? "✅ Anti-imagem ativado!" : "✅ Anti-imagem desativado!" });
    },
    antifig: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;
      const cfg = carregarJson(CAMINHO_CFG_GRUPO);
      cfg[idChat] = cfg[idChat] || {};
      cfg[idChat].antiFig = !cfg[idChat].antiFig;
      salvarJson(CAMINHO_CFG_GRUPO, cfg);
      return sock.sendMessage(idChat, { text: cfg[idChat].antiFig ? "✅ Anti-figurinha ativado!" : "✅ Anti-figurinha desativado!" });
    },
    antiaudio: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;
      const cfg = carregarJson(CAMINHO_CFG_GRUPO);
      cfg[idChat] = cfg[idChat] || {};
      cfg[idChat].antiAudio = !cfg[idChat].antiAudio;
      salvarJson(CAMINHO_CFG_GRUPO, cfg);
      return sock.sendMessage(idChat, { text: cfg[idChat].antiAudio ? "✅ Anti-áudio ativado!" : "✅ Anti-áudio desativado!" });
    },
    antivideo: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;
      const cfg = carregarJson(CAMINHO_CFG_GRUPO);
      cfg[idChat] = cfg[idChat] || {};
      cfg[idChat].antiVideo = !cfg[idChat].antiVideo;
      salvarJson(CAMINHO_CFG_GRUPO, cfg);
      return sock.sendMessage(idChat, { text: cfg[idChat].antiVideo ? "✅ Anti-vídeo ativado!" : "✅ Anti-vídeo desativado!" });
    },
    antilink: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;
      const cfg = carregarJson(CAMINHO_CFG_GRUPO);
      cfg[idChat] = cfg[idChat] || {};
      cfg[idChat].antiLink = !cfg[idChat].antiLink;
      salvarJson(CAMINHO_CFG_GRUPO, cfg);
      return sock.sendMessage(idChat, { text: cfg[idChat].antiLink ? "✅ Anti-link ativado!" : "✅ Anti-link desativado!" });
    },
    somente_adm: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;
      const cfg = carregarJson(CAMINHO_CFG_GRUPO);
      cfg[idChat] = cfg[idChat] || {};
      cfg[idChat].somenteAdm = !cfg[idChat].somenteAdm;
      salvarJson(CAMINHO_CFG_GRUPO, cfg);
      return sock.sendMessage(idChat, { text: cfg[idChat].somenteAdm ? "✅ Modo só ADM ativado!" : "✅ Modo só ADM desativado!" });
    },
    modo_parceria: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;
      const cfg = carregarJson(CAMINHO_CFG_GRUPO);
      cfg[idChat] = cfg[idChat] || {};
      cfg[idChat].modoParceria = !cfg[idChat].modoParceria;
      salvarJson(CAMINHO_CFG_GRUPO, cfg);
      return sock.sendMessage(idChat, { text: cfg[idChat].modoParceria ? "✅ Modo parceria ativado!" : "✅ Modo parceria desativado!" });
    },

    // 📋 !menuadm
    menuadm: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!await ehAdminGrupo(sock, idChat, remetente)) return;

      const mencao = `@${remetente.split("@")[0]}`;
      const caminhoMenu = path.join(__dirname, "..", "menus", "menu_adm.txt");
      const caminhoFoto = path.join(PASTA_MIDIAS, "foto_menu.jpg");
      const caminhoVideo = path.join(PASTA_MIDIAS, "video_menu.mp4");
      let texto = "⚠️ menus/menu_adm.txt não encontrado!";

      if (fs.existsSync(caminhoMenu)) {
        texto = fs.readFileSync(caminhoMenu, "utf-8")
          .replace(/{NOME_BOT}/g, config.nomeBot || "SukunaBot-MD")
          .replace(/{DONO_NOME}/g, config.nomeDono || "Moon")
          .replace(/{DONO_NUMERO_VISIVEL}/g, config.numeroDonoVisivel || "+55 81 99564-7053")
          .replace(/{VERSAO}/g, config.versao || "1.0.0")
          .replace(/{USUARIO}/g, mencao)
          .replace(/{PREFIXO}/g, PREFIXO);
      }

      if (fs.existsSync(caminhoVideo)) {
        return sock.sendMessage(idChat, { video: fs.readFileSync(caminhoVideo), caption: texto, mentions: [remetente], gifPlayback: true });
      }
      if (fs.existsSync(caminhoFoto)) {
        return sock.sendMessage(idChat, { image: fs.readFileSync(caminhoFoto), caption: texto, mentions: [remetente] });
      }
      return sock.sendMessage(idChat, { text, mentions: [remetente] });
    },

    // ⛔ Banir / Promover / Rebaixar
    ban: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!await ehAdminGrupo(sock, idChat, remetente)) return;

      const alvo = pegarMencao(msg);
      if (!alvo) return sock.sendMessage(idChat, { text: "⚠️ Marque a pessoa!" });
      if (ehDonoOuSubdono(alvo)) return sock.sendMessage(idChat, { text: "⚠️ Não posso banir administrador!" });

      await sock.groupParticipantsUpdate(idChat, [alvo], "remove");
      return sock.sendMessage(idChat, { text: `✅ Banido!\n👤 @${alvo.split("@")[0]}`, mentions: [alvo] });
    },
    promover: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!await ehAdminGrupo(sock, idChat, remetente)) return;

      const alvo = pegarMencao(msg);
      if (!alvo) return sock.sendMessage(idChat, { text: "⚠️ Marque a pessoa!" });
      await sock.groupParticipantsUpdate(idChat, [alvo], "promote");
      return sock.sendMessage(idChat, { text: `✅ Promovido a ADM!\n👤 @${alvo.split("@")[0]}`, mentions: [alvo] });
    },
    rebaixar: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!await ehAdminGrupo(sock, idChat, remetente)) return;

      const alvo = pegarMencao(msg);
      if (!alvo) return sock.sendMessage(idChat, { text: "⚠️ Marque a pessoa!" });
      if (ehDonoOuSubdono(alvo)) return sock.sendMessage(idChat, { text: "⚠️ Não posso rebaixar o dono!" });

      await sock.groupParticipantsUpdate(idChat, [alvo], "demote");
      return sock.sendMessage(idChat, { text: `✅ Rebaixado!\n👤 @${alvo.split("@")[0]}`, mentions: [alvo] });
    },

    // 🔇 Mute / Desmute
    mute: async (sock, msg, args, dados) => {
      const idGrupo = msg.key.remoteJid;
      if (!idGrupo.includes("@g.us")) return;
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!await ehAdminGrupo(sock, idGrupo, remetente)) return;

      const alvo = pegarMencao(msg);
      if (!alvo) return sock.sendMessage(idGrupo, { text: "⚠️ Marque a pessoa: !mute @pessoa" });
      if (await ehAdminGrupo(sock, idGrupo, alvo)) return sock.sendMessage(idGrupo, { text: "⚠️ Não posso mutar um ADM!" });

      mutarGrupo(idGrupo, alvo);
      return sock.sendMessage(idGrupo, { text: `✅ Mutado!\n👤 @${alvo.split("@")[0]}\nTudo que enviar será apagado!`, mentions: [alvo] });
    },
    desmute: async (sock, msg, args, dados) => {
      const idGrupo = msg.key.remoteJid;
      if (!idGrupo.includes("@g.us")) return;
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!await ehAdminGrupo(sock, idGrupo, remetente)) return;

      const alvo = pegarMencao(msg);
      if (!alvo) return sock.sendMessage(idGrupo, { text: "⚠️ Marque a pessoa: !desmute @pessoa" });
      desmutarGrupo(idGrupo, alvo);
      return sock.sendMessage(idGrupo, { text: `✅ Desmutado!\n👤 @${alvo.split("@")[0]}\nPode falar normalmente!`, mentions: [alvo] });
    },

    // ⚠️ Advertências
    adv: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!await ehAdminGrupo(sock, idChat, remetente)) return;

      const alvo = pegarMencao(msg);
      if (!alvo) return sock.sendMessage(idChat, { text: "⚠️ Marque a pessoa!" });
      if (ehDonoOuSubdono(alvo)) return sock.sendMessage(idChat, { text: "⚠️ Não pode advertir administrador!" });

      const advs = carregarJson(CAMINHO_ADVERTENCIAS);
      const chave = `${idChat}_${alvo}`;
      advs[chave] = (advs[chave] || 0) + 1;
      salvarJson(CAMINHO_ADVERTENCIAS, advs);

      if (advs[chave] >= 3) {
        await sock.groupParticipantsUpdate(idChat, [alvo], "remove");
        delete advs[chave];
        salvarJson(CAMINHO_ADVERTENCIAS, advs);
        return sock.sendMessage(idChat, { text: `🚨 3 advertências → BANIDO!\n👤 @${alvo.split("@")[0]}`, mentions: [alvo] });
      }
      return sock.sendMessage(idChat, { text: `⚠️ Advertência ${advs[chave]}/3\n👤 @${alvo.split("@")[0]}`, mentions: [alvo] });
    },
    veradv: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!await ehAdminGrupo(sock, idChat, remetente)) return;

      const alvo = pegarMencao(msg) || remetente;
      const qtd = carregarJson(CAMINHO_ADVERTENCIAS)[`${idChat}_${alvo}`] || 0;
      return sock.sendMessage(idChat, { text: `📋 Advertências: ${qtd}/3\n👤 @${alvo.split("@")[0]}`, mentions: [alvo] });
    },
    rmadv: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!await ehAdminGrupo(sock, idChat, remetente)) return;

      const alvo = pegarMencao(msg);
      if (!alvo) return sock.sendMessage(idChat, { text: "⚠️ Marque a pessoa!" });
      const advs = carregarJson(CAMINHO_ADVERTENCIAS);
      const chave = `${idChat}_${alvo}`;
      if (advs[chave] && advs[chave] > 0) {
        advs[chave]--;
        salvarJson(CAMINHO_ADVERTENCIAS, advs);
        return sock.sendMessage(idChat, { text: `✅ -1 advertência\n👤 @${alvo.split("@")[0]} → ${advs[chave]}/3`, mentions: [alvo] });
      }
      return sock.sendMessage(idChat, { text: "⚠️ Sem advertências!" });
    },
    zeraradv: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!await ehAdminGrupo(sock, idChat, remetente)) return;

      const alvo = pegarMencao(msg);
      if (!alvo) return sock.sendMessage(idChat, { text: "⚠️ Marque a pessoa!" });
      const advs = carregarJson(CAMINHO_ADVERTENCIAS);
      const chave = `${idChat}_${alvo}`;
      if (advs[chave]) {
        delete advs[chave];
        salvarJson(CAMINHO_ADVERTENCIAS, advs);
        return sock.sendMessage(idChat, { text: `✅ Advertências zeradas!\n👤 @${alvo.split("@")[0]}`, mentions: [alvo] });
      }
      return sock.sendMessage(idChat, { text: "⚠️ Sem advertências!" });
    },

    // 🔓 Abrir / 🔒 Fechar
    abrir: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;
      await sock.groupSettingUpdate(idChat, "not_announcement");
      return sock.sendMessage(idChat, { text: "✅ *GRUPO ABERTO!* 🔓" });
    },
    fechar: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;
      await sock.groupSettingUpdate(idChat, "announcement");
      return sock.sendMessage(idChat, { text: "✅ *GRUPO FECHADO!* 🔒" });
    },

    // ⏰ Agendar abrir/fechar
    fechargp: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;

      const horario = args[0];
      if (!horario || !horarioParaMinutos(horario)) {
        return sock.sendMessage(idChat, { text: "⚠️ Use: !fechargp HH:MM\nEx: !fechargp 23:00" });
      }
      const agend = carregarJson(CAMINHO_AGENDAMENTOS);
      agend[idChat] = agend[idChat] || {};
      agend[idChat].fechar = horario;
      salvarJson(CAMINHO_AGENDAMENTOS, agend);
      return sock.sendMessage(idChat, { text: `✅ Fechar agendado: ${horario}` });
    },
    abrirgp: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;

      const horario = args[0];
      if (!horario || !horarioParaMinutos(horario)) {
        return sock.sendMessage(idChat, { text: "⚠️ Use: !abrirgp HH:MM\nEx: !abrirgp 07:00" });
      }
      const agend = carregarJson(CAMINHO_AGENDAMENTOS);
      agend[idChat] = agend[idChat] || {};
      agend[idChat].abrir = horario;
      salvarJson(CAMINHO_AGENDAMENTOS, agend);
      return sock.sendMessage(idChat, { text: `✅ Abrir agendado: ${horario}` });
    },

    // 📝 Legendas
    legendafechar: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;

      const texto = args.join(" ").trim();
      if (!texto) return sock.sendMessage(idChat, { text: "⚠️ Digite o texto!" });
      const cfg = carregarJson(CAMINHO_CFG_GRUPO);
      cfg[idChat] = cfg[idChat] || {};
      cfg[idChat].legendaFechar = texto;
      salvarJson(CAMINHO_CFG_GRUPO, cfg);
      return sock.sendMessage(idChat, { text: `✅ Legenda salva:\n"${texto}"` });
    },
    legendaabrir: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;

      const texto = args.join(" ").trim();
      if (!texto) return sock.sendMessage(idChat, { text: "⚠️ Digite o texto!" });
      const cfg = carregarJson(CAMINHO_CFG_GRUPO);
      cfg[idChat] = cfg[idChat] || {};
      cfg[idChat].legendaAbrir = texto;
      salvarJson(CAMINHO_CFG_GRUPO, cfg);
      return sock.sendMessage(idChat, { text: `✅ Legenda salva:\n"${texto}"` });
    },

    // 🖼️ Imagens de abrir/fechar
    foto_fechar: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;

      const cit = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      if (!cit?.imageMessage && !cit?.jpegThumbnail) {
        return sock.sendMessage(idChat, { text: "⚠️ Responda uma imagem!" });
      }
      try {
        const buffer = await downloadMediaMessage(
          { key: msg.message.extendedTextMessage.contextInfo.stanzaId, message: cit },
          "buffer", {}
        );
        const idLimpo = idChat.split("@")[0];
        fs.writeFileSync(path.join(PASTA_MIDIAS, `fechar_${idLimpo}.jpg`), buffer);
        const cfg = carregarJson(CAMINHO_CFG_GRUPO);
        cfg[idChat] = cfg[idChat] || {};
        cfg[idChat].fotoFechar = true;
        salvarJson(CAMINHO_CFG_GRUPO, cfg);
        return sock.sendMessage(idChat, { text: "✅ Imagem de fechar salva!" });
      } catch (e) {
        return sock.sendMessage(idChat, { text: `❌ Erro: ${e.message}` });
      }
    },
    foto_abrir: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;

      const cit = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      if (!cit?.imageMessage && !cit?.jpegThumbnail) {
        return sock.sendMessage(idChat, { text: "⚠️ Responda uma imagem!" });
      }
      try {
        const buffer = await downloadMediaMessage(
          { key: msg.message.extendedTextMessage.contextInfo.stanzaId, message: cit },
          "buffer", {}
        );
        const idLimpo = idChat.split("@")[0];
        fs.writeFileSync(path.join(PASTA_MIDIAS, `abrir_${idLimpo}.jpg`), buffer);
        const cfg = carregarJson(CAMINHO_CFG_GRUPO);
        cfg[idChat] = cfg[idChat] || {};
        cfg[idChat].fotoAbrir = true;
        salvarJson(CAMINHO_CFG_GRUPO, cfg);
        return sock.sendMessage(idChat, { text: "✅ Imagem de abrir salva!" });
      } catch (e) {
        return sock.sendMessage(idChat, { text: `❌ Erro: ${e.message}` });
      }
    },

    // ✏️ Nome / Descrição do grupo
    setnomegp: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;

      const nome = args.join(" ");
      if (!nome) return sock.sendMessage(idChat, { text: `⚠️ Digite: ${PREFIXO}setnomegp Nome do Grupo` });
      await sock.groupUpdateSubject(idChat, nome);
      return sock.sendMessage(idChat, { text: `✅ Nome alterado:\n📝 ${nome}` });
    },
    set_descricao: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;

      const texto = args.join(" ");
      if (!texto) return sock.sendMessage(idChat, { text: "⚠️ Digite a descrição!" });
      await sock.groupUpdateDescription(idChat, texto);
      return sock.sendMessage(idChat, { text: "✅ Descrição alterada!" });
    },

    // ℹ️ Info / 🔗 Link
    infogrupo: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;

      const meta = await sock.groupMetadata(idChat);
      const admins = meta.participants.filter(p => p.admin).map(a => `@${a.id.split("@")[0]}`).join("\n");
      return sock.sendMessage(idChat, {
        text: `ℹ️ *GRUPO*\n\n📌 ${meta.subject}\n🆔 ${idChat}\n👥 ${meta.participants.length} membros\n👑 Admins:\n${admins}`,
        mentions: meta.participants.filter(p => p.admin).map(a => a.id)
      });
    },
    link_grupo: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;

      try {
        const codigo = await sock.groupInviteCode(idChat);
        return sock.sendMessage(idChat, { text: `🔗 Link:\nhttps://chat.whatsapp.com/${codigo}` });
      } catch {
        return sock.sendMessage(idChat, { text: "❌ Não consegui pegar o link!" });
      }
    },
    resetlink: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!idChat.includes("@g.us")) return;
      if (!await ehAdminGrupo(sock, idChat, msg.key.participant || msg.key.remoteJid)) return;

      try {
        const novo = await sock.groupRevokeInvite(idChat);
        return sock.sendMessage(idChat, { text: `✅ Link redefinido!\nhttps://chat.whatsapp.com/${novo}` });
      } catch {
        return sock.sendMessage(idChat, { text: "❌ Não consegui redefinir!" });
      }
    }
  }
};

