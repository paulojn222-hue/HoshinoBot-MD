const config = require("../config.js");
const axios = require("axios");

function ehDono(idUsuario) {
  if (!idUsuario) return false;
  const donoLimpo = String(config.numeroDono).replace(/\D/g, "");
  return String(idUsuario).replace(/\D/g, "") === donoLimpo;
}

module.exports = {
  nome: "grupoid",
  comandos: {
    grupoid: async (sock, msg, args, dados) => {
      const idChat = dados.idChat;
      
      if (!ehDono(dados.remetente)) {
        return sock.sendMessage(idChat, {
          text: `👑 *COMANDO EXCLUSIVO DO DONO!* 🕸`
        });
      }
      
      if (!idChat.includes("@g.us")) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Use este comando apenas em grupos! 🕷`
        });
      }
      
      try {
        const metadata = await sock.groupMetadata(idChat);
        const donoGrupo = metadata.owner; // ex: "5511999999999@s.whatsapp.net"
        const donoApenasNumero = donoGrupo.split("@")[0]; // ex: "5511999999999"
        
        console.log("👑 Dono do grupo:", donoGrupo); // Vai aparecer no terminal
        
        // 📸 PEGA A FOTO DO GRUPO
        let fotoGrupo = null;
        try {
          const urlFoto = await sock.profilePictureUrl(idChat, "image");
          if (urlFoto) {
            const res = await axios.get(urlFoto, { responseType: "arraybuffer", timeout: 10000 });
            fotoGrupo = Buffer.from(res.data);
          }
        } catch (erro) {
          console.log("⚠️ Foto do grupo não encontrada:", erro.message);
        }
        
        // 📝 Legenda — @ com o número COMPLETO
        const legenda = `
🆔 *INFORMAÇÕES DO GRUPO* 🕸

📛 *Nome:* ${metadata.subject}
🆔 *ID:* ${idChat}
👑 *Dono:* @${donoApenasNumero}
👥 *Membros:* ${metadata.participants.length}
📅 *Criado em:* ${new Date(metadata.creation * 1000).toLocaleDateString("pt-BR")}
`.trim();
        
        // ✅ MENÇÃO GARANTIDA — o array precisa ter o JID completo
        const mencoes = [donoGrupo];
        
        if (fotoGrupo) {
          return sock.sendMessage(
            idChat,
            {
              image: fotoGrupo,
              caption: legenda,
              mentions: mencoes
            }
          );
        }
        
        // Sem foto
        return sock.sendMessage(
          idChat,
          {
            text: legenda,
            mentions: mencoes
          }
        );
        
      } catch (erro) {
        console.log("❌ Erro grupoid:", erro);
        return sock.sendMessage(idChat, { 
          text: `❌ Erro: ${erro.message}` 
        });
      }
    }
  }
};

