const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const PREFIXO = config.prefixo || "!";
const NOME_BOT = config.nomeBot || "MoonBot-MD";                              
const DONO_NOME = config.donoNome || "Dono";
const DONO_NUMERO_VISIVEL = config.numeroDonoVisivel || config.numeroDono || "+55 00 00000-0000";

// 📂 Caminhos
const PASTA_MIDIAS = path.join(__dirname, "..", "midias");
const PASTA_MENUS = path.join(__dirname, "..", "menus");                      
const CAMINHO_RPG = path.join(__dirname, "..", "dados", "rpg.json");
const CAMINHO_VIPS = path.join(__dirname, "..", "dados", "vips.json"); // ✅ Adicionado
const FOTO_GLOBAL = path.join(PASTA_MIDIAS, "foto_menu_global.jpg");
const VIDEO_GLOBAL = path.join(PASTA_MIDIAS, "video_menu_global.mp4");

// ✅ Verifica pastas                                                         
if (!fs.existsSync(PASTA_MIDIAS)) fs.mkdirSync(PASTA_MIDIAS, { recursive: true });            
if (!fs.existsSync(PASTA_MENUS)) fs.mkdirSync(PASTA_MENUS, { recursive: true });

// ✅ Carrega VIPs
function carregarVips() {
  if (!fs.existsSync(CAMINHO_VIPS)) return {};
  try { return JSON.parse(fs.readFileSync(CAMINHO_VIPS, "utf-8")); }
  catch { return {}; }
}

// ✅ Verifica se é VIP ou Dono
function verificarVip(idUsuario) {
  if (!idUsuario) return false;
  const idLimpo = String(idUsuario).replace(/\D/g, "").split("@")[0];
  const donoLimpo = String(config.numeroDono).replace(/\D/g, "");
  if (idLimpo === donoLimpo) return true; // Dono sempre é VIP
  
  const vips = carregarVips();
  for (const [id, info] of Object.entries(vips)) {
    if (String(id).replace(/\D/g, "") === idLimpo) {
      if (!info.fim || info.fim > Date.now()) return true;
    }
  }
  return false;
}

// ✅ Verifica dono
function verificarDono(remetente) {
  const numeroLimpo = String(remetente || "").replace(/\D/g, "").split("@")[0];  
  const donoLimpo = String(config.numeroDono || "").replace(/\D/g, "");
  return numeroLimpo === donoLimpo;
}

// 🔧 Extrai só o número do remetente
function pegarNumero(remetente) {
  if (!remetente) return "Usuario";
  return String(remetente).split("@")[0].replace(/\D/g, "");
}

// 📖 Verifica status RPG
function verificarStatusRPG(numeroUsuario) {
  try {
    if (!fs.existsSync(CAMINHO_RPG)) return "OFF";
    const todosDados = JSON.parse(fs.readFileSync(CAMINHO_RPG, "utf-8"));
    if (todosDados[numeroUsuario]) {
      return "ON";                                                         
    }
    return "OFF";
  } catch {
    return "OFF";
  }
}

// ✅ Conta grupos ativos                                                     
async function contarGruposAtivos(sock) {
  try {
    const todosGrupos = await sock.groupFetchAllParticipating();                   
    return Object.keys(todosGrupos).length;
  } catch (erro) {
    console.log("❌ Erro ao contar grupos:", erro.message);                        
    return "?";
  }
}

// 🔧 Carrega menu + substitui variáveis
async function carregarMenu(sock, menuId, remetente) {
  const numero = pegarNumero(remetente);
  const statusRPG = verificarStatusRPG(numero);
  const mencaoUsuario = `@${numero}`;
  
  // ✅ Verifica VIP AQUI
  const ehVip = verificarVip(remetente);
  const statusVipTexto = ehVip ? "SIM" : "NÃO";
                                                                                 
  const caminhoTxt = path.join(PASTA_MENUS, `${menuId}.txt`);
  let texto = "";

  if (fs.existsSync(caminhoTxt)) {
    texto = fs.readFileSync(caminhoTxt, "utf-8");
  } else {
    texto = `⚠️ Arquivo menus/${menuId}.txt não encontrado!`;
  }

  // ✅ Conta os grupos
  const qtdGrupos = await contarGruposAtivos(sock);                            
  
  // ✅ Substitui TODAS as variáveis
  texto = String(texto)
    .replace(/{BOT}|{NOME_BOT}/gi, NOME_BOT)
    .replace(/{DONO_NOME}|{DONONOME}/gi, DONO_NOME)
    .replace(/{DONO_NUMERO_VISIVEL}|{DONO_NUMERO}/gi, DONO_NUMERO_VISIVEL)
    .replace(/{USUARIO}/gi, numero)
    .replace(/@\{USUARIO\}/gi, mencaoUsuario)
    .replace(/{STATUS_RPG}/gi, statusRPG)
    .replace(/{PREFIXO}/gi, PREFIXO)
    .replace(/{GRUPOS_ATIVOS}/gi, qtdGrupos)
    .replace(/{VIP_STATUS}/gi, statusVipTexto); // ✅ VIP adicionado!
  
  let tipoMidia = null;
  let caminhoMidia = null;                                                       
  if (fs.existsSync(VIDEO_GLOBAL)) {
    tipoMidia = "video";
    caminhoMidia = VIDEO_GLOBAL;
  } else if (fs.existsSync(FOTO_GLOBAL)) {                                         
    tipoMidia = "image";
    caminhoMidia = FOTO_GLOBAL;
  }

  return { texto, tipoMidia, caminhoMidia, numero, remetente };
}                                                                              

// 📤 Envia menu com menção correta
async function enviarMenu(sock, idChat, remetente, menuId, quotedMsg) {
  if (!idChat || !remetente) return;
                                                                                 
  const { texto, tipoMidia, caminhoMidia } = await carregarMenu(sock, menuId, remetente);
  const jidMencao = remetente.includes("@") ? remetente : `${remetente}@s.whatsapp.net`;
                                                                                 
  try {
    if (tipoMidia === "video") {
      return await sock.sendMessage(idChat, {
        video: fs.readFileSync(caminhoMidia),
        caption: texto,
        gifPlayback: true,                                                            
        mentions: [jidMencao]
      }, { quoted: quotedMsg });                                                   
    } else if (tipoMidia === "image") {
      return await sock.sendMessage(idChat, {
        image: fs.readFileSync(caminhoMidia),                                          
        caption: texto,
        mentions: [jidMencao]
      }, { quoted: quotedMsg });                                                   
    } else {
      return await sock.sendMessage(idChat, {
        text: texto,
        mentions: [jidMencao]                                                        
      }, { quoted: quotedMsg });
    }
  } catch (erro) {
    console.log("❌ Erro ao enviar menu:", erro);
    return await sock.sendMessage(idChat, {
      text: texto || "✅ Menu carregado!",
      mentions: [jidMencao]
    }, { quoted: quotedMsg });
  }
}
                                                                               
module.exports = {
  comandos: {
    menu:          async (sock, msg, args, dados) => enviarMenu(sock, dados?.idChat || msg.key?.remoteJid, dados?.remetente || msg.key?.participant || msg.key?.remoteJid, "principal", msg),
    menuadm:       async (sock, msg, args, dados) => enviarMenu(sock, dados?.idChat || msg.key?.remoteJid, dados?.remetente || msg.key?.participant || msg.key?.remoteJid, "adm", msg),
    menurpg:       async (sock, msg, args, dados) => enviarMenu(sock, dados?.idChat || msg.key?.remoteJid, dados?.remetente || msg.key?.participant || msg.key?.remoteJid, "rpg", msg),
    menupesquisas: async (sock, msg, args, dados) => enviarMenu(sock, dados?.idChat || msg.key?.remoteJid, dados?.remetente || msg.key?.participant || msg.key?.remoteJid, "pesquisas", msg),
    menufig:       async (sock, msg, args, dados) => enviarMenu(sock, dados?.idChat || msg.key?.remoteJid, dados?.remetente || msg.key?.participant || msg.key?.remoteJid, "fig", msg),
    menudono:      async (sock, msg, args, dados) => enviarMenu(sock, dados?.idChat || msg.key?.remoteJid, dados?.remetente || msg.key?.participant || msg.key?.remoteJid, "dono", msg),
    menugame:      async (sock, msg, args, dados) => enviarMenu(sock, dados?.idChat || msg.key?.remoteJid, dados?.remetente || msg.key?.participant || msg.key?.remoteJid, "game", msg),
    menufamilia:   async (sock, msg, args, dados) => enviarMenu(sock, dados?.idChat || msg.key?.remoteJid, dados?.remetente || msg.key?.participant || msg.key?.remoteJid, "familia", msg),

    setmenu: async (sock, msg, args, dados) => {
      const idChat = dados?.idChat || msg.key?.remoteJid;                            
      const remetente = dados?.remetente || msg.key?.participant || msg.key?.remoteJid;

      if (!verificarDono(remetente)) return;
                                                                                     
      const citada = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      if (!citada) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Responda uma FOTO ou VÍDEO com:\n${PREFIXO}setmenu`
        }, { quoted: msg });
      }

      const { downloadMediaMessage } = require("@whiskeysockets/baileys");
      try {
        const buffer = await downloadMediaMessage(
          { key: msg.message.extendedTextMessage.contextInfo.stanzaId, message: citada },
          "buffer",
          {}
        );

        if (fs.existsSync(FOTO_GLOBAL)) fs.unlinkSync(FOTO_GLOBAL);
        if (fs.existsSync(VIDEO_GLOBAL)) fs.unlinkSync(VIDEO_GLOBAL);

        if (citada.videoMessage) {
          fs.writeFileSync(VIDEO_GLOBAL, buffer);
          return sock.sendMessage(idChat, { text: `✅ *VÍDEO DEFINIDO!* 🎥` }, { quoted: msg });
        } else {
          fs.writeFileSync(FOTO_GLOBAL, buffer);
          return sock.sendMessage(idChat, { text: `✅ *FOTO DEFINIDA!* 🖼️` }, { quoted: msg });
        }
      } catch {
        return sock.sendMessage(idChat, { text: `❌ Erro ao salvar mídia!` }, { quoted: msg });
      }
    },

    rm_midiamenu: async (sock, msg, args, dados) => {
      const idChat = dados?.idChat || msg.key?.remoteJid;
      const remetente = dados?.remetente || msg.key?.participant || msg.key?.remoteJid;

      if (!verificarDono(remetente)) return;

      let apagou = [];
      if (fs.existsSync(FOTO_GLOBAL)) { fs.unlinkSync(FOTO_GLOBAL); apagou.push("🖼️ Foto"); }
      if (fs.existsSync(VIDEO_GLOBAL)) { fs.unlinkSync(VIDEO_GLOBAL); apagou.push("🎥 Vídeo"); }

      if (apagou.length === 0) {
        return sock.sendMessage(idChat, { text: `ℹ️ Nenhuma mídia encontrada!` }, { quoted: msg });
      }
      return sock.sendMessage(idChat, { text: `✅ *MÍDIA REMOVIDA!* 🗑️\n\n${apagou.join(" e ")}` }, { quoted: msg });
    }
  }
};

