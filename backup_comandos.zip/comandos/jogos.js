const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const PREFIXO = config.prefixo || "!";
const NOME_BOT = config.nomeBot || "MoonBot-MDv1";
const CAMINHO_RPG = path.join(__dirname, "..", "dados", "rpg.json");
const CAMINHO_MENU_JOGOS = path.join(__dirname, "..", "menus", "menu_jogos.txt");
const CAMINHO_QUEMGANHA = path.join(__dirname, "..", "dados", "quemganha.json");

// ✅ Objetos de estado DECLARADOS AQUI, sem usar global
let rpgAtivoGlobal = true;
const partidasVelha = new Map();
const charadasAtivas = {};
const adedonhaAtiva = {};
const quemSouEuAtivo = {};
const palavraProibidaPorGrupo = {};
const quizAtivoPorUsuario = {};

// ==========================================
// 🆕 FUNÇÕES AUXILIARES NOVAS
// ==========================================
function garantirParesQuemGanha() {
  if (!fs.existsSync(path.dirname(CAMINHO_QUEMGANHA))) {
    fs.mkdirSync(path.dirname(CAMINHO_QUEMGANHA), { recursive: true });
  }
  if (!fs.existsSync(CAMINHO_QUEMGANHA)) {
    fs.writeFileSync(CAMINHO_QUEMGANHA, JSON.stringify([
      { vencedor: "britadeira", perdedor: "pedra" },
      { vencedor: "água", perdedor: "fogo" },
      { vencedor: "fogo", perdedor: "madeira" },
      { vencedor: "papel", perdedor: "pedra" },
      { vencedor: "martelo", perdedor: "vidro" }
    ], null, 2));
  }
}

function carregarParesQuemGanha() {
  garantirParesQuemGanha();
  try { return JSON.parse(fs.readFileSync(CAMINHO_QUEMGANHA, "utf-8")); }
  catch { return []; }
}

function salvarParesQuemGanha(pares) {
  fs.writeFileSync(CAMINHO_QUEMGANHA, JSON.stringify(pares, null, 2));
}

function quemVence(coisa1, coisa2) {
  const pares = carregarParesQuemGanha();
  const c1 = coisa1.toLowerCase().trim();
  const c2 = coisa2.toLowerCase().trim();

  if (c1 === c2) return { resultado: "empate", texto: `⚖️ ${coisa1} e ${coisa2} são iguais! Empate!` };

  const venceC1 = pares.find(p => p.vencedor.toLowerCase() === c1 && p.perdedor.toLowerCase() === c2);
  const venceC2 = pares.find(p => p.vencedor.toLowerCase() === c2 && p.perdedor.toLowerCase() === c1);

  if (venceC1) return { resultado: "vence1", texto: `💥 *${coisa1}* GANHA de *${coisa2}*!` };
  if (venceC2) return { resultado: "vence2", texto: `💥 *${coisa2}* GANHA de *${coisa1}*!` };
  return { resultado: "desconhecido", texto: `❓ Não sei quem ganha!\nUse: ${PREFIXO}adicionar ${coisa1} > ${coisa2}` };
}

function darMoedas(idUsuario, quantia) {
  const rpg = carregarJson(CAMINHO_RPG);
  const uid = idUsuario.split("@")[0];
  if (!rpg[uid]) rpg[uid] = criarJogador(uid);
  rpg[uid].moedas += quantia;
  salvarJson(CAMINHO_RPG, rpg);
  return rpg[uid].moedas;
}

// ==========================================
// FUNÇÕES EXISTENTES
// ==========================================
function carregarJson(caminho, padrao = {}) {
  try {
    if (!fs.existsSync(caminho)) return padrao;
    return JSON.parse(fs.readFileSync(caminho, "utf-8"));
  } catch { return padrao; }
}

function salvarJson(caminho, dados) {
  if (!fs.existsSync(path.dirname(caminho))) fs.mkdirSync(path.dirname(caminho), { recursive: true });
  fs.writeFileSync(caminho, JSON.stringify(dados, null, 2), "utf-8");
}

async function ehAdminGrupo(sock, idGrupo, idUsuario) {
  try {
    const meta = await sock.groupMetadata(idGrupo);
    return !!meta.participants.find(p => p.id === idUsuario && p.admin);
  } catch { return false; }
}

function criarJogador(idUsuario) {
  return {
    moedas: 100,
    jogosGanhamos: 0,
    jogosPerdidos: 0,
    jogosEmpatados: 0
  };
}

function verificarVencedor(tabuleiro) {
  const linhas = [
    [0,1,2],[3,4,5],[6,7,8],
    [0,3,6],[1,4,7],[2,5,8],
    [0,4,8],[2,4,6]
  ];
  for (const [a,b,c] of linhas) {
    if (tabuleiro[a] && tabuleiro[a] === tabuleiro[b] && tabuleiro[a] === tabuleiro[c]) {
      return tabuleiro[a];
    }
  }
  return null;
}

function tabuleiroTexto(tab) {
  const s = i => tab[i] || "⬜";
  return `┌───┬───┬───┐
│ ${s(0)} │ ${s(1)} │ ${s(2)} │
├───┼───┼───┤
│ ${s(3)} │ ${s(4)} │ ${s(5)} │
├───┼───┼───┤
│ ${s(6)} │ ${s(7)} │ ${s(8)} │
└───┴───┴───┘`;
}

function tabuleiroCompleto(partida) {
  const s = i => partida.tabuleiro[i] || (i + 1);
  return `╭━━━━━━━ 🎮 JOGO DA VELHA ━━━━━━━╮
┃
┃ ${partida.simbolo1} = @${partida.jogador1.split("@")[0]}
┃ ${partida.simbolo2} = ${partida.contraBot ? "🤖 BOT" : "@" + partida.jogador2.split("@")[0]}
┃
┃ ${s(0)} │ ${s(1)} │ ${s(2)}
┃───┼───┼───
┃ ${s(3)} │ ${s(4)} │ ${s(5)}
┃───┼───┼───
┃ ${s(6)} │ ${s(7)} │ ${s(8)}
┃
┃ 📌 Vez de: ${partida.turno === "bot" ? "🤖 BOT" : "@" + partida.turno.split("@")[0]}
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯`;
}

function jogadaBot(partida) {
  for (let i = 0; i < 9; i++) {
    if (partida.tabuleiro[i] === null) {
      partida.tabuleiro[i] = partida.simbolo2;
      if (verificarVencedor(partida.tabuleiro)) return;
      partida.tabuleiro[i] = null;
    }
  }
  for (let i = 0; i < 9; i++) {
    if (partida.tabuleiro[i] === null) {
      partida.tabuleiro[i] = partida.simbolo1;
      if (verificarVencedor(partida.tabuleiro)) {
        partida.tabuleiro[i] = partida.simbolo2;
        return;
      }
      partida.tabuleiro[i] = null;
    }
  }
  if (partida.tabuleiro[4] === null) {
    partida.tabuleiro[4] = partida.simbolo2;
    return;
  }
  const cantos = [0,2,6,8].filter(i => partida.tabuleiro[i] === null);
  if (cantos.length) {
    partida.tabuleiro[cantos[Math.floor(Math.random() * cantos.length)]] = partida.simbolo2;
    return;
  }
  const laterais = [1,3,5,7].filter(i => partida.tabuleiro[i] === null);
  if (laterais.length) {
    partida.tabuleiro[laterais[Math.floor(Math.random() * laterais.length)]] = partida.simbolo2;
  }
}

// ==========================================
// 📦 EXPORTAÇÃO PRINCIPAL
// ==========================================
module.exports = {
  nome: "jogos",

  // 🆕 FUNÇÕES DE VERIFICAÇÃO PARA O index.js
  verificarMensagemExtra: async function(sock, idChat, remetente, texto) {
    if (!texto || texto.startsWith(PREFIXO)) return false;

    // ✅ Quiz
    const quiz = quizAtivoPorUsuario[remetente];
    if (quiz && !quiz.respondido) {
      const resp = texto.trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
      const correto = quiz.respostas.some(r => 
        resp === r.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
      );
      if (correto) {
        quiz.respondido = true;
        const saldo = darMoedas(remetente, 20);
        delete quizAtivoPorUsuario[remetente];
        await sock.sendMessage(idChat, {
          text: `🎉 *ACERTOU!* ✅\n💰 +20 moedas!\n💵 Saldo: ${saldo} moedas`,
          mentions: [remetente]
        });
        return true;
      }
    }

    // 🚫 Palavra Proibida
    const proibida = palavraProibidaPorGrupo[idChat];
    if (proibida) {
      const limpo = texto.toLowerCase().trim();
      if (limpo.includes(proibida.palavra.toLowerCase())) {
        const numero = remetente.split("@")[0];
        await sock.sendMessage(idChat, {
          text: `🤭 @${numero} FALOU A PALAVRA PROIBIDA! 😂\nA palavra era: "${proibida.palavra}"`,
          mentions: [remetente]
        });
        delete palavraProibidaPorGrupo[idChat];
        return true;
      }
    }

    return false;
  },

  comandos: {
    // ==========================================
    // 📋 MENU (ATUALIZADO COM OS NOVOS JOGOS)
    // ==========================================
    menugame: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const mencao = "@" + remetente.split("@")[0];

      let menuTexto = fs.existsSync(CAMINHO_MENU_JOGOS)
        ? fs.readFileSync(CAMINHO_MENU_JOGOS, "utf-8")
        : `╭━━━━━━━━━━ 🎮 MENU DE JOGOS ━━━━━━━━━━╮
┃
┃ 🤖 Bot: ${NOME_BOT}
┃ 👤 Jogador: ${mencao}
┃ ───────────────────────────────
┃ 📊 STATUS
┃ ✏️ ${PREFIXO}saldo
┃ ✏️ ${PREFIXO}rpg on/off
┃
┃ 🎯 JOGOS DISPONÍVEIS
┃ ✏️ ${PREFIXO}charada
┃ ✏️ ${PREFIXO}velha @usuario
┃ ✏️ ${PREFIXO}adedonha
┃ ✏️ ${PREFIXO}ppt pedra/papel/tesoura
┃ ✏️ ${PREFIXO}quemsoueu
┃ ✏️ ${PREFIXO}quemganha coisa1 coisa2
┃ ✏️ ${PREFIXO}adicionar vencedor > perdedor
┃ ✏️ ${PREFIXO}quiz
┃ ✏️ ${PREFIXO}palavraproibida palavra
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯`;

      await sock.sendMessage(idChat, { text: menuTexto, mentions: [remetente] });
    },

    // ==========================================
    // ⚔️ NOVO: QUEM GANHA DE QUEM?
    // ==========================================
    quemganha: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!rpgAtivoGlobal) return await sock.sendMessage(idChat, { text: `🔒 *JOGOS DESATIVADOS!*\nUse: ${PREFIXO}rpg on` });

      if (args.length < 2) {
        return await sock.sendMessage(idChat, {
          text: `📖 Use: ${PREFIXO}quemganha <coisa1> <coisa2>\nExemplo: ${PREFIXO}quemganha britadeira pedra`
        });
      }

      const coisa1 = args[0];
      const coisa2 = args[1];
      const resultado = quemVence(coisa1, coisa2);

      if (resultado.resultado !== "desconhecido" && resultado.resultado !== "empate") {
        const saldo = darMoedas(remetente, 10);
        await sock.sendMessage(idChat, {
          text: `${resultado.texto}\n\n💰 Você ganhou 10 moedas!\n💵 Saldo: ${saldo} moedas`
        });
      } else {
        await sock.sendMessage(idChat, { text: resultado.texto });
      }
    },

    adicionar: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const texto = args.join(" ");

      if (!await ehAdminGrupo(sock, idChat, remetente)) {
        return await sock.sendMessage(idChat, { text: `⚠️ Apenas administradores podem adicionar regras!` });
      }

      if (!texto.includes(">")) {
        return await sock.sendMessage(idChat, {
          text: `📖 Use: ${PREFIXO}adicionar <vencedor> > <perdedor>\nExemplo: ${PREFIXO}adicionar água > fogo`
        });
      }

      const [vencedor, perdedor] = texto.split(">").map(s => s.trim());
      if (!vencedor || !perdedor) {
        return await sock.sendMessage(idChat, { text: `❌ Formato inválido!` });
      }

      const pares = carregarParesQuemGanha();
      const existe = pares.find(p => 
        p.vencedor.toLowerCase() === vencedor.toLowerCase() && 
        p.perdedor.toLowerCase() === perdedor.toLowerCase()
      );
      if (existe) {
        return await sock.sendMessage(idChat, { text: `⚠️ Esse par já existe!` });
      }

      pares.push({ vencedor, perdedor });
      salvarParesQuemGanha(pares);

      await sock.sendMessage(idChat, {
        text: `✅ Regra adicionada!\n💥 ${vencedor} > ${perdedor}`
      });
    },

    // ==========================================
    // ❓ NOVO: QUIZ
    // ==========================================
    quiz: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!rpgAtivoGlobal) return await sock.sendMessage(idChat, { text: `🔒 *JOGOS DESATIVADOS!*\nUse: ${PREFIXO}rpg on` });

      const perguntas = [
        { p: "Qual é o maior planeta do sistema solar?", r: ["júpiter", "jupiter"] },
        { p: "Quantos dias tem um ano bissexto?", r: ["366"] },
        { p: "Qual é o símbolo químico da água?", r: ["h2o", "h₂o"] },
        { p: "Quantas cores tem um arco-íris?", r: ["7", "sete"] },
        { p: "Qual animal é conhecido como rei dos animais?", r: ["leão", "leoa"] },
        { p: "Qual é a capital do Brasil?", r: ["brasília", "brasilia"] },
        { p: "Quantos graus tem um ângulo reto?", r: ["90", "noventa"] }
      ];

      const sorteada = perguntas[Math.floor(Math.random() * perguntas.length)];
      quizAtivoPorUsuario[remetente] = {
        pergunta: sorteada.p,
        respostas: sorteada.r,
        respondido: false
      };

      await sock.sendMessage(idChat, {
        text: `❓ *QUIZ*\n\n${sorteada.p}\n\n💡 Responda direto aqui!\n💰 +20 moedas se acertar!`
      });
    },

    // ==========================================
    // 🚫 NOVO: PALAVRA PROIBIDA
    // ==========================================
    palavraproibida: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const palavra = args.join(" ");
      if (!rpgAtivoGlobal) return await sock.sendMessage(idChat, { text: `🔒 *JOGOS DESATIVADOS!*\nUse: ${PREFIXO}rpg on` });

      if (!palavra) {
        return await sock.sendMessage(idChat, {
          text: `📖 Use: ${PREFIXO}palavraproibida <palavra>\nExemplo: ${PREFIXO}palavraproibida banana`
        });
      }

      palavraProibidaPorGrupo[idChat] = {
        palavra: palavra.toLowerCase(),
        criador: remetente
      };

      await sock.sendMessage(idChat, {
        text: `🚫 *PALAVRA PROIBIDA ATIVADA!*\n\nNinguém pode falar: *"${palavra}"*\nAquele que falar perde! 😂`
      });
    },

    parar_palavraproibida: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!palavraProibidaPorGrupo[idChat]) {
        return await sock.sendMessage(idChat, { text: `⚠️ Nenhum jogo de palavra proibida em andamento!` });
      }
      delete palavraProibidaPorGrupo[idChat];
      await sock.sendMessage(idChat, { text: `✅ Jogo de palavra proibida encerrado!` });
    },

    // ==========================================
    // 📌 JOGOS ORIGINAIS (mantidos intactos)
    // ==========================================
    charada: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!rpgAtivoGlobal) return await sock.sendMessage(idChat, { text: `🔒 *JOGOS DESATIVADOS!*\nUse: ${PREFIXO}rpg on` });

      const lista = [
        { p: "O que é, o que é? Tem cabeça, tem rabo, mas não tem corpo?", r: "moeda" },
        { p: "O que é branco, cabe num copo mas não cabe dentro dele?", r: "água" },
        { p: "Quanto mais se tira, maior fica. O que é?", r: "buraco" },
        { p: "Tem pernas mas não anda, tem braços mas não abraça. O que é?", r: "cadeira" }
      ];
      const escolhida = lista[Math.floor(Math.random() * lista.length)];
      charadasAtivas[idChat] = { pergunta: escolhida.p, resposta: escolhida.r, quemAcertou: null };

      await sock.sendMessage(idChat, { text: `🧠 *CHARADA!*\n\n${escolhida.p}\n\n💡 Responda aqui! Ganha 25 moedas!` });
    },

    verificarRespostaCharada: async function(sock, idChat, remetente, texto) {
      const partida = charadasAtivas[idChat];
      if (!partida || partida.quemAcertou) return false;

      const limpar = t => t.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
      if (limpar(texto) === limpar(partida.resposta) || limpar(texto).includes(limpar(partida.resposta))) {
        partida.quemAcertou = remetente;
        delete charadasAtivas[idChat];
        const idUser = remetente.split("@")[0];
        const rpg = carregarJson(CAMINHO_RPG);
        if (!rpg[idUser]) rpg[idUser] = criarJogador(idUser);
        rpg[idUser].moedas += 25;
        rpg[idUser].jogosGanhamos++;
        salvarJson(CAMINHO_RPG, rpg);
        await sock.sendMessage(idChat, { text: `🎉 *ACERTOU, @${idUser}!*\nA resposta era: *${partida.resposta}*\n💰 +25 moedas!`, mentions: [remetente] });
        return true;
      }
      return false;
    },

    resposta: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const partida = charadasAtivas[idChat];
      if (!partida) return await sock.sendMessage(idChat, { text: `⚠️ Não há charada rolando!` });
      delete charadasAtivas[idChat];
      await sock.sendMessage(idChat, { text: `❓ A resposta era: *${partida.resposta}*\nQuer jogar de novo? Use ${PREFIXO}charada` });
    },

    saldo: async (sock, msg, args, dados) => {
      const remetente = msg.key.participant || msg.key.remoteJid;
      const idChat = msg.key.remoteJid;
      const idUser = remetente.split("@")[0];
      const rpg = carregarJson(CAMINHO_RPG);
      if (!rpg[idUser]) rpg[idUser] = criarJogador(idUser);
      salvarJson(CAMINHO_RPG, rpg);

      await sock.sendMessage(idChat, {
        text: `💰 *SEU SALDO*\n\n👤 Usuário: @${idUser}\n🪙 Moedas: ${rpg[idUser].moedas}\n🏆 Vitórias: ${rpg[idUser].jogosGanhamos}\n💀 Derrotas: ${rpg[idUser].jogosPerdidos}\n🤝 Empates: ${rpg[idUser].jogosEmpatados}`,
        mentions: [remetente]
      });
    },

    rpg: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const opcao = (args[0] || "").toLowerCase();
      if (opcao === "on") {
        rpgAtivoGlobal = true;
        await sock.sendMessage(idChat, { text: `✅ *RPG/JOGOS ATIVADO!*\nTodos os jogos liberados!` });
      } else if (opcao === "off") {
        rpgAtivoGlobal = false;
        await sock.sendMessage(idChat, { text: `❌ *RPG/JOGOS DESATIVADO!*` });
      } else {
        await sock.sendMessage(idChat, { text: `⚙️ *SISTEMA RPG*\nAtivo: ${rpgAtivoGlobal ? "✅ Sim" : "❌ Não"}\n\n${PREFIXO}rpg on / off` });
      }
    },

    velha: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!rpgAtivoGlobal) return await sock.sendMessage(idChat, { text: `🔒 *JOGOS DESATIVADOS!*\nUse: ${PREFIXO}rpg on` });
      if (partidasVelha.has(idChat)) return await sock.sendMessage(idChat, { text: `⚠️ Já existe uma partida! Use ${PREFIXO}cancelar_velha` });

      const citado = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
      const contraBot = !citado || citado === remetente;
      const adversario = contraBot ? "bot" : citado;

      const partida = {
        jogador1: remetente,
        jogador2: adversario,
        contraBot,
        turno: remetente,
        tabuleiro: Array(9).fill(null),
        simbolo1: "❌",
        simbolo2: "⭕"
      };
      partidasVelha.set(idChat, partida);

      await sock.sendMessage(idChat, {
        text: tabuleiroCompleto(partida),
        mentions: contraBot ? [remetente] : [remetente, adversario]
      });
    },

    cancelar_velha: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const partida = partidasVelha.get(idChat);
      if (!partida) return await sock.sendMessage(idChat, { text: `⚠️ Nenhuma partida em andamento!` });

      const ehDono = partida.jogador1 === remetente || partida.jogador2 === remetente;
      const ehAdmin = await ehAdminGrupo(sock, idChat, remetente);
      if (!ehDono && !ehAdmin) return await sock.sendMessage(idChat, { text: `⚠️ Só os jogadores ou admin podem cancelar!` });

      partidasVelha.delete(idChat);
      await sock.sendMessage(idChat, { text: `🚫 Partida cancelada por @${remetente.split("@")[0]}`, mentions: [remetente] });
    },

    jogadaVelha: async function(sock, idChat, remetente, posicao) {
      const partida = partidasVelha.get(idChat);
      if (!partida) return false;
      if (partida.turno !== remetente) return true;

      const indice = posicao - 1;
      if (partida.tabuleiro[indice] !== null) {
        await sock.sendMessage(idChat, { text: `⚠️ Essa posição já está ocupada!` });
        return true;
      }

      partida.tabuleiro[indice] = partida.turno === partida.jogador1 ? partida.simbolo1 : partida.simbolo2;
      const vencedor = verificarVencedor(partida.tabuleiro);
      const empate = !vencedor && partida.tabuleiro.every(c => c !== null);

      if (vencedor) {
        const idVenc = vencedor === partida.simbolo1 ? partida.jogador1 : partida.jogador2;
        const idPerd = vencedor === partida.simbolo1 ? partida.jogador2 : partida.jogador1;
        partidasVelha.delete(idChat);

        const rpg = carregarJson(CAMINHO_RPG);
        if (idVenc !== "bot") {
          const uid = idVenc.split("@")[0];
          if (!rpg[uid]) rpg[uid] = criarJogador(uid);
          rpg[uid].moedas += 50;
          rpg[uid].jogosGanhamos++;
        }
        if (idPerd !== "bot") {
          const uid = idPerd.split("@")[0];
          if (!rpg[uid]) rpg[uid] = criarJogador(uid);
          rpg[uid].jogosPerdidos++;
        }
        salvarJson(CAMINHO_RPG, rpg);

        await sock.sendMessage(idChat, {
          text: `🏆 *TEMOS UM VENCEDOR!*\n\n${tabuleiroTexto(partida.tabuleiro)}\n\n🎉 Parabéns @${idVenc === "bot" ? "🤖 BOT" : idVenc.split("@")[0]}! +50 moedas!`,
          mentions: idVenc === "bot" ? [] : [idVenc]
        });
        return true;
      }

      if (empate) {
        partidasVelha.delete(idChat);
        await sock.sendMessage(idChat, { text: `🤝 *DEU VELHA!*\n\n${tabuleiroTexto(partida.tabuleiro)}` });
        return true;
      }

      partida.turno = partida.turno === partida.jogador1 ? partida.jogador2 : partida.jogador1;

      if (partida.contraBot && partida.turno === "bot") {
        await sock.sendMessage(idChat, { text: tabuleiroCompleto(partida) });
        await new Promise(r => setTimeout(r, 800));
        jogadaBot(partida);

        const vBot = verificarVencedor(partida.tabuleiro);
        const empBot = !vBot && partida.tabuleiro.every(c => c !== null);

        if (vBot) {
          const idVenc = vBot === partida.simbolo1 ? partida.jogador1 : partida.jogador2;
          const idPerd = vBot === partida.simbolo1 ? partida.jogador2 : partida.jogador1;
          partidasVelha.delete(idChat);
          const rpg = carregarJson(CAMINHO_RPG);
          if (idVenc !== "bot") {
            const uid = idVenc.split("@")[0];
            if (!rpg[uid]) rpg[uid] = criarJogador(uid);
            rpg[uid].moedas += 50;
            rpg[uid].jogosGanhamos++;
          }
          if (idPerd !== "bot") {
            const uid = idPerd.split("@")[0];
            if (!rpg[uid]) rpg[uid] = criarJogador(uid);
            rpg[uid].jogosPerdidos++;
          }
          salvarJson(CAMINHO_RPG, rpg);

          await sock.sendMessage(idChat, {
            text: `🏆 *TEMOS UM VENCEDOR!*\n\n${tabuleiroTexto(partida.tabuleiro)}\n\n🎉 @${idVenc === "bot" ? "🤖 BOT" : idVenc.split("@")[0]} venceu!`,
            mentions: idVenc === "bot" ? [] : [idVenc]
          });
          return true;
        }

        if (empBot) {
          partidasVelha.delete(idChat);
          await sock.sendMessage(idChat, { text: `🤝 *DEU VELHA!*\n\n${tabuleiroTexto(partida.tabuleiro)}` });
          return true;
        }
        partida.turno = partida.jogador1;
      }

      await sock.sendMessage(idChat, {
        text: tabuleiroCompleto(partida),
        mentions: partida.turno === "bot" ? [] : [partida.turno]
      });
      return true;
    },

    adedonha: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!rpgAtivoGlobal) return await sock.sendMessage(idChat, { text: `🔒 *JOGOS DESATIVADOS!*\nUse: ${PREFIXO}rpg on` });
      if (adedonhaAtiva[idChat]) return await sock.sendMessage(idChat, { text: `⚠️ Já tem uma adedonha rolando! Use ${PREFIXO}parar_adedonha` });

      const letras = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
      const letra = letras[Math.floor(Math.random() * letras.length)];
      adedonhaAtiva[idChat] = { letra, palavras: {}, tempo: Date.now() };

      await sock.sendMessage(idChat, {
        text: `📝 *ADEDONHA!*\n\n🔤 Letra: *${letra}*\n⏳ Você tem 3 minutos!\n💰 Cada palavra = 50 moedas!\n\nMande palavras que comecem com a letra!`
      });

      setTimeout(async () => {
        const partida = adedonhaAtiva[idChat];
        if (!partida) return;
        delete adedonhaAtiva[idChat];

        const rpg = carregarJson(CAMINHO_RPG);
        let resultado = `⏰ *TEMPO ESGOTADO!*\n🔤 Letra: ${partida.letra}\n📊 Resultados:\n\n`;

        for (const [user, qtd] of Object.entries(partida.palavras)) {
          const uid = user.split("@")[0];
          if (!rpg[uid]) rpg[uid] = criarJogador(uid);
          rpg[uid].moedas += qtd * 50;
          resultado += `👤 @${uid}: ${qtd} palavra(s) → +${qtd * 50} moedas\n`;
        }
        salvarJson(CAMINHO_RPG, rpg);

        await sock.sendMessage(idChat, { text: resultado, mentions: Object.keys(partida.palavras) });
      }, 180000);
    },

    parar_adedonha: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!adedonhaAtiva[idChat]) return await sock.sendMessage(idChat, { text: `⚠️ Nenhuma adedonha em andamento!` });
      if (!await ehAdminGrupo(sock, idChat, remetente)) return await sock.sendMessage(idChat, { text: `⚠️ Apenas administradores podem parar!` });

      delete adedonhaAtiva[idChat];
      await sock.sendMessage(idChat, { text: `🚫 Adedonha encerrada por @${remetente.split("@")[0]}`, mentions: [remetente] });
    },

    verificarRespostaAdedonha: async function(sock, idChat, remetente, texto) {
      const partida = adedonhaAtiva[idChat];
      if (!partida) return false;
      const palavra = texto.trim().toUpperCase();
      if (!palavra.startsWith(partida.letra) || palavra.length < 2) return false;

      if (!partida.palavras[remetente]) partida.palavras[remetente] = 0;
      partida.palavras[remetente]++;

      await sock.sendMessage(idChat, {
        text: `✅ *Palavra válida!* "${palavra}" ✅\n💰 +50 moedas!\nContinue mandando palavras com a letra ${partida.letra}!`,
        mentions: [remetente]
      });
      return true;
    },

    ppt: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      if (!rpgAtivoGlobal) return await sock.sendMessage(idChat, { text: `🔒 *JOGOS DESATIVADOS!*\nUse: ${PREFIXO}rpg on` });

      const opcoes = ["pedra", "papel", "tesoura"];
      const escolhaUser = (args[0] || "").toLowerCase();
      if (!opcoes.includes(escolhaUser)) {
        return await sock.sendMessage(idChat, {
          text: `✊✋✌️ *PEDRA, PAPEL OU TESOURA!*\n\nEscolha:\n${PREFIXO}ppt pedra\n${PREFIXO}ppt papel\n${PREFIXO}ppt tesoura`
        });
      }

      const escolhaBot = opcoes[Math.floor(Math.random() * opcoes.length)];
      let resultado, ganhou = false;

      if (escolhaUser === escolhaBot) {
        resultado = `🤝 *EMPATE!*\nVocê: ${escolhaUser}\nBot: ${escolhaBot}`;
      } else if (
        (escolhaUser === "pedra" && escolhaBot === "tesoura") ||
        (escolhaUser === "papel" && escolhaBot === "pedra") ||
        (escolhaUser === "tesoura" && escolhaBot === "papel")
      ) {
        resultado = `🎉 *VOCÊ GANHOU!*\nVocê: ${escolhaUser}\nBot: ${escolhaBot}\n💰 +20 moedas!`;
        ganhou = true;
      } else {
        resultado = `😢 *VOCÊ PERDEU!*\nVocê: ${escolhaUser}\nBot: ${escolhaBot}`;
      }

      const uid = remetente.split("@")[0];
      const rpg = carregarJson(CAMINHO_RPG);
      if (!rpg[uid]) rpg[uid] = criarJogador(uid);
      if (ganhou) {
        rpg[uid].moedas += 20;
        rpg[uid].jogosGanhamos++;
      } else {
        rpg[uid].jogosPerdidos++;
      }
      salvarJson(CAMINHO_RPG, rpg);

      await sock.sendMessage(idChat, { text: resultado, mentions: [remetente] });
    },

    quemsoueu: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!rpgAtivoGlobal) return await sock.sendMessage(idChat, { text: `🔒 *JOGOS DESATIVADOS!*\nUse: ${PREFIXO}rpg on` });
      if (quemSouEuAtivo[idChat]) return await sock.sendMessage(idChat, { text: `⚠️ Já tem um jogo rolando! Use ${PREFIXO}resposta_qse` });

      const itens = [
        { nome: "pizza", dicas: ["Sou redonda e gostosa", "Tenho queijo e molho de tomate", "Sou assada no forno"] },
        { nome: "chocolate", dicas: ["Sou doce e marrom", "Derreto na boca", "Feito de cacau"] },
        { nome: "relógio", dicas: ["Tenho ponteiros mas não tenho mãos", "Meus números vão de 1 a 12", "Marco as horas"] }
      ];
      const escolhido = itens[Math.floor(Math.random() * itens.length)];
      quemSouEuAtivo[idChat] = { nome: escolhido.nome.toLowerCase(), dicas: escolhido.dicas, dicaAtual: 0, acertou: null };

      await sock.sendMessage(idChat, {
        text: `🕵️ *QUEM SOU EU?*\n\n💡 Dica 1: ${escolhido.dicas[0]}\n\nResponda com o nome!\n💰 +30 moedas se acertar!\nMais dica: ${PREFIXO}mais_dica`
      });
    },

    mais_dica: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const partida = quemSouEuAtivo[idChat];
      if (!partida) return await sock.sendMessage(idChat, { text: `⚠️ Nenhum jogo em andamento! Use ${PREFIXO}quemsoueu` });

      partida.dicaAtual++;
      if (partida.dicaAtual >= partida.dicas.length) {
        return await sock.sendMessage(idChat, { text: `⚠️ Não tenho mais dicas! Tente adivinhar!` });
      }
      await sock.sendMessage(idChat, { text: `💡 *Dica ${partida.dicaAtual + 1}:* ${partida.dicas[partida.dicaAtual]}` });
    },

    resposta_qse: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const partida = quemSouEuAtivo[idChat];
      if (!partida) return await sock.sendMessage(idChat, { text: `⚠️ Nenhum jogo em andamento!` });
      delete quemSouEuAtivo[idChat];
      await sock.sendMessage(idChat, { text: `❓ A resposta era: *${partida.nome}*\nQuer jogar de novo? Use ${PREFIXO}quemsoueu` });
    },

    verificarRespostaQuemSouEu: async function(sock, idChat, remetente, texto) {
      const partida = quemSouEuAtivo[idChat];
      if (!partida || partida.acertou) return false;
      const resposta = texto.trim().toLowerCase();
      if (resposta === partida.nome) {
        partida.acertou = remetente;
        delete quemSouEuAtivo[idChat];
        const uid = remetente.split("@")[0];
        const rpg = carregarJson(CAMINHO_RPG);
        if (!rpg[uid]) rpg[uid] = criarJogador(uid);
        rpg[uid].moedas += 30;
        rpg[uid].jogosGanhamos++;
        salvarJson(CAMINHO_RPG, rpg);
        await sock.sendMessage(idChat, {
          text: `🎉 *ACERTOU, @${uid}!*\nA resposta era: *${partida.nome}*\n💰 +30 moedas!`,
          mentions: [remetente]
        });
        return true;
      }
      return false;
    }
  }
};

