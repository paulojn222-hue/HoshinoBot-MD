const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const PREFIXO = config.prefixo || "!";
const NOME_BOT = config.nomeBot || "MoonBot-MD";
const CAMINHO_MENU = path.join(__dirname, "..", "menus", "menu_rpg.txt");
const CAMINHO_FOTO_MENU = path.join(__dirname, "..", "midias", "foto_menu_rpg.jpg"); // ← pode trocar

module.exports = {
  comandos: {
    menurpg: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const numero = remetente.split("@")[0];

      // 📝 Lê o arquivo de texto
      let texto = "";
      if (fs.existsSync(CAMINHO_MENU)) {
        texto = fs.readFileSync(CAMINHO_MENU, "utf-8");
      } else {
        texto = `╭━━━━━━━━━━ 💰 MENU RPG 💰 ━━━━━━━━━━╮
┃
┃ 👤 Usuário: @{USUARIO}
┃ 🤖 Bot: {NOME_BOT}
┃ 🔖 Prefixo: {PREFIXO}
┃
┃ 💼 !trabalhar
┃ ⛓️ !crime
┃ 🎣 !pescar
┃ ⛏️ !minerar
┃ 😈 !roubar @user
┃ 📊 !investir
┃ 💰 !saldo
┃ 🏆 !rank
┃ 🛒 !loja
┃ 📦 !inventario
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯`;
      }

      // 🔄 Troca as variáveis
      texto = texto
        .replace(/{USUARIO}/g, numero)
        .replace(/{NOME_BOT}/g, NOME_BOT)
        .replace(/{PREFIXO}/g, PREFIXO);

      // 🖼️ Verifica se tem imagem
      if (fs.existsSync(CAMINHO_FOTO_MENU)) {
        return sock.sendMessage(idChat, {
          image: fs.readFileSync(CAMINHO_FOTO_MENU),
          caption: texto,
          mentions: [remetente]
        }, { quoted: msg });
      } else {
        return sock.sendMessage(idChat, {
          text: texto,
          mentions: [remetente]
        }, { quoted: msg });
      }
    }
  }
};

