const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const PREFIXO = config.prefixo || "!";
const NOME_BOT = config.nomeBot || "MoonBot-MD";
const CAMINHO_RPG = path.join(__dirname, "..", "dados", "rpg.json");

// 📖 Carrega/Salva dados
function carregarRPG() {
  try {
    if (!fs.existsSync(CAMINHO_RPG)) return {};
    return JSON.parse(fs.readFileSync(CAMINHO_RPG, "utf-8"));
  } catch { return {}; }
}
function salvarRPG(dados) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify(dados, null, 2));
}

// 💍 Pedidos de casamento pendentes
const pedidosCasamento = {};

// 🔤 Formata o número para exibição (remove sufixos do LID)
function formatarUsuario(jid) {
  if (!jid) return "Desconhecido";
  return jid.split("@")[0].split(":")[0];
}

module.exports = {
  comandos: {
    menufamilia: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;

      const textoMenu = `👨‍👩‍👧‍👦 ════════════════════════════
           👨‍👩‍👧‍👦 SISTEMA DE FAMÍLIA 👨‍👩‍👧‍👦
═══════════════════════════════════

💍 𝗖𝗔𝗦𝗔𝗠𝗘𝗡𝗧𝗢 💍
───────────────────────────────────
💑 ${PREFIXO}casar @usuário
   → Pedir alguém em casamento

✅ ${PREFIXO}aceitar_casar
   → Aceitar pedido de casamento recebido

💔 ${PREFIXO}divorciar
   → Se divorciar (desfaz o casamento)

👶 𝗙𝗔𝗠𝗜́𝗟𝗜𝗔 👶
───────────────────────────────────
👨‍👩‍👧 ${PREFIXO}adotar @usuário
   → Adotar alguém como filho(a)
   ⚠️ Precisa estar casado(a) primeiro!

😢 ${PREFIXO}deserdar @usuário
   → Remover filho(a) da família

👨‍👩‍👧‍👦 ${PREFIXO}família
   → Ver sua família completa

═══════════════════════════════════
🤖 Bot: ${NOME_BOT}
🔹 Prefixo: ${PREFIXO}
═══════════════════════════════════`;

      // 📸 Tenta mandar com imagem, senão vídeo, senão só texto
      const caminhoImagem = path.join(__dirname, "..", "midias", "menu_familia.jpg");
      const caminhoVideo = path.join(__dirname, "..", "midias", "menu_familia.mp4");

      try {
        if (fs.existsSync(caminhoImagem)) {
          await sock.sendMessage(idChat, {
            image: { url: caminhoImagem },
            caption: textoMenu
          }, { quoted: msg });
        } else if (fs.existsSync(caminhoVideo)) {
          await sock.sendMessage(idChat, {
            video: { url: caminhoVideo },
            caption: textoMenu,
            gifPlayback: false
          }, { quoted: msg });
        } else {
          await sock.sendMessage(idChat, { text: textoMenu }, { quoted: msg });
        }
      } catch {
        await sock.sendMessage(idChat, { text: textoMenu }, { quoted: msg });
      }
    },

    casar: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const mencionados = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];

      if (mencionados.length === 0) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Mencione a pessoa com quem quer se casar!\nExemplo: ${PREFIXO}casar @nome`
        }, { quoted: msg });
      }

      const alvo = mencionados[0];
      if (alvo === remetente) {
        return sock.sendMessage(idChat, { text: `🤦 Você não pode se casar com você mesmo!` }, { quoted: msg });
      }

      const rpg = carregarRPG();

      // ⚠️ Verifica se já são casados
      if (rpg[remetente]?.conjuge === alvo) {
        return sock.sendMessage(idChat, { text: `💑 Vocês já são casados!` }, { quoted: msg });
      }

      // ⚠️ Verifica se algum já é casado com outra pessoa
      if ((rpg[remetente]?.conjuge && rpg[remetente].conjuge !== alvo) ||
          (rpg[alvo]?.conjuge && rpg[alvo].conjuge !== remetente)) {
        return sock.sendMessage(idChat, { text: `⚠️ Um dos dois já é casado! Faça o divórcio primeiro.` }, { quoted: msg });
      }

      // 💍 Salva o pedido pendente
      pedidosCasamento[alvo] = { remetente, data: Date.now() };

      await sock.sendMessage(idChat, {
        text: `💍 *PEDIDO DE CASAMENTO* 💍

@${formatarUsuario(remetente)} quer se casar com @${formatarUsuario(alvo)}!

💌 Responda com:
→ ${PREFIXO}aceitar_casar  — Aceitar
→ Ignorar ou não responder — Recusar`,
        mentions: [remetente, alvo]
      }, { quoted: msg });
    },

    aceitar_casar: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const pedido = pedidosCasamento[remetente];

      if (!pedido) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Você não tem nenhum pedido de casamento pendente!`
        }, { quoted: msg });
      }

      const rpg = carregarRPG();
      const { remetente: parceiro } = pedido;

      // ✅ Casa os dois
      if (!rpg[remetente]) rpg[remetente] = { moedas: 0, filhos: [] };
      if (!rpg[parceiro]) rpg[parceiro] = { moedas: 0, filhos: [] };

      rpg[remetente].conjuge = parceiro;
      rpg[parceiro].conjuge = remetente;

      delete pedidosCasamento[remetente];
      salvarRPG(rpg);

      await sock.sendMessage(idChat, {
        text: `💒 *CASAMENTO REALIZADO!* 💒

💑 @${formatarUsuario(parceiro)} ❤️ @${formatarUsuario(remetente)}

Agora vocês são uma família! Use ${PREFIXO}adotar para adicionar filhos!`,
        mentions: [remetente, parceiro]
      }, { quoted: msg });
    },

    divorciar: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const rpg = carregarRPG();
      const usuario = rpg[remetente];

      if (!usuario?.conjuge) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Você não está casado(a)!`
        }, { quoted: msg });
      }

      const conjuge = usuario.conjuge;
      usuario.conjuge = null;
      if (rpg[conjuge]) rpg[conjuge].conjuge = null;

      salvarRPG(rpg);

      await sock.sendMessage(idChat, {
        text: `💔 *DIVÓRCIO* 💔

Você e @${formatarUsuario(conjuge)} não são mais casados.`,
        mentions: [conjuge]
      }, { quoted: msg });
    },

    adotar: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const mencionados = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];

      if (mencionados.length === 0) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Mencione quem deseja adotar!\nExemplo: ${PREFIXO}adotar @filho`
        }, { quoted: msg });
      }

      const filho = mencionados[0];
      const rpg = carregarRPG();
      const usuario = rpg[remetente];

      if (!usuario?.conjuge) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Você precisa estar casado(a) para adotar! Use ${PREFIXO}casar primeiro.`
        }, { quoted: msg });
      }

      if (!usuario.filhos) usuario.filhos = [];

      if (usuario.filhos.includes(filho)) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Essa pessoa já é seu filho(a)!`
        }, { quoted: msg });
      }

      usuario.filhos.push(filho);
      if (!rpg[filho]) rpg[filho] = { moedas: 0 };
      rpg[filho].familia = [remetente, usuario.conjuge];

      salvarRPG(rpg);

      await sock.sendMessage(idChat, {
        text: `👶 *ADOÇÃO REALIZADA* 👶

👨‍👩‍👧 @${formatarUsuario(remetente)} e @${formatarUsuario(usuario.conjuge)}
adotaram @${formatarUsuario(filho)} como filho(a)! ❤️`,
        mentions: [remetente, usuario.conjuge, filho]
      }, { quoted: msg });
    },

    deserdar: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const mencionados = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];

      if (mencionados.length === 0) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Mencione o filho(a) que deseja deserdar!\nExemplo: ${PREFIXO}deserdar @filho`
        }, { quoted: msg });
      }

      const filho = mencionados[0];
      const rpg = carregarRPG();
      const usuario = rpg[remetente];

      if (!usuario?.filhos || !usuario.filhos.includes(filho)) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Essa pessoa não é seu filho(a)!`
        }, { quoted: msg });
      }

      usuario.filhos = usuario.filhos.filter(f => f !== filho);
      if (rpg[filho]?.familia) delete rpg[filho].familia;

      salvarRPG(rpg);

      await sock.sendMessage(idChat, {
        text: `😢 *DESERDAÇÃO* 😢

@${formatarUsuario(filho)} não faz mais parte da família de @${formatarUsuario(remetente)}.`,
        mentions: [remetente, filho]
      }, { quoted: msg });
    },

    família: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const rpg = carregarRPG();
      const usuario = rpg[remetente] || {};

      const conjuge = usuario.conjuge;
      const filhos = usuario.filhos || [];
      const fazParteDe = usuario.familia;

      let texto = `👨‍👩‍👧‍👦 *FAMÍLIA DE @${formatarUsuario(remetente)}* 👨‍👩‍👧‍👦\n\n`;

      if (conjuge) {
        texto += `💑 Cônjuge: @${formatarUsuario(conjuge)}\n`;
      } else if (fazParteDe && fazParteDe.length >= 2) {
        texto += `👨‍👩 Filho(a) de: @${formatarUsuario(fazParteDe[0])} e @${formatarUsuario(fazParteDe[1])}\n`;
      } else {
        texto += `🙋 Solteiro(a)\n`;
      }

      if (filhos.length > 0) {
        texto += `\n👶 Filhos:\n`;
        filhos.forEach((f, i) => {
          texto += `${i + 1}. @${formatarUsuario(f)}\n`;
        });
      } else if (!fazParteDe) {
        texto += `\n👶 Sem filhos ainda`;
      }

      const listaMencoes = [remetente, conjuge, ...filhos];
      if (fazParteDe) listaMencoes.push(...fazParteDe);

      await sock.sendMessage(idChat, {
        text: texto,
        mentions: listaMencoes.filter(Boolean)
      }, { quoted: msg });
    }
  }
};

