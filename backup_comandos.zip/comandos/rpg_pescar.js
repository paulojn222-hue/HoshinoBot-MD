const config = require("../config.js");
const fs = require("fs");
const path = require("path");
const { inicializarUsuario, alterarSaldo } = require("./rpg_saldo.js");

const PREFIXO = config.prefixo || "!";
const CAMINHO_RPG = path.join(__dirname, "..", "dados", "rpg_dados.json");
const COOLDOWN_PESCAR = 25 * 60 * 1000; // ⏰ 25 minutos

// 🖼️ Imagem única da pescaria
const IMAGEM_PESCAR = "https://i.ibb.co/5xs96rpM/c6f3c2b138a8ce5e747c950707d9436b.jpg"; // ← troque se quiser

// 🐟 Tipos de peixes
const PEIXES = [
  { nome: "🐟 Peixe pequeno", min: 15, max: 30, chance: 0.45 },
  { nome: "🐠 Peixe médio", min: 30, max: 55, chance: 0.30 },
  { nome: "🐡 Peixe grande", min: 55, max: 90, chance: 0.15 },
  { nome: "🦈 Tubarão", min: 90, max: 150, chance: 0.07 },
  { nome: "🐡‍💻 Nada pego", min: 0, max: 0, chance: 0.03 }
];

if (!fs.existsSync(path.dirname(CAMINHO_RPG))) {
  fs.mkdirSync(path.dirname(CAMINHO_RPG), { recursive: true });
}
if (!fs.existsSync(CAMINHO_RPG)) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify({}));
}

function salvarDados(dados) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify(dados, null, 2));
}

function sortearPeixe() {
  const sorteio = Math.random();
  let acumulado = 0;
  for (const peixe of PEIXES) {
    acumulado += peixe.chance;
    if (sorteio < acumulado) return peixe;
  }
  return PEIXES[0];
}

module.exports = {
  comandos: {
    pescar: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;

      const dadosUser = inicializarUsuario(remetente);
      const agora = Date.now();

      // ⏰ Verifica cooldown
      if (dadosUser.ultimoPesca && (agora - dadosUser.ultimoPesca) < COOLDOWN_PESCAR) {
        const tempoRestante = Math.ceil((COOLDOWN_PESCAR - (agora - dadosUser.ultimoPesca)) / 60000);
        return sock.sendMessage(idChat, {
          text: `⏳ *JÁ PESCOU HOJE!*\n\nVolte em ${tempoRestante} minutos! 🎣`
        }, { quoted: msg });
      }

      // 🎣 Sorteia peixe
      const peixe = sortearPeixe();
      let valorGanho = Math.floor(Math.random() * (peixe.max - peixe.min + 1)) + peixe.min;

      // 💾 Salva horário
      const dados = JSON.parse(fs.readFileSync(CAMINHO_RPG, "utf-8"));
      if (!dados[remetente]) dados[remetente] = {};
      dados[remetente].ultimoPesca = agora;
      salvarDados(dados);

      // 💰 Adiciona moedas
      if (valorGanho > 0) alterarSaldo(remetente, valorGanho);

      const texto = `🎣 *PESCARIA* 🎣

Você pescou um: ${peixe.nome}
💰 Ganhou: ${valorGanho} moedas!

> Use ${PREFIXO}saldo para ver seu total! 💰
> Volte em 25 minutos! ⏰`;

      return sock.sendMessage(idChat, {
        image: { url: IMAGEM_PESCAR },
        caption: texto,
        mentions: [remetente]
      }, { quoted: msg });
    }
  }
};

