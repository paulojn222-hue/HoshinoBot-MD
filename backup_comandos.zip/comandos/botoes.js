const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const CAMINHO_CONFIG_BOTOES = path.join(__dirname, "..", "dados", "botoes_status.json");

// Garante que a pasta e arquivo existam
function carregarStatusBotoes() {
  try {
    if (!fs.existsSync(path.dirname(CAMINHO_CONFIG_BOTOES))) {
      fs.mkdirSync(path.dirname(CAMINHO_CONFIG_BOTOES), { recursive: true });
    }
    if (!fs.existsSync(CAMINHO_CONFIG_BOTOES)) return { ativo: false };
    return JSON.parse(fs.readFileSync(CAMINHO_CONFIG_BOTOES, "utf-8"));
  } catch {
    return { ativo: false };
  }
}

function salvarStatusBotoes(dados) {
  fs.writeFileSync(CAMINHO_CONFIG_BOTOES, JSON.stringify(dados, null, 2));
}

// Verifica se é o dono
function ehDono(remetente) {
  return remetente === config.dono;
}

module.exports = {
  carregarStatusBotoes,
  salvarStatusBotoes,
  ehDono
};

