const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const PREFIXO = config.prefixo || "!";
const NOME_BOT = config.nomeBot || "MoonBot-MD";
const DONO_NOME = config.donoNome || "Dono";
const DONO_NUMERO_VISIVEL = config.numeroDonoVisivel || config.numeroDono || "+55 00 00000-0000";

// 📂 Caminhos
const CAMINHO_MENU = path.join(__dirname, "..", "menus", "menu_vip.txt");
const CAMINHO_VIPS = path.join(__dirname, "..", "dados", "vips.json");
const FOTO_MENU_VIP = path.join(__dirname, "..", "midias", "foto_menu_vip.jpg");
const VIDEO_MENU_VIP = path.join(__dirname, "..", "midias", "video_menu_vip.mp4");

// ✅ Verifica pastas
if (!fs.existsSync(path.dirname(CAMINHO_VIPS))) {
  fs.mkdirSync(path.dirname(CAMINHO_VIPS), { recursive: true });
}
if (!fs.existsSync(path.dirname(FOTO_MENU_VIP))) {
  fs.mkdirSync(path.dirname(FOTO_MENU_VIP), { recursive: true });
}

// ✅ Carrega VIPs
function carregarVips() {
  if (!fs.existsSync(CAMINHO_VIPS)) return {};
  try { return JSON.parse(fs.readFileSync(CAMINHO_VIPS, "utf-8")); }
  catch { return {}; }
}

// ✅ Verifica se é VIP ou Dono
function ehVipOuDono(idUsuario) {
  if (!idUsuario) return false;
  const idLimpo = String(idUsuario).replace(/\D/g, "");
  const donoLimpo = String(config.numeroDono).replace(/\D/g, "");
  
  if (idLimpo === donoLimpo) return true; // Dono sempre é VIP
  
  const vips = carregarVips();
  for (const [id, info] of Object.entries(vips)) {
    if (String(id).replace(/\D/g, "") === idLimpo) {
      if (!info.fim || info.fim > Date.now()) return true;
    }
  }
  return false;
}

// ⏳ Tempo restante do VIP
function tempoRestante(remetente) {
  const idLimpo = String(remetente).replace(/\D/g, "");
  const vips = carregarVips();
  
  for (const [id, info] of Object.entries(vips)) {
    if (String(id).replace(/\D/g, "") === idLimpo) {
      if (!info.fim) return "♾️ Vitalício";
      if (info.fim <= Date.now()) return "⚠️ Vencido";
      const r = info.fim - Date.now();
      return `${Math.floor(r / 86400000)}d ${Math.floor((r % 86400000) / 3600000)}h`;
    }
  }
  return "—";
}

module.exports = {
  comandos: {
    menuvip: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const numero = remetente.split("@")[0];
      const mencaoUsuario = `@${numero}`;
      
      // 🔒 Verifica acesso
      if (!ehVipOuDono(remetente)) {
        return sock.sendMessage(idChat, {
          text: `💎 *ACESSO RESTRITO!*\n\nApenas VIPs e o Dono podem usar este menu!\n\nUse ${PREFIXO}vip para saber como ser VIP ✨`
        }, { quoted: msg });
      }

      // 📝 Lê o arquivo de menu
      let texto = "";
      if (fs.existsSync(CAMINHO_MENU)) {
        texto = fs.readFileSync(CAMINHO_MENU, "utf-8");
      } else {
        // Menu padrão se não existir o .txt
        texto = `╭━━━━━━━━━━ 💎 MENU VIP 💎 ━━━━━━━━━━╮
┃
┃ 👤 Usuário: @{USUARIO}
┃ 💎 VIP: {VIP_STATUS}
┃ ⏳ Tempo: {TEMPO_VIP}
┃ 🤖 Bot: {NOME_BOT}
┃ 🔖 Prefixo: {PREFIXO}
┃
┃ 📋 COMANDOS EXCLUSIVOS:
┃ ├─ 🔮 {PREFIXO}gemini — IA
┃ ├─ 🧠 {PREFIXO}gpt — IA
┃ ├─ 📞 {PREFIXO}info_ddd
┃ ├─ 🌍 {PREFIXO}info_ddi
┃ ├─ 👤 {PREFIXO}get_perfil
┃ ├─ 📱 {PREFIXO}wawe
┃ ├─ 💪 {PREFIXO}aura
┃ ├─ 🎂 {PREFIXO}idade
┃ ├─ 📝 {PREFIXO}anotar
┃ ├─ ⏰ {PREFIXO}Lembrete
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯`;
      }

      // 🔄 Substitui TODAS as variáveis
      const statusVip = ehVipOuDono(remetente) ? "SIM ✅" : "NÃO ❌";
      const tempoVip = tempoRestante(remetente);
      
      texto = texto
        .replace(/{USUARIO}/gi, numero)
        .replace(/@\{USUARIO\}/gi, mencaoUsuario)
        .replace(/{NOME_BOT}/gi, NOME_BOT)
        .replace(/{PREFIXO}/gi, PREFIXO)
        .replace(/{DONO_NOME}/gi, DONO_NOME)
        .replace(/{DONO_NUMERO_VISIVEL}/gi, DONO_NUMERO_VISIVEL)
        .replace(/{VIP_STATUS}/gi, statusVip)
        .replace(/{TEMPO_VIP}/gi, tempoVip);

      // 🖼️🎥 Verifica mídia — vídeo tem prioridade
      let tipoMidia = null;
      let caminhoMidia = null;
      
      if (fs.existsSync(VIDEO_MENU_VIP)) {
        tipoMidia = "video";
        caminhoMidia = VIDEO_MENU_VIP;
      } else if (fs.existsSync(FOTO_MENU_VIP)) {
        tipoMidia = "image";
        caminhoMidia = FOTO_MENU_VIP;
      }

      // 📤 Envia com mídia ou só texto
      try {
        if (tipoMidia === "video") {
          return sock.sendMessage(idChat, {
            video: fs.readFileSync(caminhoMidia),
            caption: texto,
            gifPlayback: true,
            mentions: [remetente]
          }, { quoted: msg });
        } else if (tipoMidia === "image") {
          return sock.sendMessage(idChat, {
            image: fs.readFileSync(caminhoMidia),
            caption: texto,
            mentions: [remetente]
          }, { quoted: msg });
        } else {
          return sock.sendMessage(idChat, {
            text: texto,
            mentions: [remetente]
          }, { quoted: msg });
        }
      } catch (erro) {
        console.log("❌ Erro ao enviar menu VIP:", erro);
        return sock.sendMessage(idChat, {
          text: texto,
          mentions: [remetente]
        }, { quoted: msg });
      }
    }
  }
};

