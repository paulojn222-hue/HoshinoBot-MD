const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const PREFIXO = config.prefixo || "!";
const NOME_BOT = config.nomeBot || "MoonBot-MD";

// 📂 Caminhos dos dados
const CAMINHO_BANS = path.join(__dirname, "..", "dados", "bans_grupos.json");
const CAMINHO_ADVS = path.join(__dirname, "..", "dados", "advertencias.json");
const CAMINHO_CFG_GRUPOS = path.join(__dirname, "..", "dados", "config_grupos_admin.json");

// 📂 Garante pastas/arquivos
if (!fs.existsSync(path.dirname(CAMINHO_BANS))) {
  fs.mkdirSync(path.dirname(CAMINHO_BANS), { recursive: true });
}
if (!fs.existsSync(CAMINHO_BANS)) fs.writeFileSync(CAMINHO_BANS, JSON.stringify({}));
if (!fs.existsSync(CAMINHO_ADVS)) fs.writeFileSync(CAMINHO_ADVS, JSON.stringify({}));
if (!fs.existsSync(CAMINHO_CFG_GRUPOS)) fs.writeFileSync(CAMINHO_CFG_GRUPOS, JSON.stringify({}));

// 📖 Funções de carregar/salvar
function carregarBans() {
  try { return JSON.parse(fs.readFileSync(CAMINHO_BANS, "utf-8")); }
  catch { return {}; }
}
function salvarBans(dados) {
  fs.writeFileSync(CAMINHO_BANS, JSON.stringify(dados, null, 2));
}

function carregarAdvs() {
  try { return JSON.parse(fs.readFileSync(CAMINHO_ADVS, "utf-8")); }
  catch { return {}; }
}
function salvarAdvs(dados) {
  fs.writeFileSync(CAMINHO_ADVS, JSON.stringify(dados, null, 2));
}

function carregarCfgGrupos() {
  try { return JSON.parse(fs.readFileSync(CAMINHO_CFG_GRUPOS, "utf-8")); }
  catch { return {}; }
}
function salvarCfgGrupos(dados) {
  fs.writeFileSync(CAMINHO_CFG_GRUPOS, JSON.stringify(dados, null, 2));
}

// 🔍 Verifica se é admin
async function ehAdmin(sock, idGrupo, idUsuario) {
  try {
    const meta = await sock.groupMetadata(idGrupo);
    return meta.participants.some(p => p.id === idUsuario && p.admin);
  } catch { return false; }
}

// 🔍 Verifica se é grupo
function ehGrupo(idChat) {
  return idChat.includes("@g.us");
}

        // ✅ FUNÇÃO DEFINITIVA — reconhece brasileiro e identifica LIDs
        function ehNumeroBrasileiro(jid) {
          if (!jid) return false;
          const numCompleto = jid.split("@")[0].split(":")[0].replace(/\D/g, "");
          
          // 🆔 Se tem MAIS de 13 dígitos = provavelmente LID/conta empresarial
          if (numCompleto.length > 13) {
            // LIDs não dá pra saber país com certeza, então consideramos como "desconhecido"
            return false;
          }
          
          // 🇧🇷 Número brasileiro normal:
          // - Começa com 55 + DDD (2) + número (8-9) = 12-13 dígitos
          if (numCompleto.startsWith("55") && numCompleto.length >= 12 && numCompleto.length <= 13) {
            return true;
          }
          // - Sem DDI: só DDD + número = 10-11 dígitos
          if (!numCompleto.startsWith("55") && numCompleto.length >= 10 && numCompleto.length <= 11) {
            return true;
          }
          
          return false;
        }

// 📊 Sistema de antiflood
const contagemFlood = {};

// 🔤 Formata usuário
function formatarUsuario(jid) {
  if (!jid) return "Desconhecido";
  return jid.split("@")[0].split(":")[0];
}

module.exports = {
  // 🚦 Verificar antiflood
  verificarAntiFlood: async function (sock, msg, idChat, remetente, texto) {
    if (!ehGrupo(idChat)) return false;

    const cfg = carregarCfgGrupos();
    if (!cfg[idChat]?.antiflood) return false;

    const agora = Date.now();
    const minuto = Math.floor(agora / 60000);

    if (!contagemFlood[idChat]) contagemFlood[idChat] = {};
    if (!contagemFlood[idChat][remetente]) contagemFlood[idChat][remetente] = { minuto, contagem: 0 };

    const registro = contagemFlood[idChat][remetente];

    if (registro.minuto !== minuto) {
      registro.minuto = minuto;
      registro.contagem = 0;
    }

    const ehMidia = msg.message?.imageMessage || msg.message?.videoMessage ||
                    msg.message?.stickerMessage;
    const temApenasEmoji = texto && /^[\p{Emoji}\s]+$/u.test(texto.trim());

    if (ehMidia || temApenasEmoji) {
      registro.contagem++;

      if (registro.contagem > 10) {
        try {
          await sock.chatModify({ delete: msg.key, lastMessages: [{ key: msg.key }] }, idChat);
        } catch {}

        await sock.sendMessage(idChat, {
          text: `⚠️ *ANTI-FLOOD ATIVADO!* ⚠️
@${formatarUsuario(remetente)} ultrapassou o limite de 10 mensagens por minuto!
(Mídias, figurinhas e emojis são contados)`,
          mentions: [remetente]
        });
        return true;
      }
    }
    return false;
  },

  comandos: {
    // ==========================================
    // 🧹 !rm_off — Remover inativos (apenas admin)
    // ==========================================
    rm_off: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;

      if (!ehGrupo(idChat)) {
        return sock.sendMessage(idChat, { text: `⚠️ Use apenas em grupos!` }, { quoted: msg });
      }

      if (!(await ehAdmin(sock, idChat, remetente))) {
        return sock.sendMessage(idChat, { text: `⛔ Apenas administradores podem usar este comando!` }, { quoted: msg });
      }

      try {
        const meta = await sock.groupMetadata(idChat);
        const membros = meta.participants.filter(p => !p.admin);

        await sock.sendMessage(idChat, {
          text: `🧹 *REMOVER INATIVOS* 🧹

📊 Total de membros: ${meta.participants.length}
👥 Membros não-admins: ${membros.length}

⚠️ *Funcionalidade em desenvolvimento:*
Para remover inativos automaticamente, o bot precisa registrar a última vez que cada membro falou.

💡 Use este comando para verificar quem está há muito tempo sem interagir!`
        }, { quoted: msg });

      } catch (e) {
        await sock.sendMessage(idChat, { text: `❌ Erro: ${e.message}` }, { quoted: msg });
      }
    },

    // ==========================================
    // 📌 !fixar_aviso — Fixar mensagem marcada (apenas admin)
    // ==========================================
    fixar_aviso: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;

      if (!ehGrupo(idChat)) {
        return sock.sendMessage(idChat, { text: `⚠️ Use apenas em grupos!` }, { quoted: msg });
      }

      if (!(await ehAdmin(sock, idChat, remetente))) {
        return sock.sendMessage(idChat, { text: `⛔ Apenas administradores podem usar este comando!` }, { quoted: msg });
      }

      const citada = msg.message?.extendedTextMessage?.contextInfo;
      if (!citada?.stanzaId) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Responda a mensagem que deseja fixar!\nExemplo: responda uma mensagem com ${PREFIXO}fixar_aviso`
        }, { quoted: msg });
      }

      try {
        await sock.sendMessage(idChat, {
          text: `📌 *AVISO FIXADO* 📌

*Mensagem de @${formatarUsuario(citada.participant || remetente)}:*

"${citada.quotedMessage?.conversation || citada.quotedMessage?.extendedTextMessage?.text || '[Mensagem de mídia]'}"

⚠️ Esta mensagem está fixada como aviso do grupo!`,
          mentions: [citada.participant || remetente]
        });

        const cfg = carregarCfgGrupos();
        if (!cfg[idChat]) cfg[idChat] = {};
        cfg[idChat].avisoFixado = {
          texto: citada.quotedMessage?.conversation || citada.quotedMessage?.extendedTextMessage?.text || '[Mensagem de mídia]',
          autor: citada.participant || remetente,
          data: Date.now()
        };
        salvarCfgGrupos(cfg);

      } catch (e) {
        await sock.sendMessage(idChat, { text: `❌ Erro: ${e.message}` }, { quoted: msg });
      }
    },

    // ==========================================
    // 🌍 !numeros_fakes — VERSÃO FINAL PERFEITA
    // ==========================================
    numeros_fakes: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;

      if (!ehGrupo(idChat)) {
        return sock.sendMessage(idChat, { text: `⚠️ Use apenas em grupos!` }, { quoted: msg });
      }

      try {
        const meta = await sock.groupMetadata(idChat);
        
        // ✅ FUNÇÃO DEFINITIVA para identificar brasileiro
        // Formato brasileiro: 55 + DDD (2 dígitos) + número (8-9 dígitos) = 12-13 dígitos
        // OU: número local de 10-11 dígitos
        function ehNumeroBrasileiro(jid) {
          if (!jid) return false;
          const num = jid.split("@")[0].split(":")[0].replace(/\D/g, "");
          
          // Se começa com 55 e tem 12 ou 13 dígitos = brasileiro com DDI
          if (num.startsWith("55") && num.length >= 12 && num.length <= 13) return true;
          // Se tem 10 ou 11 dígitos = brasileiro sem DDI
          if (num.length >= 10 && num.length <= 11) return true;
          
          return false;
        }

        // ✅ Formata número para exibição bonita
        function formatarNumeroExibicao(jid) {
          const num = jid.split("@")[0].split(":")[0].replace(/\D/g, "");
          
          // Formato internacional: +55 81 99999-9999
          if (num.startsWith("55") && num.length >= 12) {
            const ddi = num.slice(0, 2);
            const ddd = num.slice(2, 4);
            const parte1 = num.slice(4, num.length - 4);
            const parte2 = num.slice(-4);
            return `+${ddi} ${ddd} ${parte1}-${parte2}`;
          }
          
          // Formato local: (81) 99999-9999
          if (num.length >= 10 && num.length <= 11) {
            const ddd = num.slice(0, 2);
            const parte1 = num.slice(2, num.length - 4);
            const parte2 = num.slice(-4);
            return `(${ddd}) ${parte1}-${parte2}`;
          }
          
          // Outros formatos: retorna como está
          return `+${num}`;
        }

        // Filtra só quem NÃO é brasileiro
        const naoBrasileiros = meta.participants.filter(p => !ehNumeroBrasileiro(p.id));

        if (naoBrasileiros.length === 0) {
          return sock.sendMessage(idChat, {
            text: `✅ *NENHUM NÚMERO ESTRANGEIRO ENCONTRADO!*

Todos os ${meta.participants.length} membros têm números brasileiros! 🇧🇷
(Formato reconhecido: +55 XX XXXXX-XXXX)`
          }, { quoted: msg });
        }

        let texto = `🌍 *NÚMEROS NÃO BRASILEIROS NO GRUPO* 🌍

📊 Total: ${naoBrasileiros.length} de ${meta.participants.length} membros
🇧🇷 Formato brasileiro reconhecido: +55 XX XXXXX-XXXX

📋 *Lista de números estrangeiros:*
`;

        naoBrasileiros.slice(0, 30).forEach((p, i) => {
          texto += `${i + 1}. ${formatarNumeroExibicao(p.id)}${p.admin ? " 👑 ADMIN" : ""}\n`;
        });

        if (naoBrasileiros.length > 30) {
          texto += `\n... e mais ${naoBrasileiros.length - 30} números`;
        }

        texto += `\n\n💡 *Observação:* Apenas números que NÃO são do Brasil aparecem aqui.
Números como +55 81 9564-7053 são reconhecidos como brasileiros e NÃO entram nesta lista! 🇧🇷✅`;

        // ✅ Sem menções — ninguém fica marcado em azul!
        await sock.sendMessage(idChat, { text: texto }, { quoted: msg });

      } catch (e) {
        await sock.sendMessage(idChat, { text: `❌ Erro: ${e.message}` }, { quoted: msg });
      }
    },

    // ==========================================
    // 🚫 !bans — Lista de banidos (apenas admin)
    // ==========================================
    bans: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;

      if (!ehGrupo(idChat)) {
        return sock.sendMessage(idChat, { text: `⚠️ Use apenas em grupos!` }, { quoted: msg });
      }

      if (!(await ehAdmin(sock, idChat, remetente))) {
        return sock.sendMessage(idChat, { text: `⛔ Apenas administradores podem usar este comando!` }, { quoted: msg });
      }

      const bans = carregarBans();
      const bansGrupo = bans[idChat] || [];

      if (bansGrupo.length === 0) {
        return sock.sendMessage(idChat, {
          text: `✅ *NENHUMA PESSOA BANIDA AINDA!*

Ninguém foi banido deste grupo ainda.`
        }, { quoted: msg });
      }

      let texto = `🚫 *LISTA DE BANIDOS* 🚫

📊 Total: ${bansGrupo.length} pessoas banidas

`;
      bansGrupo.slice(0, 30).forEach((b, i) => {
        const data = new Date(b.data).toLocaleString("pt-BR");
        texto += `${i + 1}. @${formatarUsuario(b.usuario)}
   📅 Data: ${data}
   👤 Por: @${formatarUsuario(b.admin)}
   📝 Motivo: ${b.motivo || "Não informado"}\n\n`;
      });

      if (bansGrupo.length > 30) {
        texto += `... e mais ${bansGrupo.length - 30} registros`;
      }

      const mencoes = bansGrupo.slice(0, 30).map(b => b.usuario).concat(bansGrupo.slice(0, 30).map(b => b.admin));

      await sock.sendMessage(idChat, {
        text: texto,
        mentions: mencoes.filter((v, i, a) => a.indexOf(v) === i)
      }, { quoted: msg });
    },

    // ==========================================
    // 📜 !Regrasgp — Mostrar descrição/regras do grupo (todos)
    // ==========================================
    Regrasgp: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;

      if (!ehGrupo(idChat)) {
        return sock.sendMessage(idChat, { text: `⚠️ Use apenas em grupos!` }, { quoted: msg });
      }

      try {
        const meta = await sock.groupMetadata(idChat);
        const cfg = carregarCfgGrupos();
        const aviso = cfg[idChat]?.avisoFixado;

        let texto = `📜 *REGRAS / DESCRIÇÃO DO GRUPO* 📜

👥 Grupo: ${meta.subject}
👑 Criado por: @${formatarUsuario(meta.owner || meta.participants[0]?.id)}
📅 Criado em: ${new Date(meta.creation * 1000).toLocaleDateString("pt-BR")}
👥 Membros: ${meta.participants.length}

`;

        if (meta.desc) {
          texto += `📝 *Descrição oficial:*
${meta.desc}

`;
        }

        if (aviso) {
          const data = new Date(aviso.data).toLocaleString("pt-BR");
          texto += `📌 *Aviso fixado:*
"${aviso.texto}"
   👤 Por: @${formatarUsuario(aviso.autor)}
   📅 ${data}`;
        } else if (!meta.desc) {
          texto += `⚠️ Este grupo ainda não tem descrição ou regras definidas.`;
        }

        await sock.sendMessage(idChat, {
          text: texto,
          mentions: [meta.owner, meta.participants[0]?.id, aviso?.autor].filter(Boolean)
        }, { quoted: msg });

      } catch (e) {
        await sock.sendMessage(idChat, { text: `❌ Erro: ${e.message}` }, { quoted: msg });
      }
    },

    // ==========================================
    // ⚠️ !advs — Lista de advertências (apenas admin)
    // ==========================================
    advs: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;

      if (!ehGrupo(idChat)) {
        return sock.sendMessage(idChat, { text: `⚠️ Use apenas em grupos!` }, { quoted: msg });
      }

      if (!(await ehAdmin(sock, idChat, remetente))) {
        return sock.sendMessage(idChat, { text: `⛔ Apenas administradores podem usar este comando!` }, { quoted: msg });
      }

      const advs = carregarAdvs();
      const advsGrupo = advs[idChat] || {};
      const comAdvs = Object.entries(advsGrupo).filter(([_, dados]) => dados.total > 0);

      if (comAdvs.length === 0) {
        return sock.sendMessage(idChat, {
          text: `✅ *NENHUMA ADVERTÊNCIA REGISTRADA!*

Todos os membros estão comportados! 😊`
        }, { quoted: msg });
      }

      let texto = `⚠️ *LISTA DE ADVERTÊNCIAS* ⚠️

📊 Total: ${comAdvs.length} membros com advertências

`;
      comAdvs.slice(0, 30).forEach(([usuario, dados], i) => {
        texto += `${i + 1}. @${formatarUsuario(usuario)} — ${dados.total} advertência(s)
   📝 Último motivo: ${dados.ultimoMotivo || "Não informado"}\n\n`;
      });

      if (comAdvs.length > 30) {
        texto += `... e mais ${comAdvs.length - 30} membros`;
      }

      const mencoes = comAdvs.slice(0, 30).map(([u]) => u);

      await sock.sendMessage(idChat, {
        text: texto,
        mentions: mencoes
      }, { quoted: msg });
    },

    // ==========================================
    // 🌊 !antiflood — Ativar/desativar limite de mensagens (apenas admin)
    // ==========================================
    antiflood: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;

      if (!ehGrupo(idChat)) {
        return sock.sendMessage(idChat, { text: `⚠️ Use apenas em grupos!` }, { quoted: msg });
      }

      if (!(await ehAdmin(sock, idChat, remetente))) {
        return sock.sendMessage(idChat, { text: `⛔ Apenas administradores podem usar este comando!` }, { quoted: msg });
      }

      const cfg = carregarCfgGrupos();
      if (!cfg[idChat]) cfg[idChat] = {};

      const acao = args[0]?.toLowerCase();

      if (acao === "on" || acao === "ligar" || acao === "ativar") {
        cfg[idChat].antiflood = true;
        salvarCfgGrupos(cfg);
        return sock.sendMessage(idChat, {
          text: `✅ *ANTI-FLOOD ATIVADO!*

Limite: 10 mensagens (fig, vídeo, foto, emoji) por minuto por pessoa.
Quem ultrapassar terá a mensagem apagada e será avisado!`
        }, { quoted: msg });
      }

      if (acao === "off" || acao === "desligar" || acao === "desativar") {
        cfg[idChat].antiflood = false;
        salvarCfgGrupos(cfg);
        return sock.sendMessage(idChat, {
          text: `❌ *ANTI-FLOOD DESATIVADO!*

O limite de mensagens foi removido.`
        }, { quoted: msg });
      }

      const status = cfg[idChat].antiflood ? "✅ ATIVADO" : "❌ DESATIVADO";
      await sock.sendMessage(idChat, {
        text: `🌊 *STATUS DO ANTI-FLOOD* 🌊

Status atual: ${status}

💡 Use:
${PREFIXO}antiflood on  — Ativar
${PREFIXO}antiflood off — Desativar

Limite: 10 mensagens de mídia/emoji por minuto`
      }, { quoted: msg });
    },

    // ==========================================
    // 🔔 !Avisos_adms on/off — Avisos administrativos (apenas admin)
    // ==========================================
    Avisos_adms: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;

      if (!ehGrupo(idChat)) {
        return sock.sendMessage(idChat, { text: `⚠️ Use apenas em grupos!` }, { quoted: msg });
      }

      if (!(await ehAdmin(sock, idChat, remetente))) {
        return sock.sendMessage(idChat, { text: `⛔ Apenas administradores podem usar este comando!` }, { quoted: msg });
      }

      const cfg = carregarCfgGrupos();
      if (!cfg[idChat]) cfg[idChat] = {};

      const acao = args[0]?.toLowerCase();

      if (acao === "on" || acao === "ligar" || acao === "ativar") {
        cfg[idChat].avisosAdms = true;
        salvarCfgGrupos(cfg);
        return sock.sendMessage(idChat, {
          text: `🔔 *AVISOS ADMINISTRATIVOS ATIVADOS!*

Agora o bot avisará no grupo quando:
👑 Alguém for promovido a admin
👤 Alguém for rebaixado
🚫 Alguém for banido
➕ Alguém entrar no grupo
➖ Alguém sair do grupo`
        }, { quoted: msg });
      }

      if (acao === "off" || acao === "desligar" || acao === "desativar") {
        cfg[idChat].avisosAdms = false;
        salvarCfgGrupos(cfg);
        return sock.sendMessage(idChat, {
          text: `🔕 *AVISOS ADMINISTRATIVOS DESATIVADOS!*

O bot não avisará mais sobre promoções, banimentos, etc.`
        }, { quoted: msg });
      }

      const status = cfg[idChat].avisosAdms ? "✅ ATIVADO" : "❌ DESATIVADO";
      await sock.sendMessage(idChat, {
        text: `🔔 *STATUS DOS AVISOS ADMINISTRATIVOS* 🔔

Status atual: ${status}

💡 Use:
${PREFIXO}Avisos_adms on  — Ativar
${PREFIXO}Avisos_adms off — Desativar`
      }, { quoted: msg });
    }
  }
};

