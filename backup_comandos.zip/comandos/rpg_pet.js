const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const PREFIXO = config.prefixo || "!";
const CAMINHO_RPG = path.join(__dirname, "..", "dados", "rpg_dados.json");

// 🐾 Lista de Pets disponíveis
const PETS_LOJA = [
  { id: "cachorro", nome: "🐶 Cachorro", preco: 300, forcaBase: 5, resistenciaBase: 8 },
  { id: "gato", nome: "🐱 Gato", preco: 280, forcaBase: 6, resistenciaBase: 6 },
  { id: "coelho", nome: "🐰 Coelho", preco: 250, forcaBase: 4, resistenciaBase: 5 },
  { id: "papagaio", nome: "🦜 Papagaio", preco: 350, forcaBase: 5, resistenciaBase: 4 },
  { id: "hamster", nome: "🐹 Hamster", preco: 200, forcaBase: 3, resistenciaBase: 5 },
  { id: "lobo", nome: "🐺 Lobo", preco: 800, forcaBase: 12, resistenciaBase: 10 },
  { id: "leao", nome: "🦁 Leão", preco: 1500, forcaBase: 18, resistenciaBase: 15 },
  { id: "dragao", nome: "🐉 Dragão", preco: 3000, forcaBase: 25, resistenciaBase: 20 }
];

// ⚙️ Limites diários
const LIMITE_BRINCAR_DIA = 7;
const LIMITE_TREINAR_DIA = 10;
const LIMITE_BATALHAR_DIA = 5;

if (!fs.existsSync(path.dirname(CAMINHO_RPG))) {
  fs.mkdirSync(path.dirname(CAMINHO_RPG), { recursive: true });
}
if (!fs.existsSync(CAMINHO_RPG)) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify({}));
}

function carregarDados() {
  try { return JSON.parse(fs.readFileSync(CAMINHO_RPG, "utf-8")); }
  catch { return {}; }
}

function salvarDados(dados) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify(dados, null, 2));
}

function inicializarUsuarioPet(remetente) {
  const dados = carregarDados();
  if (!dados[remetente]) dados[remetente] = {};
  const user = dados[remetente];
  if (!user.pet) user.pet = null;
  if (!user.petStats) user.petStats = {};
  return { user, dados };
}

function resetarSeNovoDia(user) {
  const hoje = new Date().toDateString();
  if (user.petStats.ultimoDia !== hoje) {
    user.petStats.ultimoDia = hoje;
    user.petStats.brincarUsado = 0;
    user.petStats.treinarUsado = 0;
    user.petStats.batalharUsado = 0;
  }
}

module.exports = {
  comandos: {
    // 🛒 Comprar Pet
    comprarpet: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const { user, dados } = inicializarUsuarioPet(remetente);
      const saldo = user.saldo || 0;

      // Lista os pets
      if (args.length === 0) {
        let texto = `🛒 *LOJA DE PETS* 🛒\n\n`;
        PETS_LOJA.forEach((pet, i) => {
          texto += `${i + 1}. ${pet.nome}\n`;
          texto += `   💰 Preço: ${pet.preco} moedas\n`;
          texto += `   💪 Força: ${pet.forcaBase} | 🛡️ Resistência: ${pet.resistenciaBase}\n\n`;
        });
        texto += `> Use: ${PREFIXO}comprarpet [número]\nExemplo: ${PREFIXO}comprarpet 1`;
        return sock.sendMessage(idChat, { text: texto }, { quoted: msg });
      }

      const num = parseInt(args[0]);
      if (isNaN(num) || num < 1 || num > PETS_LOJA.length) {
        return sock.sendMessage(idChat, { text: `❌ Pet inválido! Escolha de 1 a ${PETS_LOJA.length}` }, { quoted: msg });
      }

      const petEscolhido = PETS_LOJA[num - 1];

      if (user.pet) {
        return sock.sendMessage(idChat, { text: `❌ Você já tem um pet!\nNome: ${user.pet.nomeCompleto || user.pet.tipo}\nAbandone antes de comprar outro!` }, { quoted: msg });
      }

      if (saldo < petEscolhido.preco) {
        return sock.sendMessage(idChat, { text: `❌ Saldo insuficiente!\nVocê tem: ${saldo} moedas\nPrecisa: ${petEscolhido.preco} moedas` }, { quoted: msg });
      }

      // Deduz saldo e cria pet
      user.saldo = saldo - petEscolhido.preco;
      user.pet = {
        tipo: petEscolhido.id,
        nomeCompleto: petEscolhido.nome,
        nivel: 1,
        forca: petEscolhido.forcaBase,
        resistencia: petEscolhido.resistenciaBase,
        fome: 100,
        energia: 100
      };
      user.petStats = {
        brincarUsado: 0,
        treinarUsado: 0,
        batalharUsado: 0,
        ultimoDia: new Date().toDateString()
      };

      salvarDados(dados);
      return sock.sendMessage(idChat, { text: `✅ *PET COMPRADO COM SUCESSO!*\n\n${user.pet.nomeCompleto} agora é seu! 🎉\n\nUse ${PREFIXO}nomear_pet para dar um nome!` }, { quoted: msg });
    },

    // 🎾 Brincar com Pet
    brincar_pet: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const { user, dados } = inicializarUsuarioPet(remetente);

      if (!user.pet) return sock.sendMessage(idChat, { text: `❌ Você não tem pet! Use ${PREFIXO}comprarpet` }, { quoted: msg });

      resetarSeNovoDia(user);

      if (user.petStats.brincarUsado >= LIMITE_BRINCAR_DIA) {
        return sock.sendMessage(idChat, { text: `⏰ Limite de brincadeiras atingido! (${LIMITE_BRINCAR_DIA}/dia)\nVolte amanhã! 😊` }, { quoted: msg });
      }

      // Ganha energia e força
      user.pet.energia = Math.min(100, user.pet.energia + 15);
      user.pet.forca += Math.floor(Math.random() * 2) + 1;
      user.petStats.brincarUsado++;

      salvarDados(dados);
      return sock.sendMessage(idChat, { text: `🎾 *BRINCANDO COM O PET!* 🎾\n\n✅ Energia +15\n💪 Força aumentou!\n\n📊 Brincadeiras hoje: ${user.petStats.brincarUsado}/${LIMITE_BRINCAR_DIA}` }, { quoted: msg });
    },

    // 📚 Treinar Pet
    treinar_pet: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const { user, dados } = inicializarUsuarioPet(remetente);

      if (!user.pet) return sock.sendMessage(idChat, { text: `❌ Você não tem pet! Use ${PREFIXO}comprarpet` }, { quoted: msg });

      resetarSeNovoDia(user);

      if (user.petStats.treinarUsado >= LIMITE_TREINAR_DIA) {
        return sock.sendMessage(idChat, { text: `⏰ Limite de treinos atingido! (${LIMITE_TREINAR_DIA}/dia)\nVolte amanhã! 💪` }, { quoted: msg });
      }

      // Evolui o pet
      user.pet.nivel += 1;
      user.pet.forca += 2;
      user.pet.resistencia += 2;
      user.pet.fome = Math.max(0, user.pet.fome - 15);
      user.petStats.treinarUsado++;

      salvarDados(dados);
      return sock.sendMessage(idChat, { text: `📚 *TREINAMENTO CONCLUÍDO!* 📚\n\n⭐ Nível: ${user.pet.nivel}\n💪 Força: ${user.pet.forca}\n🛡️ Resistência: ${user.pet.resistencia}\n🍖 Fome: ${user.pet.fome}%\n\n📊 Treinos hoje: ${user.petStats.treinarUsado}/${LIMITE_TREINAR_DIA}` }, { quoted: msg });
    },

    // ⚔️ Batalhar com outro Pet
    batalhar_pet: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const alvo = msg.message?.mentionedJidList?.[0];
      const { user, dados } = inicializarUsuarioPet(remetente);

      if (!user.pet) return sock.sendMessage(idChat, { text: `❌ Você não tem pet! Use ${PREFIXO}comprarpet` }, { quoted: msg });
      if (!alvo || alvo === remetente) return sock.sendMessage(idChat, { text: `❌ Marque alguém para batalhar!\nExemplo: ${PREFIXO}batalhar_pet @usuario` }, { quoted: msg });

      resetarSeNovoDia(user);

      if (user.petStats.batalharUsado >= LIMITE_BATALHAR_DIA) {
        return sock.sendMessage(idChat, { text: `⏰ Limite de batalhas atingido! (${LIMITE_BATALHAR_DIA}/dia)` }, { quoted: msg });
      }

      const dadosAlvo = dados[alvo];
      if (!dadosAlvo || !dadosAlvo.pet) return sock.sendMessage(idChat, { text: `❌ Essa pessoa não tem pet!` }, { quoted: msg });

      // Cálculo simples de batalha
      const poderA = user.pet.forca + user.pet.resistencia;
      const poderB = dadosAlvo.pet.forca + dadosAlvo.pet.resistencia;
      const sorteA = Math.random() * 0.3;
      const sorteB = Math.random() * 0.3;

      let vencedor;
      if ((poderA * (1 + sorteA)) > (poderB * (1 + sorteB))) {
        vencedor = remetente;
      } else {
        vencedor = alvo;
      }

      user.petStats.batalharUsado++;
      salvarDados(dados);

      const nomePetA = user.pet.nomeCompleto;
      const nomePetB = dadosAlvo.pet.nomeCompleto;
      const venceuVo = vencedor === remetente;

      return sock.sendMessage(idChat, {
        text: `⚔️ *BATALHA DE PETS* ⚔️

${nomePetA} vs ${nomePetB}

🏆 Resultado: ${venceuVo ? `Seu pet venceu! 🎉` : `O pet adversário venceu! 😔`}

📊 Batalhas hoje: ${user.petStats.batalharUsado}/${LIMITE_BATALHAR_DIA}`,
        mentions: [remetente, alvo]
      }, { quoted: msg });
    },

    // 🍖 Alimentar Pet
    alimentrar_pet: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const { user, dados } = inicializarUsuarioPet(remetente);

      if (!user.pet) return sock.sendMessage(idChat, { text: `❌ Você não tem pet! Use ${PREFIXO}comprarpet` }, { quoted: msg });

      user.pet.fome = Math.min(100, user.pet.fome + 30);
      salvarDados(dados);
      return sock.sendMessage(idChat, { text: `🍖 *PET ALIMENTADO!* 🍖\n\nFome atual: ${user.pet.fome}%\n\nSeu pet está feliz! 😊` }, { quoted: msg });
    },

    // ✏️ Nomear Pet
    nomear_pet: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const { user, dados } = inicializarUsuarioPet(remetente);
      const nome = args.join(" ").trim();

      if (!user.pet) return sock.sendMessage(idChat, { text: `❌ Você não tem pet! Use ${PREFIXO}comprarpet` }, { quoted: msg });
      if (!nome) return sock.sendMessage(idChat, { text: `❌ Digite um nome!\nExemplo: ${PREFIXO}nomear_pet Rex` }, { quoted: msg });

      user.pet.nomeCompleto = nome;
      salvarDados(dados);
      return sock.sendMessage(idChat, { text: `✅ *Pet renomeado!*\n\nNovo nome: ${nome} 🐾` }, { quoted: msg });
    },

    // 📊 Status do Pet
    status_pet: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const numeroDono = remetente.split("@")[0];
      const { user } = inicializarUsuarioPet(remetente);

      if (!user.pet) return sock.sendMessage(idChat, { text: `❌ Você não tem pet! Use ${PREFIXO}comprarpet` }, { quoted: msg });

      resetarSeNovoDia(user);

      const pet = user.pet;
      let texto = `📊 *STATUS DO PET* 📊

📛 Nome: ${pet.nomeCompleto}
⭐ Nível: ${pet.nivel}
💪 Força: ${pet.forca}
🛡️ Resistência: ${pet.resistencia}
🍖 Fome: ${pet.fome}%
⚡ Energia: ${pet.energia}

👤 Dono: @${numeroDono}

📅 Limites de hoje:
🎾 Brincar: ${user.petStats.brincarUsado}/${LIMITE_BRINCAR_DIA}
📚 Treinar: ${user.petStats.treinarUsado}/${LIMITE_TREINAR_DIA}
⚔️ Batalhar: ${user.petStats.batalharUsado}/${LIMITE_BATALHAR_DIA}`;

      return sock.sendMessage(idChat, { text: texto, mentions: [remetente] }, { quoted: msg });
    }
  }
};

