const versiculos = [
  { texto: "Porque Deus amou o mundo de tal maneira que deu o seu Filho Unigênito, para que todo aquele que nele crer não pereça, mas tenha a vida eterna.", referencia: "João 3:16" },
  { texto: "O Senhor é o meu pastor, nada me faltará.", referencia: "Salmos 23:1" },
  { texto: "Tudo posso naquele que me fortalece.", referencia: "Filipenses 4:13" },
  { texto: "Confia no Senhor de todo o teu coração, e não te estribes no teu próprio entendimento.", referencia: "Provérbios 3:5" },
  { texto: "Porque para Deus nada é impossível.", referencia: "Lucas 1:37" },
  { texto: "Eu sou o caminho, e a verdade, e a vida; ninguém vem ao Pai, senão por mim.", referencia: "João 14:6" },
  { texto: "A fé é a certeza daquilo que esperamos e a prova das coisas que não vemos.", referencia: "Hebreus 11:1" },
  { texto: "Bem-aventurados os pacificadores, porque eles serão chamados filhos de Deus.", referencia: "Mateus 5:9" },
  { texto: "O amor é paciente, o amor é bondoso. Não inveja, não se vangloria, não se orgulha.", referencia: "1 Coríntios 13:4" },
  { texto: "Venham a mim, todos os que estão cansados e sobrecarregados, e eu lhes darei descanso.", referencia: "Mateus 11:28" },
  { texto: "Se Deus é por nós, quem será contra nós?", referencia: "Romanos 8:31" },
  { texto: "A alegria do Senhor é a nossa força.", referencia: "Neemias 8:10" },
  { texto: "Tudo tem o seu tempo determinado, e há tempo para todo o propósito debaixo do céu.", referencia: "Eclesiastes 3:1" },
  { texto: "O Senhor é a minha luz e a minha salvação; a quem temerei?", referencia: "Salmos 27:1" },
  { texto: "Deus não nos deu espírito de covardia, mas de poder, de amor e de equilíbrio.", referencia: "2 Timóteo 1:7" },
  { texto: "A misericórdia do Senhor é nova cada manhã; grande é a sua fidelidade.", referencia: "Lamentações 3:22-23" },
  { texto: "Ande por fé, e não por vista.", referencia: "2 Coríntios 5:7" },
  { texto: "Quem em tudo tem cuidado, em tudo será feliz.", referencia: "Provérbios 16:20" },
  { texto: "O Senhor está perto dos que têm o coração quebrantado.", referencia: "Salmos 34:18" },
  { texto: "Lancem sobre ele toda a sua ansiedade, porque ele tem cuidado de vocês.", referencia: "1 Pedro 5:7" }
];

module.exports = {
  nome: "versiculo",
  comandos: {
    versiculo: async (sock, msg, args, dados) => {
      const idChat = dados.idChat;
      const escolhido = versiculos[Math.floor(Math.random() * versiculos.length)];
      
      const texto = `
📖 *VERSÍCULO DO DIA* ✨

"${escolhido.texto}"

— 📍 ${escolhido.referencia}
`.trim();
      
      return sock.sendMessage(idChat, { text: texto });
    }
  }
};

