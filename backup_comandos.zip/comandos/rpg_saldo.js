const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const PREFIXO = config.prefixo || "!";
const CAMINHO_RPG = path.join(__dirname, "..", "dados", "rpg_dados.json");

// 📂 Garante pasta e arquivo
if (!fs.existsSync(path.dirname(CAMINHO_RPG))) {
  fs.mkdirSync(path.dirname(CAMINHO_RPG), { recursive: true });
}
if (!fs.existsSync(CAMINHO_RPG)) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify({}));
}

// 📖 Carrega dados
function carregarDados() {
  try {
    return JSON.parse(fs.readFileSync(CAMINHO_RPG, "utf-8"));
  } catch {
    return {};
  }
}

// 💾 Salva dados
function salvarDados(dados) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify(dados, null, 2));
}

// ✅ Cria usuário completo se não existir
function inicializarUsuario(usuario) {
  const dados = carregarDados();
  if (!dados[usuario]) {
    dados[usuario] = {
      saldo: 0,
      nivel: 1,
      xp: 0,
      ultimoAcesso: null,
      ultimoTrabalho: 0,
      ultimoCrime: 0,
      ultimoPesca: 0,
      ultimoMineracao: 0,
      presoAte: 0,
      itens: [],
      pet: null,
      ultimoInvestimento: null,
      bonusCarteiraAte: 0,
      contagemDiaria: {
        brincarPet: 0,
        treinarPet: 0,
        primeiraMensagemDia: null
      }
    };
    salvarDados(dados);
  }
  // Garante que contagemDiaria exista mesmo em usuários antigos
  if (!dados[usuario].contagemDiaria) {
    dados[usuario].contagemDiaria = {
      brincarPet: 0,
      treinarPet: 0,
      primeiraMensagemDia: null
    };
    salvarDados(dados);
  }
  return dados[usuario];
}

// 💰 Saldo compartilhado com jogos
function alterarSaldo(usuario, valor) {
  const dados = carregarDados();
  inicializarUsuario(usuario);
  dados[usuario].saldo = Math.max(0, dados[usuario].saldo + valor);
  salvarDados(dados);
  return dados[usuario].saldo;
}

// 🎁 Bônus da 1ª mensagem do dia — VERSÃO BLINDADA
function verificarBonusDiario(usuario) {
  const dados = carregarDados();

  // Se usuário não existe, cria completo
  if (!dados[usuario]) {
    dados[usuario] = {
      saldo: 0,
      nivel: 1,
      xp: 0,
      ultimoAcesso: null,
      ultimoTrabalho: 0,
      ultimoCrime: 0,
      ultimoPesca: 0,
      ultimoMineracao: 0,
      presoAte: 0,
      itens: [],
      pet: null,
      ultimoInvestimento: null,
      bonusCarteiraAte: 0,
      contagemDiaria: {
        brincarPet: 0,
        treinarPet: 0,
        primeiraMensagemDia: null
      }
    };
  }

  // Se contagemDiaria não existe, cria
  if (!dados[usuario].contagemDiaria) {
    dados[usuario].contagemDiaria = {
      brincarPet: 0,
      treinarPet: 0,
      primeiraMensagemDia: null
    };
  }

  const hoje = new Date().toISOString().slice(0, 10);
  const ultimoDia = dados[usuario].contagemDiaria.primeiraMensagemDia;

  if (ultimoDia !== hoje) {
    const valor = Math.floor(Math.random() * 111) + 40; // 40 a 150 moedas
    dados[usuario].saldo += valor;
    dados[usuario].contagemDiaria.primeiraMensagemDia = hoje;
    salvarDados(dados);
    return { ganhou: true, valor };
  }

  return { ganhou: false, valor: 0 };
}

module.exports = {
  verificarBonusDiario,
  alterarSaldo,
  inicializarUsuario,

  comandos: {
    // 💰 !saldo
    saldo: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const usuario = remetente.split("@")[0];

      const dadosUser = inicializarUsuario(remetente);
      const saldo = dadosUser.saldo;
      const nivel = dadosUser.nivel;
      const xp = dadosUser.xp;

      // ✅ Variável TEXTO definida corretamente
      const texto = `💰 *SALDO* 💰

👤 Usuário: @${usuario}
💵 Moedas: ${saldo}
⭐ Nível: ${nivel}
📊 XP: ${xp}

> Use ${PREFIXO}trabalhar para ganhar mais! 💼`;

      return sock.sendMessage(idChat, {
        text: texto, // ✅ Aqui passa a variável certa!
        mentions: [remetente]
      }, { quoted: msg });
    }
  }
};

