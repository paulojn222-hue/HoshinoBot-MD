const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const PREFIXO = config.prefixo || "!";
const NOME_BOT = config.nomeBot || "SukunaBot-MD";
const DONO_PRINCIPAL_LIMPO = String(config.numeroDono).replace(/\D/g, "");

// 📁 Caminhos
const CAMINHO_LISTA_FIG = path.join(__dirname, "..", "dados", "lista_figurinhas.json");
const CAMINHO_PACK = path.join(__dirname, "..", "dados", "pack_fig.json");

// ✅ Garante arquivos
if (!fs.existsSync(path.dirname(CAMINHO_LISTA_FIG))) {
  fs.mkdirSync(path.dirname(CAMINHO_LISTA_FIG), { recursive: true });
}
if (!fs.existsSync(CAMINHO_LISTA_FIG)) {
  fs.writeFileSync(CAMINHO_LISTA_FIG, JSON.stringify([]));
}
if (!fs.existsSync(CAMINHO_PACK)) {
  fs.writeFileSync(CAMINHO_PACK, JSON.stringify({ link: "", nome: "" }));
}

// ✅ Funções auxiliares
function ehDonoPrincipal(idUsuario) {
  if (!idUsuario) return false;
  const limpo = String(idUsuario).replace(/\D/g, "");
  return limpo === DONO_PRINCIPAL_LIMPO;
}

function carregarListaFig() {
  try {
    return JSON.parse(fs.readFileSync(CAMINHO_LISTA_FIG, "utf-8"));
  } catch {
    return [];
  }
}

function salvarListaFig(lista) {
  fs.writeFileSync(CAMINHO_LISTA_FIG, JSON.stringify(lista, null, 2), "utf-8");
}

function carregarPack() {
  try {
    return JSON.parse(fs.readFileSync(CAMINHO_PACK, "utf-8"));
  } catch {
    return { link: "", nome: "" };
  }
}

function salvarPack(dados) {
  fs.writeFileSync(CAMINHO_PACK, JSON.stringify(dados, null, 2), "utf-8");
}

module.exports = {
  carregarListaFig,
  salvarListaFig,
  ehDonoPrincipal,

  nome: "fig_gerenciar",
  comandos: {

    // 🎨 !rg_fig <comando> — SÓ DONO
    rg_fig: {
      nome: "rg_fig",
      alternativos: ["registrar_fig", "cadastrar_fig"],
      executar: async (sock, msg, args, dados) => {
        if (!ehDonoPrincipal(dados.remetente)) return;

        const citada = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (!citada || !citada.stickerMessage) {
          return sock.sendMessage(dados.idChat, {
            text: `🎨 *REGISTRAR FIGURINHA* 🕷️\n\n📎 Responda uma FIGURINHA com:\n${PREFIXO}rg_fig <comando>\n\n💡 Exemplos:\n${PREFIXO}rg_fig ping\n${PREFIXO}rg_fig menu\n${PREFIXO}rg_fig infobot`
          });
        }

        const comando = args[0];
        if (!comando) {
          return sock.sendMessage(dados.idChat, {
            text: `⚠️ Digite o comando que a figurinha vai executar!\n\nEx: ${PREFIXO}rg_fig ping`
          });
        }

        const lista = carregarListaFig();
        const idFig = citada.stickerMessage.id || citada.stickerMessage.fileSha256;

        const jaExiste = lista.findIndex(item => item.id === idFig);
        if (jaExiste !== -1) {
          lista[jaExiste].comando = comando;
          lista[jaExiste].data = new Date().toLocaleString("pt-BR");
        } else {
          lista.push({
            id: idFig,
            comando: comando,
            data: new Date().toLocaleString("pt-BR")
          });
        }

        salvarListaFig(lista);

        return sock.sendMessage(dados.idChat, {
          text: `✅ *FIGURINHA REGISTRADA!* 🕷️\n\n⚙️ Comando: ${PREFIXO}${comando}\n📅 Data: ${new Date().toLocaleString("pt-BR")}\n\n💡 Agora quando alguém enviar essa figurinha, o bot executa ${PREFIXO}${comando} automaticamente!`
        });
      }
    },

    // 🚫 !rmfig — SÓ DONO
    rmfig: {
      nome: "rmfig",
      alternativos: ["remover_fig", "del_fig"],
      executar: async (sock, msg, args, dados) => {
        if (!ehDonoPrincipal(dados.remetente)) return;

        const idOuIndice = args[0];
        if (!idOuIndice) {
          return sock.sendMessage(dados.idChat, {
            text: `⚠️ Use: ${PREFIXO}rmfig <número ou ID>\nExemplo: ${PREFIXO}rmfig 1`
          });
        }

        let lista = carregarListaFig();
        if (/^\d+$/.test(idOuIndice)) {
          const indice = parseInt(idOuIndice) - 1;
          if (indice < 0 || indice >= lista.length) {
            return sock.sendMessage(dados.idChat, { text: `⚠️ Índice inválido!` });
          }
          lista.splice(indice, 1);
        } else {
          lista = lista.filter(item => item.id !== idOuIndice);
        }

        salvarListaFig(lista);
        return sock.sendMessage(dados.idChat, {
          text: `✅ *Removido!* 🕷️\nVeja a lista:\n${PREFIXO}listafig`
        });
      }
    },

    // 📋 !listafig — SÓ DONO
    listafig: {
      nome: "listafig",
      alternativos: ["lista_fig", "figuras"],
      executar: async (sock, msg, args, dados) => {
        if (!ehDonoPrincipal(dados.remetente)) return;

        const lista = carregarListaFig();
        if (lista.length === 0) {
          return sock.sendMessage(dados.idChat, {
            text: `📋 *LISTA DE FIGURINHAS* 🕷️\n\n⚠️ Nenhuma figurinha cadastrada!\n\nUse:\n${PREFIXO}rg_fig ping`
          });
        }

        let texto = `📋 *LISTA DE FIGURINHAS* 🕷️\n\nTotal: ${lista.length}\n\n`;
        lista.forEach((item, i) => {
          texto += `${i + 1}. ⚙️ Comando: ${PREFIXO}${item.comando}\n   📅 Data: ${item.data}\n\n`;
        });

        return sock.sendMessage(dados.idChat, { text: texto });
      }
    },

    // 🔗 !set_pack <link> <nome> — SÓ DONO
    set_pack: {
      nome: "set_pack",
      alternativos: ["definir_pack", "setpackfig"],
      executar: async (sock, msg, args, dados) => {
        if (!ehDonoPrincipal(dados.remetente)) return;

        const link = args[0];
        const nome = args.slice(1).join(" ") || "Sukuna Pack";

        if (!link) {
          return sock.sendMessage(dados.idChat, {
            text: `🔗 *DEFINIR PACK DE FIGURINHAS* 🕷️\n\n📌 Use:\n${PREFIXO}set_pack <link_do_pack> <nome>\n\n💡 Exemplo:\n${PREFIXO}set_pack https://pack.link Sukuna Pack`
          });
        }

        salvarPack({ link, nome });
        return sock.sendMessage(dados.idChat, {
          text: `✅ *PACK DEFINIDO!* 🕷️\n\n📦 Nome: ${nome}\n🔗 Link: ${link}\n\n💡 Agora use:\n${PREFIXO}pack_figcmd para enviar o pack!`
        });
      }
    },

    // 📦 !pack_figcmd — TODOS PODEM USAR ✅
    pack_figcmd: {
      nome: "pack_figcmd",
      alternativos: ["pacote_fig", "figcmd", "packfig", "pack"],
      executar: async (sock, msg, args, dados) => {
        const pack = carregarPack();

        if (!pack.link) {
          return sock.sendMessage(dados.idChat, {
            text: `⚠️ Pack de figurinhas ainda não definido!\n\n👑 Peça ao dono para definir:\n${PREFIXO}set_pack <link_do_pack> <nome>`
          });
        }

        return sock.sendMessage(dados.idChat, {
          text: `╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╮
┃        🕷️ 𝐏𝐀𝐂𝐊 𝐃𝐄 𝐅𝐈𝐆𝐔𝐑𝐈𝐍𝐇𝐀𝐒 🕷️
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

          📦 *${pack.nome}* 📦

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔗 *BAIXE AQUI:*
${pack.link}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🕷️ *Bot:* ${NOME_BOT}
👑 *Dono:* ${config.donoNome || "Dono"}
⚡ *Versão:* ${config.versao || "1.0.0"}
📌 *Comando:* ${PREFIXO}pack_figcmd`
        });
      }
    }
  }
};

