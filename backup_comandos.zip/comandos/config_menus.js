const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const PASTA_MIDIAS = path.join(__dirname, "..", "midias");
const PASTA_MENUS = path.join(__dirname, "..", "menus");

// 📋 LISTA DE TODOS OS MENUS — NÃO ALTERE AQUI SEM PRECISAR!
const LISTA_MENUS = [
  { id: "principal", nome: "Menu Principal", foto: "foto_menu.jpg", video: "video_menu.mp4" },
  { id: "adm", nome: "Menu Administrador", foto: "foto_menu_adm.jpg", video: "video_menu_adm.mp4" },
  { id: "rpg", nome: "Menu RPG", foto: "foto_menu_rpg.jpg", video: "video_menu_rpg.mp4" },
  { id: "pesquisas", nome: "Menu Pesquisas", foto: "foto_menu_pesquisas.jpg", video: "video_menu_pesquisas.mp4" },
  { id: "fig", nome: "Menu Figurinhas", foto: "foto_menu_fig.jpg", video: "video_menu_fig.mp4" },
  { id: "dono", nome: "Menu Dono", foto: "foto_menu_dono.jpg", video: "video_menu_dono.mp4" },
  { id: "game", nome: "Menu Games/Jogos", foto: "foto_menu_game.jpg", video: "video_menu_game.mp4" },
  { id: "familia", nome: "Menu Família", foto: "foto_menu_familia.jpg", video: "video_menu_familia.mp4" }
];

// ✅ Verifica se é o dono
function verificarDono(remetente) {
  const numeroLimpo = String(remetente).replace(/\D/g, "");
  const donoLimpo = String(config.numeroDono || config.dono || "").replace(/\D/g, "");
  return numeroLimpo === donoLimpo;
}

// 📂 Garante que as pastas existem
if (!fs.existsSync(PASTA_MIDIAS)) fs.mkdirSync(PASTA_MIDIAS, { recursive: true });
if (!fs.existsSync(PASTA_MENUS)) fs.mkdirSync(PASTA_MENUS, { recursive: true });

function carregarMenu(menuId, remetente, NOME_BOT, PREFIXO) {
  // ✅ Proteção contra remetente undefined
  const numero = (remetente && remetente.split("@")[0]) || "Usuario";

  const caminhoTxt = path.join(PASTA_MENUS, `${menuId}.txt`);
  let texto = "";
  if (fs.existsSync(caminhoTxt)) {
    texto = fs.readFileSync(caminhoTxt, "utf-8");
  } else {
    texto = `⚠️ Arquivo menus/${menuId}.txt não encontrado!`;
  }

  // ✅ Garante que texto é string antes de usar replace
  texto = String(texto)
    .replace(/{USUARIO}/g, numero)
    .replace(/{NOME_BOT}/g, NOME_BOT || "MoonBot-MD")
    .replace(/{PREFIXO}/g, PREFIXO || "!");

  // 🖼️🎥 Verifica se tem foto ou vídeo
  let tipoMidia = null;
  let caminhoMidia = null;

  if (menuConfig) {
    const caminhoVideo = path.join(PASTA_MIDIAS, menuConfig.video);
    const caminhoFoto = path.join(PASTA_MIDIAS, menuConfig.foto);

    if (fs.existsSync(caminhoVideo)) {
      tipoMidia = "video";
      caminhoMidia = caminhoVideo;
    } else if (fs.existsSync(caminhoFoto)) {
      tipoMidia = "image";
      caminhoMidia = caminhoFoto;
    }
  }

  return { texto, tipoMidia, caminhoMidia, numero };
}

module.exports = {
  LISTA_MENUS,
  carregarMenu,
  comandos: {
    // ⚙️ COMANDO PRINCIPAL: !menuconfig
    menuconfig: async (sock, msg, args, dados) => {
      const idChat = dados.idChat;
      const remetente = dados.remetente;

      if (!verificarDono(remetente)) return;

      const acao = args[0]?.toLowerCase();
      const menuId = args[1]?.toLowerCase();

      // 📜 Mostra ajuda e lista de menus
      if (!acao || acao === "ajuda" || acao === "lista") {
        let texto = `⚙️ *CONFIGURADOR DE MENUS* ⚙️\n\n`;
        texto += `📋 Menus disponíveis:\n`;
        LISTA_MENUS.forEach((m, i) => {
          texto += `${i + 1}. ${m.nome} → id: *${m.id}*\n`;
        });
        texto += `\n🛠️ *Como usar:*\n`;
        texto += `!menuconfig foto [id] → responda uma FOTO\n`;
        texto += `!menuconfig video [id] → responda um VÍDEO\n`;
        texto += `!menuconfig limpar [id] → remove mídia (só texto)\n`;
        texto += `\nExemplo: !menuconfig foto rpg`;
        return sock.sendMessage(idChat, { text: texto }, { quoted: msg });
      }

      const menuEscolhido = LISTA_MENUS.find(m => m.id === menuId);
      if (!menuEscolhido) {
        return sock.sendMessage(idChat, {
          text: `❌ Menu não encontrado!\nUse !menuconfig lista para ver os ids.`
        }, { quoted: msg });
      }

      const citada = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const { downloadMediaMessage } = require("@whiskeysockets/baileys");

      // 🖼️ Definir FOTO
      if (acao === "foto") {
        if (!citada || (!citada.imageMessage && !citada.jpegThumbnail)) {
          return sock.sendMessage(idChat, {
            text: `⚠️ Responda uma FOTO com:\n!menuconfig foto ${menuEscolhido.id}`
          }, { quoted: msg });
        }

        try {
          const buffer = await downloadMediaMessage(
            { key: msg.message.extendedTextMessage.contextInfo.stanzaId, message: citada },
            "buffer",
            {}
          );
          const caminhoFoto = path.join(PASTA_MIDIAS, menuEscolhido.foto);
          if (fs.existsSync(caminhoFoto)) fs.unlinkSync(caminhoFoto);
          fs.writeFileSync(caminhoFoto, buffer);

          return sock.sendMessage(idChat, {
            text: `✅ *FOTO DEFINIDA!* 🖼️\n\n📋 Menu: ${menuEscolhido.nome}\n\nDigite o comando do menu para ver!`
          }, { quoted: msg });
        } catch {
          return sock.sendMessage(idChat, { text: `❌ Erro ao salvar foto!` }, { quoted: msg });
        }
      }

      // 🎥 Definir VÍDEO
      if (acao === "video") {
        if (!citada || !citada.videoMessage) {
          return sock.sendMessage(idChat, {
            text: `⚠️ Responda um VÍDEO com:\n!menuconfig video ${menuEscolhido.id}`
          }, { quoted: msg });
        }

        try {
          const buffer = await downloadMediaMessage(
            { key: msg.message.extendedTextMessage.contextInfo.stanzaId, message: citada },
            "buffer",
            {}
          );
          const caminhoVideo = path.join(PASTA_MIDIAS, menuEscolhido.video);
          if (fs.existsSync(caminhoVideo)) fs.unlinkSync(caminhoVideo);
          fs.writeFileSync(caminhoVideo, buffer);

          return sock.sendMessage(idChat, {
            text: `✅ *VÍDEO DEFINIDO!* 🎥\n\n📋 Menu: ${menuEscolhido.nome}\n\nDigite o comando do menu para ver!`
          }, { quoted: msg });
        } catch {
          return sock.sendMessage(idChat, { text: `❌ Erro ao salvar vídeo!` }, { quoted: msg });
        }
      }

      // 🗑️ Remover mídia
      if (acao === "limpar" || acao === "texto" || acao === "apagar") {
        const caminhoFoto = path.join(PASTA_MIDIAS, menuEscolhido.foto);
        const caminhoVideo = path.join(PASTA_MIDIAS, menuEscolhido.video);
        let apagou = [];

        if (fs.existsSync(caminhoFoto)) { fs.unlinkSync(caminhoFoto); apagou.push("🖼️ Foto"); }
        if (fs.existsSync(caminhoVideo)) { fs.unlinkSync(caminhoVideo); apagou.push("🎥 Vídeo"); }

        if (apagou.length === 0) {
          return sock.sendMessage(idChat, {
            text: `ℹ️ Nenhuma mídia encontrada!\nO menu já está em modo texto. 📝`
          }, { quoted: msg });
        }

        return sock.sendMessage(idChat, {
          text: `✅ *MÍDIA REMOVIDA!* 🗑️\n\n${apagou.join(" e ")}\n\nAgora só texto. 📝`
        }, { quoted: msg });
      }

      return sock.sendMessage(idChat, { text: `❌ Ação inválida! Use !menuconfig ajuda.` }, { quoted: msg });
    }
  }
};

