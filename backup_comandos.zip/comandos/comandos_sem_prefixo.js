const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const PREFIXO = config.prefixo || "!";
const CAMINHO_DADOS = path.join(__dirname, "..", "dados", "cmd_sem_prefixo.json");

// ✅ Garante que o arquivo existe
if (!fs.existsSync(path.dirname(CAMINHO_DADOS))) {
  fs.mkdirSync(path.dirname(CAMINHO_DADOS), { recursive: true });
}
if (!fs.existsSync(CAMINHO_DADOS)) {
  fs.writeFileSync(CAMINHO_DADOS, JSON.stringify([]));
}

// ✅ Carrega lista
function carregarLista() {
  try {
    return JSON.parse(fs.readFileSync(CAMINHO_DADOS, "utf-8"));
  } catch {
    return [];
  }
}

// ✅ Salva lista
function salvarLista(lista) {
  fs.writeFileSync(CAMINHO_DADOS, JSON.stringify(lista, null, 2));
}

// ✅ Verifica se é dono
function ehDono(remetente) {
  const numero = String(remetente || "").split("@")[0].replace(/\D/g, "");
  const dono = String(config.numeroDono || "").replace(/\D/g, "");
  return numero === dono;
}

module.exports = {
  // ➕ !addcmdp menu — Adiciona comando pra funcionar sem prefixo
  addcmdp: async (sock, msg, args, dados) => {
    const idChat = dados?.idChat || msg.key?.remoteJid;
    const remetente = dados?.remetente || msg.key?.participant || msg.key?.remoteJid;

    if (!ehDono(remetente)) return;

    const cmd = args[0]?.trim().toLowerCase();
    if (!cmd) {
      return sock.sendMessage(idChat, {
        text: `⚠️ Uso: ${PREFIXO}addcmdp <comando>\n\nExemplo: ${PREFIXO}addcmdp menu`
      }, { quoted: msg });
    }

    const lista = carregarLista();
    if (lista.includes(cmd)) {
      return sock.sendMessage(idChat, {
        text: `ℹ️ O comando "${cmd}" JÁ está na lista!`
      }, { quoted: msg });
    }

    lista.push(cmd);
    salvarLista(lista);

    return sock.sendMessage(idChat, {
      text: `✅ Comando "${cmd}" adicionado!\n\nAgora funciona com e sem prefixo! 🚀`
    }, { quoted: msg });
  },

  // 📋 !listar_cmdp — Lista todos os comandos sem prefixo
  listar_cmdp: async (sock, msg, args, dados) => {
    const idChat = dados?.idChat || msg.key?.remoteJid;
    const remetente = dados?.remetente || msg.key?.participant || msg.key?.remoteJid;

    if (!ehDono(remetente)) return;

    const lista = carregarLista();

    if (lista.length === 0) {
      return sock.sendMessage(idChat, {
        text: `📋 Lista de comandos sem prefixo:\n\nVazia! Use ${PREFIXO}addcmdp para adicionar.`
      }, { quoted: msg });
    }

    const texto = lista.map((c, i) => `${i + 1}. 『${c}』`).join("\n");

    return sock.sendMessage(idChat, {
      text: `📋 Comandos sem prefixo:\n\n${texto}\n\nTotal: ${lista.length} comando(s)`
    }, { quoted: msg });
  },

  // 🗑️ !rmcmdp — Remove da lista
  rmcmdp: async (sock, msg, args, dados) => {
    const idChat = dados?.idChat || msg.key?.remoteJid;
    const remetente = dados?.remetente || msg.key?.participant || msg.key?.remoteJid;

    if (!ehDono(remetente)) return;

    const cmd = args[0]?.trim().toLowerCase();
    if (!cmd) {
      return sock.sendMessage(idChat, {
        text: `⚠️ Uso: ${PREFIXO}rmcmdp <comando>\nExemplo: ${PREFIXO}rmcmdp menu\nOu use o número da lista: ${PREFIXO}rmcmdp 1`
      }, { quoted: msg });
    }

    let lista = carregarLista();
    const indice = parseInt(cmd) - 1;

    if (!isNaN(indice) && lista[indice]) {
      const removido = lista.splice(indice, 1)[0];
      salvarLista(lista);
      return sock.sendMessage(idChat, {
        text: `✅ Comando "${removido}" removido da lista!`
      }, { quoted: msg });
    }

    if (!lista.includes(cmd)) {
      return sock.sendMessage(idChat, {
        text: `⚠️ O comando "${cmd}" NÃO está na lista!`
      }, { quoted: msg });
    }

    lista = lista.filter(c => c !== cmd);
    salvarLista(lista);

    return sock.sendMessage(idChat, {
      text: `✅ Comando "${cmd}" removido da lista!`
    }, { quoted: msg });
  },

  // ✅ Exporta a função pra usar no index.js
  carregarComandosSemPrefixo: carregarLista
};

