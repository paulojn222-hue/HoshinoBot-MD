const config = require("../config.js");
const fs = require("fs");
const path = require("path");
const { inicializarUsuario, alterarSaldo } = require("./rpg_saldo.js");

const PREFIXO = config.prefixo || "!";
const CAMINHO_RPG = path.join(__dirname, "..", "dados", "rpg_dados.json");

// 🖼️ Imagem da loja
const IMAGEM_LOJA = "https://i.ibb.co/bjQDS5f5/91d03174088cf3adfe573506893ea0f9.jpg";

// 🛒 Itens da loja
const ITENS_LOJA = [
  {
    id: "pescar_melhorado",
    nome: "🎣 Vara de pescar melhorada",
    descricao: "Aumenta as chances de pegar peixes raros.",
    preco: 800,
    tipo: "permanente"
  },
  {
    id: "picareta_melhorada",
    nome: "⛏️ Picareta melhorada",
    descricao: "Aumenta as chances de encontrar minerais valiosos.",
    preco: 900,
    tipo: "permanente"
  },
  {
    id: "amuleto_sorte",
    nome: "🍀 Amuleto da sorte",
    descricao: "Dá um bônus de sorte nos comandos.",
    preco: 600,
    tipo: "permanente"
  },
  {
    id: "escudo",
    nome: "🛡️ Escudo",
    descricao: "Reduz o valor das multas em crimes.",
    preco: 700,
    tipo: "permanente"
  },
  {
    id: "mochila",
    nome: "🎒 Mochila",
    descricao: "Aumenta o limite de dinheiro que você pode carregar.",
    preco: 500,
    tipo: "permanente"
  }
];

// 📂 Garante que o arquivo existe
if (!fs.existsSync(path.dirname(CAMINHO_RPG))) {
  fs.mkdirSync(path.dirname(CAMINHO_RPG), { recursive: true });
}
if (!fs.existsSync(CAMINHO_RPG)) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify({}));
}

// 💾 Salvar dados
function salvarDados(dados) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify(dados, null, 2));
}

module.exports = {
  comandos: {
    // 🛒 !loja
    loja: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;

      inicializarUsuario(remetente);
      const dados = JSON.parse(fs.readFileSync(CAMINHO_RPG, "utf-8"));
      const usuario = dados[remetente] || {};
      const saldo = usuario.saldo || 0;

      // 📜 Mostrar loja
      if (args.length === 0) {
        let texto = `🛒 *LOJA DO SERVIDOR* 🛒\n\n`;
        texto += `💰 Seu saldo: ${saldo} moedas\n\n`;
        texto += `📦 Itens disponíveis:\n\n`;

        ITENS_LOJA.forEach((item, index) => {
          texto += `${index + 1}. ${item.nome}\n`;
          texto += `   💸 Preço: ${item.preco} moedas\n`;
          texto += `   ℹ️ ${item.descricao}\n\n`;
        });

        texto += `> Use: ${PREFIXO}loja comprar [número]\n`;
        texto += `> Exemplo: ${PREFIXO}loja comprar 1`;

        return sock.sendMessage(idChat, {
          image: { url: IMAGEM_LOJA },
          caption: texto,
          mentions: [remetente]
        }, { quoted: msg });
      }

      // 🛒 Comprar item
      if (args[0].toLowerCase() === "comprar") {
        const numero = parseInt(args[1]);

        if (isNaN(numero) || numero < 1 || numero > ITENS_LOJA.length) {
          return sock.sendMessage(idChat, {
            text: `❌ *Item inválido!*\n\nEscolha um número de 1 a ${ITENS_LOJA.length}.`
          }, { quoted: msg });
        }

        const itemEscolhido = ITENS_LOJA[numero - 1];

        if (saldo < itemEscolhido.preco) {
          return sock.sendMessage(idChat, {
            text: `❌ *Saldo insuficiente!*\n\nVocê tem: ${saldo} moedas\nCusta: ${itemEscolhido.preco} moedas`
          }, { quoted: msg });
        }

        if (!usuario.inventario) usuario.inventario = [];

        const jaTem = usuario.inventario.some(i => i.id === itemEscolhido.id);
        if (jaTem) {
          return sock.sendMessage(idChat, {
            text: `✅ *Você já possui esse item!*\n\n${itemEscolhido.nome} já está no seu inventário.`
          }, { quoted: msg });
        }

        // 💰 Debita e adiciona ao inventário
        alterarSaldo(remetente, -itemEscolhido.preco);
        usuario.inventario.push(itemEscolhido);
        salvarDados(dados);

        return sock.sendMessage(idChat, {
          text: `✅ *COMPRA REALIZADA COM SUCESSO!*\n\n` +
                `📦 Item: ${itemEscolhido.nome}\n` +
                `💸 Preço: ${itemEscolhido.preco} moedas\n\n` +
                `> Use ${PREFIXO}inventario para ver seus itens!`
        }, { quoted: msg });
      }

      // ❌ Uso incorreto
      return sock.sendMessage(idChat, {
        text: `❌ *Como usar:*\n\n` +
              `${PREFIXO}loja → ver os itens\n` +
              `${PREFIXO}loja comprar 1 → comprar o item 1`
      }, { quoted: msg });
    }
  }
};

