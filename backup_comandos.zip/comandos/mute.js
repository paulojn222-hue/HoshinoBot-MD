const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const PREFIXO = config.prefixo || "!";
const CAMINHO_MUTE = path.join(__dirname, "..", "dados", "mute.json");

// ✅ Garante arquivo
if (!fs.existsSync(path.dirname(CAMINHO_MUTE))) {
  fs.mkdirSync(path.dirname(CAMINHO_MUTE), { recursive: true });
}
if (!fs.existsSync(CAMINHO_MUTE)) {
  fs.writeFileSync(CAMINHO_MUTE, JSON.stringify({}));
}

function carregarMute() {
  try { return JSON.parse(fs.readFileSync(CAMINHO_MUTE, "utf-8")); }
  catch { return {}; }
}
function salvarMute(dados) {
  fs.writeFileSync(CAMINHO_MUTE, JSON.stringify(dados, null, 2));
}

// ✅ Verifica se usuário está mutado
function estaMutado(idGrupo, idUsuario) {
  const dados = carregarMute();
  return !!(dados[idGrupo]?.usuarios?.includes(idUsuario));
}

// ✅ Função que verifica admin (agora AQUI mesmo!)
async function ehAdminGrupo(sock, idGrupo, idUsuario) {
  try {
    const meta = await sock.groupMetadata(idGrupo);
    const admin = meta.participants.find(p => p.id === idUsuario && p.admin);
    return !!admin;
  } catch { return false; }
}

// ✅ Comando MUTE
const mute = async (sock, msg, args, dados) => {
  const idChat = dados.idChat;
  const remetente = dados.remetente;
  const mencionado = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];

  if (!idChat.includes("@g.us")) {
    return sock.sendMessage(idChat, { text: `⚠️ Use apenas em grupo!` });
  }
  
  const ehAdmin = await ehAdminGrupo(sock, idChat, remetente);
  if (!ehAdmin) return;

  if (!mencionado) {
    return sock.sendMessage(idChat, { text: `⚠️ Use: ${PREFIXO}mute @usuario` });
  }

  const dadosMute = carregarMute();
  if (!dadosMute[idChat]) dadosMute[idChat] = { usuarios: [] };
  if (!dadosMute[idChat].usuarios.includes(mencionado)) {
    dadosMute[idChat].usuarios.push(mencionado);
  }
  salvarMute(dadosMute);

  await sock.sendMessage(idChat, {
    text: `✅ MUTADO NESTE GRUPO! 🔇\n@${mencionado.split("@")[0]}\nTudo que mandar aqui será apagado! 🗑️`,
    mentions: [mencionado],
    quoted: msg
  });
};

// ✅ Comando UNMUTE
const unmute = async (sock, msg, args, dados) => {
  const idChat = dados.idChat;
  const remetente = dados.remetente;
  const mencionado = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];

  if (!idChat.includes("@g.us")) {
    return sock.sendMessage(idChat, { text: `⚠️ Use apenas em grupo!` });
  }
  
  const ehAdmin = await ehAdminGrupo(sock, idChat, remetente);
  if (!ehAdmin) return;

  if (!mencionado) {
    return sock.sendMessage(idChat, { text: `⚠️ Use: ${PREFIXO}unmute @usuario` });
  }

  const dadosMute = carregarMute();
  if (dadosMute[idChat]?.usuarios) {
    dadosMute[idChat].usuarios = dadosMute[idChat].usuarios.filter(u => u !== mencionado);
    salvarMute(dadosMute);
  }

  await sock.sendMessage(idChat, {
    text: `✅ DESMUTADO! 🔊\n@${mencionado.split("@")[0]} já pode falar!`,
    mentions: [mencionado],
    quoted: msg
  });
};

module.exports = {
  comandos: { mute, unmute },
  estaMutado
};

