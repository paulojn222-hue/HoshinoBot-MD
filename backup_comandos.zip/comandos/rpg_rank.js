const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const PREFIXO = config.prefixo || "!";
const CAMINHO_RPG = path.join(__dirname, "..", "dados", "rpg_dados.json");

// 🖼️ Imagem do ranking
const IMAGEM_RANK = "https://i.ibb.co/MDhpPW43/d342f34b64a6570cae179cdd1125c2b6.jpg"; // ← pode trocar!

if (!fs.existsSync(path.dirname(CAMINHO_RPG))) {
  fs.mkdirSync(path.dirname(CAMINHO_RPG), { recursive: true });
}
if (!fs.existsSync(CAMINHO_RPG)) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify({}));
}

module.exports = {
  comandos: {
    rank: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;

      const dados = JSON.parse(fs.readFileSync(CAMINHO_RPG, "utf-8"));

      // 📋 Transforma os dados em lista e ordena por saldo
      const listaUsuarios = Object.entries(dados)
        .filter(([_, usuario]) => usuario.saldo > 0) // Só quem tem saldo positivo
        .sort((a, b) => (b[1].saldo || 0) - (a[1].saldo || 0)) // Do maior pro menor
        .slice(0, 10); // Top 10

      if (listaUsuarios.length === 0) {
        return sock.sendMessage(idChat, {
          text: `🏆 *RANKING* 🏆\n\nAinda não há jogadores com saldo!\nUse ${PREFIXO}trabalhar para ser o primeiro! 💼`
        }, { quoted: msg });
      }

      // 🏅 Monta o texto do ranking
      let texto = `🏆 *RANKING — TOP 10* 🏆\n\n`;

      listaUsuarios.forEach(([usuarioId, dadosUser], index) => {
        const posicao = index + 1;
        const saldo = dadosUser.saldo || 0;
        const numero = usuarioId.split("@")[0];

        // Medalhas para os 3 primeiros
        let medalha = "";
        if (posicao === 1) medalha = "🥇";
        else if (posicao === 2) medalha = "🥈";
        else if (posicao === 3) medalha = "🥉";
        else medalha = `${posicao}.`;

        texto += `${medalha} @${numero} — ${saldo} moedas 💰\n`;
      });

      // 📍 Posição do usuário atual
      const minhaPosicao = listaUsuarios.findIndex(([id]) => id === remetente);
      if (minhaPosicao !== -1) {
        texto += `\n📍 Sua posição: ${minhaPosicao + 1}º lugar`;
      } else {
        texto += `\n📍 Você ainda não está no top 10! Continue trabalhando! 💪`;
      }

      texto += `\n> Use ${PREFIXO}saldo para ver seu saldo! 💰`;

      // 🖼️ Envia com imagem
      return sock.sendMessage(idChat, {
        image: { url: IMAGEM_RANK },
        caption: texto,
        mentions: listaUsuarios.map(([id]) => id) // Marca todos do top 10
      }, { quoted: msg });
    }
  }
};

