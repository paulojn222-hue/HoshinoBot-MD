const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const PREFIXO = config.prefixo || "!";
const CAMINHO_AFK = path.join(__dirname, "..", "dados", "afk.json");

// ✅ Garante pasta e arquivo
if (!fs.existsSync(path.dirname(CAMINHO_AFK))) {
  fs.mkdirSync(path.dirname(CAMINHO_AFK), { recursive: true });
}
if (!fs.existsSync(CAMINHO_AFK)) {
  fs.writeFileSync(CAMINHO_AFK, JSON.stringify({}));
}

// 📖 Carrega / Salva dados
function carregarAFK() {
  try { return JSON.parse(fs.readFileSync(CAMINHO_AFK, "utf-8")); }
  catch { return {}; }
}
function salvarAFK(dados) {
  fs.writeFileSync(CAMINHO_AFK, JSON.stringify(dados, null, 2));
}

// ⏰ Formata tempo de ausência
function formatarTempo(timestamp) {
  const diff = Date.now() - timestamp;
  const minutos = Math.floor(diff / 60000);
  const horas = Math.floor(minutos / 60);
  if (horas > 0) return `${horas} hora(s)`;
  if (minutos > 0) return `${minutos} minuto(s)`;
  return "poucos segundos";
}

// ✅ Verifica se alguém mencionou um usuário AFK
const verificarMencaoAFK = async (sock, msg, idChat, remetente, texto) => {
  const dados = carregarAFK();
  const mencionados = msg?.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
  
  for (const usuario of mencionados) {
    if (dados[usuario] && usuario !== remetente) {
      await sock.sendMessage(idChat, {
        text: `👤 @${usuario.split("@")[0]} está AFK!\n📌 Motivo: ${dados[usuario].motivo}\n⏰ Desde: ${formatarTempo(dados[usuario].desde)}`,
        mentions: [usuario],
        quoted: msg
      });
    }
  }
};

// ✅ Cancela AFK quando o usuário manda mensagem
const verificarRetornoAFK = async (sock, msg, idChat, remetente) => {
  const dados = carregarAFK();
  if (dados[remetente]) {
    delete dados[remetente];
    salvarAFK(dados);
    await sock.sendMessage(idChat, {
      text: `👋 Bem-vindo de volta! AFK desativado! ✅`,
      quoted: msg
    });
  }
};

// ✅ Função principal do comando
const executar = async (sock, msg, args, dados) => {
  const remetente = msg.key.participant || msg.key.remoteJid;
  const idChat = msg.key.remoteJid;
  const motivo = args.join(" ").trim() || "Estou ausente";

  const afkDados = carregarAFK();
  afkDados[remetente] = {
    motivo: motivo,
    desde: Date.now()
  };
  salvarAFK(afkDados);

  await sock.sendMessage(idChat, {
    text: `😴 AFK ATIVADO!\n📌 Motivo: ${motivo}\n✅ Quando mandar mensagem, volto sozinho!`,
    quoted: msg
  });
};

// ✅ FORMATO EXATO que o index.js espera!
module.exports = {
  comandos: {
    afk: {
      nome: "afk",
      alternativos: ["ausente", "away"],
      executar
    }
  },
  verificarMencaoAFK,
  verificarRetornoAFK
};

