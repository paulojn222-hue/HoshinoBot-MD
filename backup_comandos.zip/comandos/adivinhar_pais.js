const config = require("../config.js");

const PREFIXO = config.prefixo || "!";

// 🚩 Lista de países com bandeira e nome
const LISTA_PAISES = [
  { nome: "Brasil", bandeira: "🇧🇷", dica: "País da América do Sul, maior da região" },
  { nome: "Argentina", bandeira: "🇦🇷", dica: "Vizinho do Brasil, famoso pelo tango" },
  { nome: "França", bandeira: "🇫🇷", dica: "País europeu, Torre Eiffel" },
  { nome: "Estados Unidos", bandeira: "🇺🇸", dica: "País da América do Norte, 50 estrelas" },
  { nome: "Portugal", bandeira: "🇵🇹", dica: "País europeu que fala português" },
  { nome: "Japão", bandeira: "🇯🇵", dica: "País asiático, terra do sol nascente" },
  { nome: "Itália", bandeira: "🇮🇹", dica: "Formato de bota, famoso por pizza e macarrão" },
  { nome: "Espanha", bandeira: "🇪🇸", dica: "País europeu, famoso por touradas e flamenco" },
  { nome: "Alemanha", bandeira: "🇩🇪", dica: "País europeu, famoso por cerveja e carros" },
  { nome: "Canadá", bandeira: "🇨🇦", dica: "Folha de bordo, ao norte dos EUA" },
  { nome: "México", bandeira: "🇲🇽", dica: "Vizinho ao sul dos Estados Unidos" },
  { nome: "Austrália", bandeira: "🇦🇺", dica: "Continente-ilha, canguru e coala" },
  { nome: "China", bandeira: "🇨🇳", dica: "Maior população do mundo, Ásia" },
  { nome: "Índia", bandeira: "🇮🇳", dica: "Segundo país mais populoso, Ásia" },
  { nome: "Rússia", bandeira: "🇷🇺", dica: "Maior país do mundo em extensão" },
  { nome: "Egito", bandeira: "🇪🇬", dica: "Pirâmides e Rio Nilo" },
  { nome: "Inglaterra", bandeira: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", dica: "Parte do Reino Unido, Londres" },
  { nome: "Coreia do Sul", bandeira: "🇰🇷", dica: "País asiático, K-pop e tecnologia" },
  { nome: "Colômbia", bandeira: "🇨🇴", dica: "País da América do Sul, café" },
  { nome: "Chile", bandeira: "🇨🇱", dica: "País da América do Sul, costa longa" }
];

// 📦 Jogos ativos por usuário
const jogosAtivos = {};

// 🔤 Remove acentos e deixa minúsculo
function normalizar(texto) {
  return texto.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

module.exports = {
  comandos: {
    pais: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;

      if (jogosAtivos[remetente]) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Você já tem um jogo em andamento!\nResponda com o nome do país ou aguarde!`
        }, { quoted: msg });
      }

      // 🎲 Sorteia país
      const indice = Math.floor(Math.random() * LISTA_PAISES.length);
      const pais = LISTA_PAISES[indice];

      jogosAtivos[remetente] = {
        nomeCorreto: normalizar(pais.nome),
        nomeExibicao: pais.nome,
        bandeira: pais.bandeira,
        dica: pais.dica,
        tentativas: 0,
        maxTentativas: 3
      };

      await sock.sendMessage(idChat, {
        text: `🚩 *ADIVINHE O PAÍS* 🚩

${pais.bandeira}

💡 Dica: ${pais.dica}

✍️ Qual é o nome desse país?
❌ Tentativas restantes: 3`
      }, { quoted: msg });
    },

    // 🔍 Verifica respostas
    verificarRespostaPais: async (sock, idChat, remetente, texto) => {
      const jogo = jogosAtivos[remetente];
      if (!jogo) return false;

      const resposta = normalizar(texto.trim());
      if (!resposta) return false;

      jogo.tentativas++;

      if (resposta === jogo.nomeCorreto) {
        // ✅ Acertou!
        delete jogosAtivos[remetente];
        await sock.sendMessage(idChat, {
          text: `🎉 *ACERTOU!* ✅\nO país é: *${jogo.nomeExibicao}* ${jogo.bandeira}\n\nQuer jogar de novo? Use ${PREFIXO}pais`
        });
        return true;
      } else if (jogo.tentativas >= jogo.maxTentativas) {
        // ❌ Esgotou tentativas
        delete jogosAtivos[remetente];
        await sock.sendMessage(idChat, {
          text: `😢 *Acabaram as tentativas!*\nO país era: *${jogo.nomeExibicao}* ${jogo.bandeira}\n\nTente de novo com ${PREFIXO}pais!`
        });
        return true;
      } else {
        // ⚠️ Errou, tem mais tentativas
        await sock.sendMessage(idChat, {
          text: `❌ Errou! Tente de novo!\n❌ Tentativas restantes: ${jogo.maxTentativas - jogo.tentativas}`
        });
        return true;
      }
    }
  }
};

