const config = require("../config.js");
const fs = require("fs");
const path = require("path");
const { downloadMediaMessage } = require("@whiskeysockets/baileys");
const pino = require("pino");

const PREFIXO = config.prefixo || "!";
const DONO = String(config.numeroDono || "").replace(/\D/g, "");
const CAMINHO = path.join(__dirname, "..", "dados", "divulgacao.json");

// 📂 GARANTE QUE O ARQUIVO EXISTE COM A ESTRUTURA CORRETA
function inicializarArquivo() {
  const pasta = path.dirname(CAMINHO);
  if (!fs.existsSync(pasta)) fs.mkdirSync(pasta, { recursive: true });
  
  if (!fs.existsSync(CAMINHO)) {
    fs.writeFileSync(CAMINHO, JSON.stringify({
      divulgacoes: [],
      gruposPermitidos: [],
      autoEntrar: false,
      aquecer: false,
      ultimoId: 0,
      agendamentos: []
    }, null, 2));
  } else {
    try {
      const dados = JSON.parse(fs.readFileSync(CAMINHO, "utf-8"));
      if (!dados.agendamentos || !Array.isArray(dados.agendamentos)) dados.agendamentos = [];
      if (!dados.gruposPermitidos || !Array.isArray(dados.gruposPermitidos)) dados.gruposPermitidos = [];
      fs.writeFileSync(CAMINHO, JSON.stringify(dados, null, 2));
    } catch {
      fs.writeFileSync(CAMINHO, JSON.stringify({
        divulgacoes: [], gruposPermitidos: [], autoEntrar: false, aquecer: false, ultimoId: 0, agendamentos: []
      }, null, 2));
    }
  }
}

const ler = () => { inicializarArquivo(); return JSON.parse(fs.readFileSync(CAMINHO, "utf-8")); };
const salvar = d => fs.writeFileSync(CAMINHO, JSON.stringify(d, null, 2));
const ehDono = r => String(r || "").replace(/\D/g, "") === DONO;

// ⏰ Converter tempo
function tempoParaMs(tempoStr) {
  const match = String(tempoStr).match(/^(\d+)(s|m|h)$/i);
  if (!match) return null;
  const valor = parseInt(match[1]);
  const unidade = match[2].toLowerCase();
  if (unidade === "s") return valor * 1000;
  if (unidade === "m") return valor * 60 * 1000;
  if (unidade === "h") return valor * 60 * 60 * 1000;
  return null;
}

// 📋 Listar TODOS os grupos que o bot participa
async function listarTodosGrupos(sock) {
  try {
    const grupos = await sock.groupFetchAllParticipating();
    return Object.values(grupos).map(g => ({ id: g.id, nome: g.subject || "Sem nome" }));
  } catch (e) {
    console.log("❌ Erro ao listar grupos:", e);
    return [];
  }
}

// 🚀 Executar divulgação — COM FOTO/VIDEO OU SÓ TEXTO!
async function executarLote(sock, texto, midia = null, tipoMidia = null) {
  const dados = ler();
  const todosGrupos = await listarTodosGrupos(sock);
  
  // 🔒 Se NENHUM grupo liberado → NÃO DIVULGA!
  if (!dados.gruposPermitidos.length) {
    console.log("⚠️ Nenhum grupo liberado! Divulgação cancelada.");
    return;
  }

  // ✅ Só envia para os grupos LIBERADOS
  const alvo = todosGrupos.filter(grupo => 
    dados.gruposPermitidos.some(liberado => liberado.trim() === grupo.id.trim())
  );

  console.log(`📢 Divulgando em ${alvo.length} grupos (${tipoMidia || "texto"})`);

  const lote = 15;
  for (let i = 0; i < alvo.length; i += lote) {
    for (const grupo of alvo.slice(i, i + lote)) {
      try {
        let mensagem;
        if (midia && tipoMidia === "image") {
          mensagem = { image: midia, caption: texto };
        } else if (midia && tipoMidia === "video") {
          mensagem = { video: midia, caption: texto };
        } else {
          mensagem = { text: texto };
        }
        
        await sock.sendMessage(grupo.id, mensagem);
        console.log(`✅ Enviado para: ${grupo.nome}`);
        await new Promise(r => setTimeout(r, dados.aquecer ? 300000 : 1500));
      } catch (err) {
        console.log(`❌ Falha em ${grupo.nome}: ${err.message}`);
      }
    }
  }
}

// 🔁 Iniciar agendamentos
const intervalosAtivos = {};
async function iniciarAgendamentos(sock) {
  const dados = ler();
  if (!dados.agendamentos || !Array.isArray(dados.agendamentos)) dados.agendamentos = [];

  Object.values(intervalosAtivos).forEach(clearInterval);
  Object.keys(intervalosAtivos).forEach(k => delete intervalosAtivos[k]);

  for (const ag of dados.agendamentos) {
    if (!ag.ativo) continue;
    console.log(`⏰ Agendamento ${ag.id} ativo: a cada ${ag.tempoTexto}`);
    intervalosAtivos[ag.id] = setInterval(async () => {
      console.log(`📢 Divulgando agendamento ${ag.id}...`);
      const midiaBuffer = ag.midia ? Buffer.from(ag.midia, "base64") : null;
      await executarLote(sock, ag.texto, midiaBuffer, ag.tipoMidia);
    }, ag.intervaloMs);
  }
}

module.exports = {
  // ⏰ !rg_divulgacao <tempo> [texto] — AGENDA COM FOTO/VIDEO
  rg_divulgacao: {
    nome: "rg_divulgacao",
    executar: async (sock, msg, args) => {
      const id = msg.key.remoteJid;
      const rem = msg.key.participant || msg.key.remoteJid;
      if (!ehDono(rem)) return;

      if (args.length < 1) {
        return sock.sendMessage(id, {
          text: `⚠️ *USO:* ${PREFIXO}rg_divulgacao <tempo> [texto]\n\n⏰ Exemplos:\n${PREFIXO}rg_divulgacao 30s Minha divulgação!\n${PREFIXO}rg_divulgacao 15m\n\n📸 Para salvar COM FOTO/VIDEO: responda com a mídia e mande o comando!\n⚠️ PRIMEIRO libere os grupos com ${PREFIXO}addgrupo!`
        });
      }

      const tempoStr = args[0];
      const intervaloMs = tempoParaMs(tempoStr);
      if (!intervaloMs) {
        return sock.sendMessage(id, { text: `⚠️ Tempo inválido! Use: 30s / 1m / 2h` });
      }

      // 📸 PEGA FOTO/VIDEO DA MENSAGEM RESPONDIDA
      let midia = null, tipoMidia = null;
      const citada = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      
      // 📝 Texto: pega do comando OU da legenda da mídia
      let texto = args.slice(1).join(" ").trim();
      if (!texto) {
        texto = citada?.imageMessage?.caption || 
                citada?.videoMessage?.caption || 
                `📢 Divulgação — ${tempoStr}`;
      }
      
      // 🖼️ Baixa a mídia se tiver
      if (citada?.imageMessage) {
        tipoMidia = "image";
        midia = await downloadMediaMessage(
          { message: citada, key: { remoteJid: id } },
          "buffer",
          {},
          { logger: pino({ level: "silent" }), reuploadRequest: sock.updateMediaMessage }
        );
      } else if (citada?.videoMessage) {
        tipoMidia = "video";
        midia = await downloadMediaMessage(
          { message: citada, key: { remoteJid: id } },
          "buffer",
          {},
          { logger: pino({ level: "silent" }), reuploadRequest: sock.updateMediaMessage }
        );
      }

      const d = ler();
      d.ultimoId++;
      d.agendamentos.push({
        id: d.ultimoId,
        tempoTexto: tempoStr,
        intervaloMs,
        texto,
        midia: midia ? midia.toString("base64") : null,
        tipoMidia,
        ativo: true,
        criadoEm: Date.now()
      });
      salvar(d);

      if (intervalosAtivos[d.ultimoId]) clearInterval(intervalosAtivos[d.ultimoId]);
      intervalosAtivos[d.ultimoId] = setInterval(async () => {
        const agAtual = d.agendamentos.find(x => x.id === d.ultimoId);
        if (!agAtual) return;
        const midiaBuffer = agAtual.midia ? Buffer.from(agAtual.midia, "base64") : null;
        await executarLote(sock, agAtual.texto, midiaBuffer, agAtual.tipoMidia);
      }, intervaloMs);

      await sock.sendMessage(id, {
        text: `✅ *AGENDAMENTO CRIADO!* 📢\n\n🆔 ID: ${d.ultimoId}\n⏰ Intervalo: ${tempoStr}\n📝 Texto: ${texto}\n📎 Mídia: ${tipoMidia ? (tipoMidia === "image" ? "📸 FOTO" : "🎥 VÍDEO") : "📄 Sem mídia"}\n🔁 Repetindo automaticamente!\n⚠️ Grupos liberados: ${d.gruposPermitidos.length}`
      });
    }
  },

  // 📢 !divulgar — ENVIA AGORA COM FOTO/VIDEO!
  divulgar: {
    nome: "divulgar",
    executar: async (sock, msg, args) => {
      const id = msg.key.remoteJid;
      const rem = msg.key.participant || msg.key.remoteJid;
      if (!ehDono(rem)) return;
      
      const d = ler();
      if (!d.gruposPermitidos.length) {
        return sock.sendMessage(id, { text: `⚠️ NENHUM GRUPO LIBERADO!\nUse ${PREFIXO}addgrupo <id> ou ${PREFIXO}grupos_all primeiro!` });
      }

      // 📸 PEGA FOTO/VIDEO DA MENSAGEM RESPONDIDA — CORRIGIDO!
      let midia = null, tipoMidia = null;
      const citada = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const texto = args.join(" ").trim() || 
                    citada?.imageMessage?.caption || 
                    citada?.videoMessage?.caption || 
                    "📢 Divulgação";

      if (citada?.imageMessage) {
        tipoMidia = "image";
        midia = await downloadMediaMessage(
          { message: citada, key: { remoteJid: id } },
          "buffer",
          {},
          { logger: pino({ level: "silent" }), reuploadRequest: sock.updateMediaMessage }
        );
      } else if (citada?.videoMessage) {
        tipoMidia = "video";
        midia = await downloadMediaMessage(
          { message: citada, key: { remoteJid: id } },
          "buffer",
          {},
          { logger: pino({ level: "silent" }), reuploadRequest: sock.updateMediaMessage }
        );
      }

      await sock.sendMessage(id, { text: `🚀 Enviando em ${d.gruposPermitidos.length} grupos... ${tipoMidia ? ("(" + (tipoMidia === "image" ? "📸 FOTO" : "🎥 VÍDEO") + ")") : ""}` });
      await executarLote(sock, texto, midia, tipoMidia);
      await sock.sendMessage(id, { text: "✅ Divulgação concluída!" });
    }
  },

  // 📋 !lista_divulgacao
  lista_divulgacao: {
    nome: "lista_divulgacao",
    executar: async (sock, msg) => {
      const id = msg.key.remoteJid;
      const rem = msg.key.participant || msg.key.remoteJid;
      if (!ehDono(rem)) return;
      const d = ler();
      if (!d.agendamentos.length) return sock.sendMessage(id, { text: "📋 Nenhum agendamento registrado!" });

      let txt = "📋 *AGENDAMENTOS DE DIVULGAÇÃO:*\n\n";
      d.agendamentos.forEach(ag => {
        txt += `🆔 ID: ${ag.id}\n⏰ Tempo: ${ag.tempoTexto}\n📝 Texto: ${ag.texto.slice(0,40)}...\n📎 Mídia: ${ag.tipoMidia ? (ag.tipoMidia === "image" ? "📸 FOTO" : "🎥 VÍDEO") : "📄 Sem mídia"}\n🔁 Status: ${ag.ativo ? "✅ ATIVO" : "❌ PARADO"}\n━━━━━━━━━━━━━━\n`;
      });
      txt += `\n🔒 Grupos liberados: ${d.gruposPermitidos.length}`;
      await sock.sendMessage(id, { text: txt });
    }
  },

  // 🗑️ !rm_divulgacao id
  rm_divulgacao: {
    nome: "rm_divulgacao",
    executar: async (sock, msg, args) => {
      const id = msg.key.remoteJid;
      const rem = msg.key.participant || msg.key.remoteJid;
      if (!ehDono(rem)) return;
      if (!args[0]) return sock.sendMessage(id, { text: `⚠️ Use: ${PREFIXO}rm_divulgacao 1,2,3` });

      const ids = args[0].split(",").map(Number);
      const d = ler();
      ids.forEach(idAg => { if (intervalosAtivos[idAg]) { clearInterval(intervalosAtivos[idAg]); delete intervalosAtivos[idAg]; } });
      d.agendamentos = d.agendamentos.filter(x => !ids.includes(x.id));
      salvar(d);
      await sock.sendMessage(id, { text: `✅ Removido! ${ids.length} agendamento(s)!` });
    }
  },

  // ▶️ !iniciar_div id
  iniciar_div: {
    nome: "iniciar_div",
    executar: async (sock, msg, args) => {
      const id = msg.key.remoteJid;
      const rem = msg.key.participant || msg.key.remoteJid;
      if (!ehDono(rem)) return;
      if (!args[0]) return sock.sendMessage(id, { text: `⚠️ Use: ${PREFIXO}iniciar_div 1` });

      const d = ler();
      const ag = d.agendamentos.find(x => x.id === parseInt(args[0]));
      if (!ag) return sock.sendMessage(id, { text: "❌ Agendamento não encontrado!" });

      ag.ativo = true; salvar(d);
      if (intervalosAtivos[ag.id]) clearInterval(intervalosAtivos[ag.id]);
      intervalosAtivos[ag.id] = setInterval(async () => {
        const midiaBuffer = ag.midia ? Buffer.from(ag.midia, "base64") : null;
        await executarLote(sock, ag.texto, midiaBuffer, ag.tipoMidia);
      }, ag.intervaloMs);
      await sock.sendMessage(id, { text: `✅ Agendamento ${ag.id} INICIADO!` });
    }
  },

  // ⏹️ !parar_div id
  parar_div: {
    nome: "parar_div",
    executar: async (sock, msg, args) => {
      const id = msg.key.remoteJid;
      const rem = msg.key.participant || msg.key.remoteJid;
      if (!ehDono(rem)) return;
      if (!args[0]) return sock.sendMessage(id, { text: `⚠️ Use: ${PREFIXO}parar_div 1` });

      const d = ler();
      const ag = d.agendamentos.find(x => x.id === parseInt(args[0]));
      if (!ag) return sock.sendMessage(id, { text: "❌ Agendamento não encontrado!" });

      ag.ativo = false; salvar(d);
      if (intervalosAtivos[ag.id]) { clearInterval(intervalosAtivos[ag.id]); delete intervalosAtivos[ag.id]; }
      await sock.sendMessage(id, { text: `⏹️ Agendamento ${ag.id} PARADO!` });
    }
  },

  // 👥 !grupos — Listar todos e ver quais estão liberados
  grupos: {
    nome: "grupos",
    executar: async (sock, msg) => {
      const id = msg.key.remoteJid;
      const rem = msg.key.participant || msg.key.remoteJid;
      if (!ehDono(rem)) return;
      const todos = await listarTodosGrupos(sock);
      const d = ler();
      let txt = `👥 GRUPOS (${todos.length} total | ${d.gruposPermitidos.length} liberados):\n\n`;
      todos.forEach((g, i) => {
        const liberado = d.gruposPermitidos.includes(g.id);
        txt += `${liberado ? "✅" : "🔒"} ${i+1}. ${g.nome}\n   ${g.id}\n`;
      });
      txt += `\n💡 Para liberar: ${PREFIXO}addgrupo <id>\nPara liberar todos: ${PREFIXO}grupos_all`;
      await sock.sendMessage(id, { text: txt });
    }
  },

  // ✅ !grupos_all — Libera TODOS os grupos
  grupos_all: {
    nome: "grupos_all",
    executar: async (sock, msg) => {
      const id = msg.key.remoteJid;
      const rem = msg.key.participant || msg.key.remoteJid;
      if (!ehDono(rem)) return;
      const todos = await listarTodosGrupos(sock);
      const d = ler();
      d.gruposPermitidos = todos.map(g => g.id);
      salvar(d);
      await sock.sendMessage(id, { text: `✅ TODOS os ${todos.length} grupos foram LIBERADOS!` });
    }
  },

  // 🔒 !grupos_nenhum — Bloqueia TODOS
  grupos_nenhum: {
    nome: "grupos_nenhum",
    executar: async (sock, msg) => {
      const id = msg.key.remoteJid;
      const rem = msg.key.participant || msg.key.remoteJid;
      if (!ehDono(rem)) return;
      const d = ler();
      d.gruposPermitidos = [];
      salvar(d);
      await sock.sendMessage(id, { text: "✅ TODOS os grupos BLOQUEADOS! Divulgação NÃO vai funcionar." });
    }
  },

  // ➕ !addgrupo <id> — Libera um grupo
  addgrupo: {
    nome: "addgrupo",
    executar: async (sock, msg, args) => {
      const id = msg.key.remoteJid;
      const rem = msg.key.participant || msg.key.remoteJid;
      if (!ehDono(rem)) return;
      if (!args[0]) return sock.sendMessage(id, { text: `⚠️ Use: ${PREFIXO}addgrupo <id_do_grupo>\nOu ${PREFIXO}grupos_all para liberar todos` });
      
      const d = ler();
      const ids = args[0].split(",").map(x => x.trim());
      let adicionados = 0;
      ids.forEach(grupoId => {
        if (!d.gruposPermitidos.includes(grupoId)) {
          d.gruposPermitidos.push(grupoId);
          adicionados++;
        }
      });
      salvar(d);
      await sock.sendMessage(id, { text: `✅ ${adicionados} grupo(s) liberado(s)!\nTotal liberados: ${d.gruposPermitidos.length}` });
    }
  },

  // ➖ !rmgrupo <id> — Bloqueia um grupo
  rmgrupo: {
    nome: "rmgrupo",
    executar: async (sock, msg, args) => {
      const id = msg.key.remoteJid;
      const rem = msg.key.participant || msg.key.remoteJid;
      if (!ehDono(rem)) return;
      if (!args[0]) return sock.sendMessage(id, { text: `⚠️ Use: ${PREFIXO}rmgrupo <id_do_grupo>` });
      
      const d = ler();
      const ids = args[0].split(",").map(x => x.trim());
      const antes = d.gruposPermitidos.length;
      d.gruposPermitidos = d.gruposPermitidos.filter(x => !ids.includes(x));
      salvar(d);
      await sock.sendMessage(id, { text: `✅ Removido! ${antes - d.gruposPermitidos.length} grupo(s) bloqueado(s).\nTotal liberados: ${d.gruposPermitidos.length}` });
    }
  },

  // 🤖 !autoentrar on/off
  autoentrar: {
    nome: "autoentrar",
    executar: async (sock, msg, args) => {
      const id = msg.key.remoteJid;
      const rem = msg.key.participant || msg.key.remoteJid;
      if (!ehDono(rem)) return;
      const d = ler();
      if (args[0] === "on") { d.autoEntrar = true; await sock.sendMessage(id, { text: "✅ Auto-entrar LIGADO!" }); }
      else if (args[0] === "off") { d.autoEntrar = false; await sock.sendMessage(id, { text: "✅ Auto-entrar DESLIGADO!" }); }
      else return sock.sendMessage(id, { text: `⚠️ ${PREFIXO}autoentrar on/off\nAtual: ${d.autoEntrar ? "✅ LIGADO" : "❌ DESLIGADO"}` });
      salvar(d);
    }
  },

  // 🔥 !aquecer on/off
  aquecer: {
    nome: "aquecer",
    executar: async (sock, msg, args) => {
      const id = msg.key.remoteJid;
      const rem = msg.key.participant || msg.key.remoteJid;
      if (!ehDono(rem)) return;
      const d = ler();
      if (args[0] === "on") { d.aquecer = true; await sock.sendMessage(id, { text: "✅ Aquecer LIGADO — 5min entre lotes!" }); }
      else if (args[0] === "off") { d.aquecer = false; await sock.sendMessage(id, { text: "✅ Aquecer DESLIGADO!" }); }
      else return sock.sendMessage(id, { text: `⚠️ ${PREFIXO}aquecer on/off\nAtual: ${d.aquecer ? "✅ LIGADO" : "❌ DESLIGADO"}` });
      salvar(d);
    }
  },

  verificarLinkGrupo: async (sock, msg, texto, remetente) => {
    const d = ler();
    if (!d.autoEntrar) return;
    if (String(remetente || "").replace(/\D/g, "") !== DONO) return;
    if (!texto.includes("chat.whatsapp.com/invite")) return;
    const codigo = texto.split("/").pop();
    await sock.groupAcceptInvite(codigo).catch(() => {});
  },

  iniciarAgendamentos
};

