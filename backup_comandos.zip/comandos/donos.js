const config = require("../config.js");
const fs = require("fs");
const path = require("path");
const { downloadMediaMessage } = require("@whiskeysockets/baileys");

// 📁 CAMINHOS
const CAMINHO_CONFIG = path.join(__dirname, "..", "config.js");
const CAMINHO_SUBDONOS = path.join(__dirname, "..", "dados", "subdonos.json");
const PASTA_MIDIAS = path.join(__dirname, "..", "midias");
const CAMINHO_FOTO_MENU = path.join(PASTA_MIDIAS, "foto_menu.jpg");
const CAMINHO_VIDEO_MENU = path.join(PASTA_MIDIAS, "video_menu.mp4");

// ⚙️ DADOS
let PREFIXO = config.prefixo || "!";
const NOME_BOT = config.nomeBot || "MoonBot-MDv1";
const DONO_PRINCIPAL_LIMPO = String(config.numeroDono).replace(/\D/g, "");
const MAX_SUBDONOS = 8;

// ✅ Garante pastas e arquivos
if (!fs.existsSync(PASTA_MIDIAS)) fs.mkdirSync(PASTA_MIDIAS, { recursive: true });
if (!fs.existsSync(path.dirname(CAMINHO_SUBDONOS))) {
  fs.mkdirSync(path.dirname(CAMINHO_SUBDONOS), { recursive: true });
}
if (!fs.existsSync(CAMINHO_SUBDONOS)) {
  fs.writeFileSync(CAMINHO_SUBDONOS, "[]", "utf-8");
}

// ==========================================
// ✅ FUNÇÕES DE PERMISSÃO
// ==========================================
function carregarSubdonos() {
  try {
    return JSON.parse(fs.readFileSync(CAMINHO_SUBDONOS, "utf-8"));
  } catch {
    return [];
  }
}

function salvarSubdonos(lista) {
  fs.writeFileSync(CAMINHO_SUBDONOS, JSON.stringify(lista, null, 2), "utf-8");
}

function ehDonoPrincipal(idUsuario) {
  if (!idUsuario) return false;
  const usuarioLimpo = String(idUsuario).replace(/\D/g, "");
  return usuarioLimpo === DONO_PRINCIPAL_LIMPO;
}

function ehDonoOuSubdono(idUsuario) {
  if (!idUsuario) return false;
  const usuarioLimpo = String(idUsuario).replace(/\D/g, "");
  if (usuarioLimpo === DONO_PRINCIPAL_LIMPO) return true;
  const subdonos = carregarSubdonos();
  return subdonos.some(s => String(s.numeroLimpo || s).replace(/\D/g, "") === usuarioLimpo);
}

async function ehAdminGrupo(sock, idGrupo, idUsuario) {
  try {
    const meta = await sock.groupMetadata(idGrupo);
    const admin = meta.participants.find(p => p.id === idUsuario && p.admin);
    return !!admin || ehDonoOuSubdono(idUsuario);
  } catch {
    return ehDonoOuSubdono(idUsuario);
  }
}

// ==========================================
// ✅ OUTRAS FUNÇÕES
// ==========================================
function salvarPrefixo(novoPrefixo) {
  try {
    let conteudo = fs.readFileSync(CAMINHO_CONFIG, "utf-8");
    conteudo = conteudo.replace(/prefixo:\s*["'].+?["']/, `prefixo: "${novoPrefixo}"`);
    fs.writeFileSync(CAMINHO_CONFIG, conteudo, "utf-8");
    PREFIXO = novoPrefixo;
    return true;
  } catch {
    return false;
  }
}

function carregarMenu(nomeArquivo = "menu_principal", usuarioMencao = "") {
  const caminhoMenu = path.join(__dirname, "..", "menus", `${nomeArquivo}.txt`);
  const dados = {
    NOME_BOT: NOME_BOT,
    PREFIXO: PREFIXO,
    DONO_NOME: config.donoNome || "Moon",
    DONO_NUMERO_VISIVEL: config.numeroDonoVisivel || config.numeroDono || "Não definido",
    VERSAO: config.versao || "1.0.0",
    USUARIO: usuarioMencao || "@pessoa"
  };

  if (fs.existsSync(caminhoMenu)) {
    let texto = fs.readFileSync(caminhoMenu, "utf-8");
    texto = texto.replace(/{NOME_BOT}/g, dados.NOME_BOT);
    texto = texto.replace(/{PREFIXO}/g, dados.PREFIXO);
    texto = texto.replace(/{DONO_NOME}/g, dados.DONO_NOME);
    texto = texto.replace(/{DONO_NUMERO_VISIVEL}/g, dados.DONO_NUMERO_VISIVEL);
    texto = texto.replace(/{VERSAO}/g, dados.VERSAO);
    texto = texto.replace(/{USUARIO}/g, dados.USUARIO);
    return texto;
  }
  return `⚠️ Menu não encontrado!`;
}

function pegarMencao(idUsuario) {
  if (!idUsuario) return "@pessoa";
  return `@${String(idUsuario).split("@")[0]}`;
}

function temFotoMenu() {
  return fs.existsSync(CAMINHO_FOTO_MENU);
}

function temVideoMenu() {
  return fs.existsSync(CAMINHO_VIDEO_MENU);
}

// ==========================================
// ✅ COMANDOS
// ==========================================
module.exports = {
  nome: "dono",
  comandos: {

    // 🪪 !meulid — TODOS
    meulid: async (sock, msg, args, dados) => {
      const lid = dados.remetente || dados.idChat;
      return sock.sendMessage(dados.idChat, {
        text: `👑 *SEU LID / IDENTIFICADOR* 👑\n\n🆔 LID: ${lid}\n\n📋 Para usar no config.js:\nDONO_PRINCIPAL_LID: "${lid}"`,
        mentions: [dados.remetente]
      });
    },

// 🛡️ !antipv — Liga/desliga bloqueio automático de quem chama no privado do bot (apenas dono)
 antipv: async (sock, msg, args, dados) => {
   const idChat = dados.idChat || msg.key.remoteJid;
   const remetente = dados.remetente || msg.key.participant || msg.key.remoteJid;
   const DONO = String(config.numeroDono).replace(/\D/g, "");
   const remetenteLimpo = String(remetente).replace(/\D/g, "");
   if (remetenteLimpo !== DONO) {
     return await sock.sendMessage(idChat, { text: "⚠️ Apenas o dono pode usar esse comando!" });
   }
   const CAMINHO_ANTIPV = path.join(__dirname, "..", "dados", "antipv.json");
   function carregarAntiPv() { try { if (!fs.existsSync(CAMINHO_ANTIPV)) return {ativo:false}; return JSON.parse(fs.readFileSync(CAMINHO_ANTIPV,"utf‑8")); } catch { return {ativo:false}; } }
   function salvarAntiPv(d) { fs.writeFileSync(CAMINHO_ANTIPV, JSON.stringify(d,null,2)); }
   const dadosApv = carregarAntiPv();
   dadosApv.ativo = !dadosApv.ativo;
   salvarAntiPv(dadosApv);
   await sock.sendMessage(idChat, {
     text: dadosApv.ativo
       ? "✅ Anti‑PV ativado!\nQuem abrir chat privado com o bot será bloqueado automaticamente."
       : "❌ Anti‑PV desativado!"
   });
 },
 // 🛡️ !anticall — Liga/desliga bloqueio automático de chamadas ao bot (apenas dono)
 anticall: async (sock, msg, args, dados) => {
   const idChat = dados.idChat || msg.key.remoteJid;
   const remetente = dados.remetente || msg.key.participant || msg.key.remoteJid;
   const DONO = String(config.numeroDono).replace(/\D/g, "");
   const remetenteLimpo = String(remetente).replace(/\D/g, "");
   if (remetenteLimpo !== DONO) {
     return await sock.sendMessage(idChat, { text: "⚠️ Apenas o dono pode usar esse comando!" });
   }
   const CAMINHO_ANTICALL = path.join(__dirname, "..", "dados", "anticall.json");
   function carregarAntiCall() { try { if (!fs.existsSync(CAMINHO_ANTICALL)) return {ativo:false}; return JSON.parse(fs.readFileSync(CAMINHO_ANTICALL,"utf‑8")); } catch { return {ativo:false}; } }
   function salvarAntiCall(d) { fs.writeFileSync(CAMINHO_ANTICALL, JSON.stringify(d,null,2)); }
   const dadosAc = carregarAntiCall();
   dadosAc.ativo = !dadosAc.ativo;
   salvarAntiCall(dadosAc);
   await sock.sendMessage(idChat, {
     text: dadosAc.ativo
       ? "✅ Anti‑Call ativado!\nQualquer chamada recebida pelo bot será recusada e o usuário bloqueado."
       : "❌ Anti‑Call desativado!"
   });
 },
    // 🕸 prefixo — TODOS
    prefixo: async (sock, msg, args, dados) => {
      return sock.sendMessage(dados.idChat, {
        text: `🕸*PREFIXO ATUAL* \n\nO prefixo do bot é: 「 ${PREFIXO} 」\n\nExemplo: ${PREFIXO}menu`
      });
    },

    // 👑 rg_prefixo — SÓ DONO PRINCIPAL
    rg_prefixo: async (sock, msg, args, dados) => {
      if (!ehDonoPrincipal(dados.remetente)) return;

      const novo = args[0];
      if (!novo) {
        return sock.sendMessage(dados.idChat, {
          text: `🕸 *Alterar Prefixo* 🕸\n\nUso: ${PREFIXO}rg_prefixo /\n\nSímbolos permitidos:\n!  /  +  =  .  >  $  %  &  #\n\n⚠️ Reinicie o bot após trocar!`
        });
      }

      if (novo.length !== 1) {
        return sock.sendMessage(dados.idChat, {
          text: `⚠️ Use apenas 1 símbolo!\nExemplo: /  !  +`
        });
      }

      const permitidos = ["!", "/", "+", "=", ".", ">", "$", "%", "&", "#", "-", "@"];
      if (!permitidos.includes(novo)) {
        return sock.sendMessage(dados.idChat, {
          text: `⚠️ Símbolo não permitido!\nEscolha entre:\n!  /  +  =  .  >  $  %  &  #`
        });
      }

      const salvo = salvarPrefixo(novo);
      if (salvo) {
        return sock.sendMessage(dados.idChat, {
          text: `✅ *PREFIXO ALTERADO!* 🕸\n\nNovo prefixo: 「 ${novo} 」\n\n⚠️ Reinicie o bot para usar o novo prefixo!`
        });
      } else {
        return sock.sendMessage(dados.idChat, {
          text: `❌ Erro ao salvar o prefixo!`
        });
      }
    },

    // ➕ !addsubdono — SÓ DONO PRINCIPAL
    addsubdono: async (sock, msg, args, dados) => {
      if (!ehDonoPrincipal(dados.remetente)) return;

      const citada = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const mencionado = citada
        ? msg.message.extendedTextMessage.contextInfo.participant
        : null;

      if (!mencionado) {
        return sock.sendMessage(dados.idChat, {
          text: `👑 *Adicionar Sub-Dono* 🕸\n\n📎 Responda a mensagem da pessoa com:\n${PREFIXO}addsubdono`
        });
      }

      const numeroLimpo = String(mencionado).replace(/\D/g, "");
      const subdonos = carregarSubdonos();

      if (numeroLimpo === DONO_PRINCIPAL_LIMPO) {
        return sock.sendMessage(dados.idChat, {
          text: `⚠️ Essa pessoa já é o DONO PRINCIPAL!`
        });
      }

      if (subdonos.some(s => String(s.numeroLimpo || s).replace(/\D/g, "") === numeroLimpo)) {
        return sock.sendMessage(dados.idChat, {
          text: `⚠️ Essa pessoa JÁ é Sub-Dono!`
        });
      }

      if (subdonos.length >= MAX_SUBDONOS) {
        return sock.sendMessage(dados.idChat, {
          text: `⚠️ Limite atingido! (${MAX_SUBDONOS} Sub-Donos no máximo)`
        });
      }

      subdonos.push({
        idCompleto: mencionado,
        numeroLimpo: numeroLimpo,
        dataAdicao: new Date().toLocaleString("pt-BR")
      });
      salvarSubdonos(subdonos);

      return sock.sendMessage(dados.idChat, {
        text: `✅ *SUBDONO ADICIONADO!* 🕸\n\n👤 Usuário: ${pegarMencao(mencionado)}\n📋 Total: ${subdonos.length}/${MAX_SUBDONOS}`,
        mentions: [mencionado]
      });
    },

    // ➖ !rmsubdono — SÓ DONO PRINCIPAL
    rmsubdono: async (sock, msg, args, dados) => {
      if (!ehDonoPrincipal(dados.remetente)) return;

      const citada = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const mencionado = citada
        ? msg.message.extendedTextMessage.contextInfo.participant
        : null;

      if (!mencionado) {
        return sock.sendMessage(dados.idChat, {
          text: `👑 *Remover Sub-Dono* 🕸\n\n📎 Responda a mensagem da pessoa com:\n${PREFIXO}rmsubdono`
        });
      }

      const numeroLimpo = String(mencionado).replace(/\D/g, "");
      let subdonos = carregarSubdonos();
      const existe = subdonos.some(s => String(s.numeroLimpo || s).replace(/\D/g, "") === numeroLimpo);

      if (!existe) {
        return sock.sendMessage(dados.idChat, {
          text: `⚠️ Essa pessoa NÃO é Sub-Dono!`
        });
      }

      subdonos = subdonos.filter(s => String(s.numeroLimpo || s).replace(/\D/g, "") !== numeroLimpo);
      salvarSubdonos(subdonos);

      return sock.sendMessage(dados.idChat, {
        text: `✅ *SUBDONO REMOVIDO!* 🕸\n\n👤 Usuário: ${pegarMencao(mencionado)}\n📋 Total: ${subdonos.length}/${MAX_SUBDONOS}`,
        mentions: [mencionado]
      });
    },

    // 📋 !lista_subdonos — TODOS
    lista_subdonos: async (sock, msg, args, dados) => {
      const subdonos = carregarSubdonos();
      if (subdonos.length === 0) {
        return sock.sendMessage(dados.idChat, {
          text: `📋 *LISTA DE SUBDONOS* 🕸\n\n⚠️ Nenhum Sub-Dono cadastrado!\n\nUse: ${PREFIXO}addsubdono`
        });
      }

      let lista = `📋 *LISTA DE SUBDONOS* 🕸\n\n👑 Dono Principal: ${config.donoNome || "Moon"}\n👤 Sub-Donos: ${subdonos.length}/${MAX_SUBDONOS}\n\n`;
      let mencoes = [];
      subdonos.forEach((s, i) => {
        lista += `${i + 1}. ${pegarMencao(s.idCompleto)}\n`;
        lista += `   📅 Adicionado: ${s.dataAdicao}\n\n`;
        mencoes.push(s.idCompleto);
      });

      return sock.sendMessage(dados.idChat, { text: lista, mentions: mencoes });
    }
  },

  // ✅ EXPORTA AS FUNÇÕES PARA O INDEX.JS USAR
  ehDonoPrincipal,
  ehDonoOuSubdono,
  ehAdminGrupo,
  carregarSubdonos,
  salvarSubdonos,
  salvarPrefixo,
  carregarMenu,
  pegarMencao,
  temFotoMenu,
  temVideoMenu
};

