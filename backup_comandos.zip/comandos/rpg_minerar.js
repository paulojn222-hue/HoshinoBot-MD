const config = require("../config.js");
const fs = require("fs");
const path = require("path");
const { inicializarUsuario, alterarSaldo } = require("./rpg_saldo.js");

const PREFIXO = config.prefixo || "!";
const CAMINHO_RPG = path.join(__dirname, "..", "dados", "rpg_dados.json");
const COOLDOWN_MINERAR = 30 * 60 * 1000; // ⏰ 30 minutos

// 🖼️ Imagem única da mineração
const IMAGEM_MINERAR = "https://i.ibb.co/cKrPx8ZW/0bac905b677ffa3cbf5c65891b7d190d-1.jpg"; // ← troque se quiser

// ⛏️ Tipos de minerais
const MINERAIS = [
  { nome: "🪨 Pedra comum", min: 12, max: 25, chance: 0.40 },
  { nome: "🥉 Bronze", min: 25, max: 45, chance: 0.30 },
  { nome: "🥈 Prata", min: 45, max: 80, chance: 0.18 },
  { nome: "🥇 Ouro", min: 80, max: 140, chance: 0.09 },
  { nome: "💎 Diamante", min: 140, max: 250, chance: 0.03 }
];

if (!fs.existsSync(path.dirname(CAMINHO_RPG))) {
  fs.mkdirSync(path.dirname(CAMINHO_RPG), { recursive: true });
}
if (!fs.existsSync(CAMINHO_RPG)) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify({}));
}

function salvarDados(dados) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify(dados, null, 2));
}

function sortearMineral() {
  const sorteio = Math.random();
  let acumulado = 0;
  for (const mineral of MINERAIS) {
    acumulado += mineral.chance;
    if (sorteio < acumulado) return mineral;
  }
  return MINERAIS[0];
}

module.exports = {
  comandos: {
    minerar: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;

      const dadosUser = inicializarUsuario(remetente);
      const agora = Date.now();

      // ⏰ Verifica cooldown
      if (dadosUser.ultimoMineracao && (agora - dadosUser.ultimoMineracao) < COOLDOWN_MINERAR) {
        const tempoRestante = Math.ceil((COOLDOWN_MINERAR - (agora - dadosUser.ultimoMineracao)) / 60000);
        return sock.sendMessage(idChat, {
          text: `⏳ *JÁ MINEROU HOJE!*\n\nVolte em ${tempoRestante} minutos! ⛏️`
        }, { quoted: msg });
      }

      // ⛏️ Sorteia mineral
      const mineral = sortearMineral();
      let valorGanho = Math.floor(Math.random() * (mineral.max - mineral.min + 1)) + mineral.min;

      // 💾 Salva horário
      const dados = JSON.parse(fs.readFileSync(CAMINHO_RPG, "utf-8"));
      if (!dados[remetente]) dados[remetente] = {};
      dados[remetente].ultimoMineracao = agora;
      salvarDados(dados);

      // 💰 Adiciona moedas
      alterarSaldo(remetente, valorGanho);

      const texto = `⛏️ *MINERAÇÃO* ⛏️

Você encontrou: ${mineral.nome}
💰 Ganhou: ${valorGanho} moedas!

> Use ${PREFIXO}saldo para ver seu total! 💰
> Volte em 30 minutos! ⏰`;

      return sock.sendMessage(idChat, {
        image: { url: IMAGEM_MINERAR },
        caption: texto,
        mentions: [remetente]
      }, { quoted: msg });
    }
  }
};

