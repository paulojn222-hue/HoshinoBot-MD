const config = require("../config.js");
const fs = require("fs");
const path = require("path");
const { inicializarUsuario, alterarSaldo } = require("./rpg_saldo.js");

const PREFIXO = config.prefixo || "!";
const CAMINHO_RPG = path.join(__dirname, "..", "dados", "rpg_dados.json");
const COOLDOWN_CRIME = 45 * 60 * 1000; // ⏰ 45 minutos
const VALOR_MIN = 80;
const VALOR_MAX = 180;
const CHANCE_SUCESSO = 0.10; // 45% de dar certo
const MULTA_MIN = 50;
const MULTA_MAX = 120;

// 🖼️ Imagem única do crime
const IMAGEM_CRIME = "https://i.ibb.co/Zzr3T4D4/08a0875711e6721d2cc00ce3c313eae7.jpg";

if (!fs.existsSync(path.dirname(CAMINHO_RPG))) {
  fs.mkdirSync(path.dirname(CAMINHO_RPG), { recursive: true });
}
if (!fs.existsSync(CAMINHO_RPG)) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify({}));
}

function salvarDados(dados) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify(dados, null, 2));
}

module.exports = {
  comandos: {
    crime: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;

      const dadosUser = inicializarUsuario(remetente);
      const agora = Date.now();

      // ⏰ Cooldown
      if (dadosUser.ultimoCrime && (agora - dadosUser.ultimoCrime) < COOLDOWN_CRIME) {
        const tempoRestante = Math.ceil((COOLDOWN_CRIME - (agora - dadosUser.ultimoCrime)) / 60000);
        return sock.sendMessage(idChat, {
          text: `⏳ *VOCÊ JÁ FOI CRIMINOSO!*\n\nVolte em ${tempoRestante} minutos para tentar de novo! ⛓️`
        }, { quoted: msg });
      }

      // 🎲 Sorteia sucesso ou falha
      const deuCerto = Math.random() < CHANCE_SUCESSO;

      const dados = JSON.parse(fs.readFileSync(CAMINHO_RPG, "utf-8"));
      if (!dados[remetente]) dados[remetente] = {};
      dados[remetente].ultimoCrime = agora;
      salvarDados(dados);

      let texto;

      if (deuCerto) {
        const valorGanho = Math.floor(Math.random() * (VALOR_MAX - VALOR_MIN + 1)) + VALOR_MIN;
        alterarSaldo(remetente, valorGanho);

        texto = `⛓️ *CRIME REALIZADO COM SUCESSO!* ⛓️

💸 *Você ganhou:* ${valorGanho} moedas!
😎 Dinheiro caiu direto na carteira!

> Use ${PREFIXO}saldo para ver seu total! 💰
> Volte em 45 minutos! ⏰`;
      } else {
        const valorMulta = Math.floor(Math.random() * (MULTA_MAX - MULTA_MIN + 1)) + MULTA_MIN;
        alterarSaldo(remetente, -valorMulta);

        texto = `🚔 *FOI PRESO!* 🚔

💸 *Multa de:* ${valorMulta} moedas!
😬 você foi pego e perdeu metade do seu dinheiro!

> Use ${PREFIXO}saldo para ver seu total! 💰
> Volte em 45 minutos! ⏰`;
      }

      // 🖼️ Envia imagem única do crime
      return sock.sendMessage(idChat, {
        image: { url: IMAGEM_CRIME },
        caption: texto,
        mentions: [remetente]
      }, { quoted: msg });
    }
  }
};

