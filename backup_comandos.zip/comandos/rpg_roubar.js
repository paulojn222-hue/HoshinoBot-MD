const config = require("../config.js");
const fs = require("fs");
const path = require("path");
const { inicializarUsuario, alterarSaldo } = require("./rpg_saldo.js");

const PREFIXO = config.prefixo || "!";
const CAMINHO_RPG = path.join(__dirname, "..", "dados", "rpg_dados.json");
const COOLDOWN_ROUBAR = 3 * 60 * 60 * 1000; // ⏰ 3 horas
const LIMITE_POR_COOLDOWN = 3; // máximo 3 vezes por 3h

if (!fs.existsSync(path.dirname(CAMINHO_RPG))) {
  fs.mkdirSync(path.dirname(CAMINHO_RPG), { recursive: true });
}
if (!fs.existsSync(CAMINHO_RPG)) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify({}));
}

function salvarDados(dados) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify(dados, null, 2));
}

function extrairUsuario(mencao) {
  if (!mencao) return null;
  const numero = mencao.replace(/[^0-9]/g, "");
  return numero + "@s.whatsapp.net";
}

module.exports = {
  comandos: {
    roubar: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const alvo = msg.message?.mentionedJidList?.[0] || extrairUsuario(args[0]);

      const dadosUser = inicializarUsuario(remetente);
      const agora = Date.now();

      // ⏰ Verifica cooldown e limite
      if (!dadosUser.ultimosRoubos) dadosUser.ultimosRoubos = [];
      // Remove registros mais antigos que 3h
      dadosUser.ultimosRoubos = dadosUser.ultimosRoubos.filter(tempo => (agora - tempo) < COOLDOWN_ROUBAR);

      if (dadosUser.ultimosRoubos.length >= LIMITE_POR_COOLDOWN) {
        return sock.sendMessage(idChat, {
          text: `⏳ *LIMITE ATINGIDO!*\n\nVocê só pode roubar ${LIMITE_POR_COOLDOWN} vezes a cada 3 horas!\nTente novamente mais tarde! 😈`
        }, { quoted: msg });
      }

      if (!alvo || alvo === remetente) {
        return sock.sendMessage(idChat, {
          text: `❌ *Uso incorreto!*\n\n${PREFIXO}roubar @usuario\n\nVocê precisa marcar alguém para roubar! 😈`
        }, { quoted: msg });
      }

      const dados = JSON.parse(fs.readFileSync(CAMINHO_RPG, "utf-8"));
      if (!dados[alvo]) dados[alvo] = { saldo: 0 };
      if (!dados[alvo].saldo || dados[alvo].saldo <= 0) {
        return sock.sendMessage(idChat, {
          text: `😬 *Essa pessoa não tem moedas para roubar!*\n\nEscolha alguém com mais dinheiro! 💰`
        }, { quoted: msg });
      }

      const saldoAlvo = dados[alvo].saldo;
      const porcentagem = Math.floor(Math.random() * 31) + 10; // 10% a 40%
      const valorRoubado = Math.floor(saldoAlvo * porcentagem / 100);

      // 💸 Executa o roubo
      alterarSaldo(alvo, -valorRoubado);
      alterarSaldo(remetente, valorRoubado);

      // 📝 Registra o roubo
      dadosUser.ultimosRoubos.push(agora);
      salvarDados(dados);

      const numeroAlvo = alvo.split("@")[0];
      const numeroQuemRouba = remetente.split("@")[0];

      return sock.sendMessage(idChat, {
        text: `😈 *ROUBO REALIZADO!* 😈

👤 Você roubou: @${numeroAlvo}
💵 Valor roubado: ${valorRoubado} moedas! (${porcentagem}%)

> Restam ${LIMITE_POR_COOLDOWN - dadosUser.ultimosRoubos.length} tentativas nesse período! ⏳`,
        mentions: [remetente, alvo]
      }, { quoted: msg });
    }
  }
};

