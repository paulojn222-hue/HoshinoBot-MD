const config = require("../config.js");
const fs = require("fs");
const path = require("path");
const { inicializarUsuario, alterarSaldo } = require("./rpg_saldo.js");

const PREFIXO = config.prefixo || "!";
const CAMINHO_RPG = path.join(__dirname, "..", "dados", "rpg_dados.json");
const COOLDOWN_TRABALHAR = 30 * 60 * 1000; // ⏰ 30 minutos

// 📂 Garante arquivo
if (!fs.existsSync(path.dirname(CAMINHO_RPG))) {
  fs.mkdirSync(path.dirname(CAMINHO_RPG), { recursive: true });
}
if (!fs.existsSync(CAMINHO_RPG)) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify({}));
}

// 💼 EMPREGOS + IMAGENS (já na ordem!)
const EMPREGOS = [
  { nome: "🍔 Entregador de comida", min: 25, max: 45, imagem: "https://i.ibb.co/G3G7y00w/3ca47e8350d19aa5cc59ec06fad1c5f3.jpg" },
  { nome: "🏗️ Pedreiro", min: 30, max: 60, imagem: "https://i.ibb.co/S7JBJRWX/b7baaf5adee6ccc6c68f23189810f219-1.jpg" },
  { nome: "🏫 Professor", min: 35, max: 70, imagem: "https://i.ibb.co/60XRyyM3/4795030cb1c0f6c7f975556705c31093-2.jpg" },
  { nome: "💻 Programador", min: 50, max: 100, imagem: "https://i.ibb.co/WvTr07jx/ebdb2c8c85976fe92bafd662ed574711-1.jpg" },
  { nome: "🍞 Padeiro", min: 20, max: 40, imagem: "https://i.ibb.co/n8fVvPgN/9cdd74646b24d92b2fc42a6fabaa47c9.jpg" },
  { nome: "🚚 Motorista", min: 35, max: 65, imagem: "https://i.ibb.co/MkPphBsG/82411d88ed4d59f56e38d6c95b198122.jpg" },
  { nome: "🏥 Enfermeiro", min: 40, max: 80, imagem: "https://i.ibb.co/gZNVP7rm/9c7a3bc3df0c5cddd4f2a369d9523356.jpg" },
  { nome: "🧑‍🍳 Cozinheiro", min: 30, max: 55, imagem: "https://i.ibb.co/F4Rxk7DJ/fd90dd751391fb7ed82e65819193bcab.jpg" },
  { nome: "📦 Entregador de encomendas", min: 28, max: 50, imagem: "https://i.ibb.co/Zz2gzN4R/6b8a08f75bfebc8d9d73f7f63874acbe.jpg" },
  { nome: "🛒 Caixa de supermercado", min: 22, max: 42, imagem: "https://i.ibb.co/Rp01tpb2/69d39f3885e49648dbbcf76e7bdf14ad.jpg" },
  { nome: "🎨 Designer", min: 45, max: 90, imagem: "https://i.ibb.co/35tYwdJ7/934ad93725b56a7b775373186a148cb9.jpg" },
  { nome: "📢 Vendedor", min: 25, max: 85, imagem: "https://i.ibb.co/p66XKRk5/925e73c263224d23334dae5af57ae23e-1.jpg" },
  { nome: "🚒 Bombeiro", min: 40, max: 75, imagem: "https://i.ibb.co/BVzZTFZg/ab1b4ed87b4905a11b3708152d8c65d9.jpg" },
  { nome: "✈️ Piloto de avião", min: 80, max: 150, imagem: "https://i.ibb.co/DH24cK3w/3de7085d96a89c899e544401be684b2f-1.jpg" },
  { nome: "🌾 Agricultor", min: 20, max: 38, imagem: "https://i.ibb.co/8DMZQNM0/99716e0976fcd175c8d4a23255dc8b4e.jpg" },
  { nome: "🏦 Bancário", min: 45, max: 85, imagem: "https://i.ibb.co/B5SY7dc9/1f3781f4323c26523f1628d6037d184d.jpg" },
  { nome: "📺 Youtuber", min: 30, max: 120, imagem: "https://i.ibb.co/DDJwPb18/68119e2b5056ff49bf8271a4b2fc4725.jpg" },
  { nome: "⚽ Jogador de futebol", min: 60, max: 200, imagem: "https://i.ibb.co/DHBRzXgJ/7ef8706bfcb94a552164856ff0846d3f.jpg" },
  { nome: "🔧 Mecânico", min: 32, max: 58, imagem: "https://i.ibb.co/HDhTt62c/f406f36ae2ae4f68f09a0357628350f1.jpg" },
  { nome: "👮 Policial", min: 38, max: 72, imagem: "https://i.ibb.co/DPLFk1Lw/8742709447813ba9ca381c40daf22bc2.jpg" }
];

// 💾 Salvar dados
function salvarDados(dados) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify(dados, null, 2));
}

module.exports = {
  comandos: {
    // 💼 !trabalhar
    trabalhar: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;

      const dadosUser = inicializarUsuario(remetente);
      const agora = Date.now();

      // ⏰ Verifica cooldown
      if (dadosUser.ultimoTrabalho && (agora - dadosUser.ultimoTrabalho) < COOLDOWN_TRABALHAR) {
        const tempoRestante = Math.ceil((COOLDOWN_TRABALHAR - (agora - dadosUser.ultimoTrabalho)) / 60000);
        return sock.sendMessage(idChat, {
          text: `⏳ *VOCÊ JÁ TRABALHOU!*\n\nVolte em ${tempoRestante} minutos para trabalhar de novo! 💼`
        }, { quoted: msg });
      }

      // 👷 Sorteia emprego aleatório
      const emprego = EMPREGOS[Math.floor(Math.random() * EMPREGOS.length)];

      // 💰 Calcula valor
      let valorGanho = Math.floor(Math.random() * (emprego.max - emprego.min + 1)) + emprego.min;
      let bonusTexto = "";

      // 🎁 Verifica bônus da carteira
      if (dadosUser.bonusCarteiraAte && agora < dadosUser.bonusCarteiraAte) {
        valorGanho *= 2;
        bonusTexto = "\n💵 *BÔNUS:* Dobro de moedas ativado!";
      }

      // 💾 Salva horário do trabalho
      const dados = JSON.parse(fs.readFileSync(CAMINHO_RPG, "utf-8"));
      if (!dados[remetente]) dados[remetente] = {};
      dados[remetente].ultimoTrabalho = agora;
      salvarDados(dados);

      // 💰 Adiciona as moedas
      alterarSaldo(remetente, valorGanho);

      // ✅ Monta mensagem
      const texto = `💼 *TRABALHO CONCLUÍDO!* 💼

👷 *Emprego:* ${emprego.nome}
💰 *Ganhou:* ${valorGanho} moedas!${bonusTexto}

> Use ${PREFIXO}saldo para ver seu total! 💰
> Volte em 30 minutos! ⏰`;

      // 🖼️ Envia imagem correspondente ao emprego + legenda
      return sock.sendMessage(idChat, {
        image: { url: emprego.imagem },
        caption: texto,
        mentions: [remetente]
      }, { quoted: msg });
    }
  }
};

