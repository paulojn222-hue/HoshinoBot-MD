const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const PREFIXO = config.prefixo || "!";
const CAMINHO_DADOS = path.join(__dirname, "..", "dados", "emoji_errado.json");

// 📂 Garante que a pasta e arquivo existam
if (!fs.existsSync(path.dirname(CAMINHO_DADOS))) {
  fs.mkdirSync(path.dirname(CAMINHO_DADOS), { recursive: true });
}
if (!fs.existsSync(CAMINHO_DADOS)) {
  fs.writeFileSync(CAMINHO_DADOS, JSON.stringify({}));
}

// 📖 Carrega dados
function carregarDados() {
  try {
    return JSON.parse(fs.readFileSync(CAMINHO_DADOS, "utf-8"));
  } catch {
    return {};
  }
}

function salvarDados(dados) {
  fs.writeFileSync(CAMINHO_DADOS, JSON.stringify(dados, null, 2));
}

// 🎯 Sorteia posição diferente (linha 1-5, coluna 1-8)
function sortearPosicao() {
  const linha = Math.floor(Math.random() * 5) + 1;
  const coluna = Math.floor(Math.random() * 8) + 1;
  return { linha, coluna };
}

// 🎨 Emojis para o jogo
const emojisBase = ["💡", "😀", "😎", "🌙", "🌟", "🔥", "💧", "🍀", "🌸", "⚡"];

// 📦 Estado do jogo ativo por usuário
const jogosAtivos = {};

module.exports = {
  comandos: {
    emoji: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const agora = Date.now();
      const dadosUsuarios = carregarDados();

      // ⏰ Conta jogadas na última hora
      if (!dadosUsuarios[remetente]) dadosUsuarios[remetente] = { jogadas: [], saldo: 0 };
      const jogasNaHora = dadosUsuarios[remetente].jogadas.filter(t => agora - t < 3600000);

      if (jogasNaHora.length >= 4) {
        return sock.sendMessage(idChat, {
          text: `⏰ *LIMITE DE JOGADAS ALCANÇADO!*\n\nVocê pode jogar apenas 4 vezes por hora.\nTente novamente mais tarde! ⏳`
        }, { quoted: msg });
      }

      // 🚫 Verifica se já tem jogo em andamento
      if (jogosAtivos[remetente]) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Você já tem um jogo em andamento!\nUse:\n${PREFIXO}cancelar_emoji\nPara começar um novo!`
        }, { quoted: msg });
      }

      // 🎮 Cria o jogo
      const emojiCerto = emojisBase[Math.floor(Math.random() * emojisBase.length)];
      let emojiErrado;
      do {
        emojiErrado = emojisBase[Math.floor(Math.random() * emojisBase.length)];
      } while (emojiErrado === emojiCerto);

      const { linha, coluna } = sortearPosicao();

      // 📝 Monta o tabuleiro
      let tabuleiro = `🔍 *ENCONTRE O EMOJI DIFERENTE!*\n\n`;
      for (let l = 1; l <= 5; l++) {
        tabuleiro += `${l} `;
        for (let c = 1; c <= 8; c++) {
          tabuleiro += (l === linha && c === coluna) ? emojiErrado : emojiCerto;
        }
        tabuleiro += "\n";
      }

      tabuleiro += `\n💡 *Dica:* Responda com a posição, exemplo: *3 5*\n💰 Prêmio: 30 moedas\n🎮 Jogadas restantes essa hora: ${4 - jogasNaHora.length}`;

      // 💾 Guarda o jogo
      jogosAtivos[remetente] = { linha, coluna, emojiCerto, emojiErrado };

      await sock.sendMessage(idChat, { text: tabuleiro }, { quoted: msg });
    },

    cancelar_emoji: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;

      if (jogosAtivos[remetente]) {
        delete jogosAtivos[remetente];
        return sock.sendMessage(idChat, {
          text: `✅ Jogo cancelado! Use ${PREFIXO}emoji para jogar de novo.`
        }, { quoted: msg });
      } else {
        return sock.sendMessage(idChat, {
          text: `❌ Você não tem nenhum jogo em andamento!`
        }, { quoted: msg });
      }
    },

    // 🔍 Verifica a resposta do usuário
    verificarRespostaEmoji: async (sock, idChat, remetente, texto) => {
      const jogo = jogosAtivos[remetente];

      if (!jogo) {
        return false;
      }

      const entrada = texto.trim();
      let linha = null, coluna = null;

      // Aceita: "2 8" / "2,8" / "linha 2 coluna 8"
      const ambos = entrada.match(/(\d+)\D+(\d+)/);
      if (ambos) {
        linha = parseInt(ambos[1]);
        coluna = parseInt(ambos[2]);
      }

      if (!linha || !coluna) {
        return false;
      }

      const dadosUsuarios = carregarDados();
      if (!dadosUsuarios[remetente]) dadosUsuarios[remetente] = { jogadas: [], saldo: 0 };

      if (linha === jogo.linha && coluna === jogo.coluna) {
        dadosUsuarios[remetente].saldo += 30;
        dadosUsuarios[remetente].jogadas.push(Date.now());
        salvarDados(dadosUsuarios);
        delete jogosAtivos[remetente];

        await sock.sendMessage(idChat, {
          text: `🎉 *PARABÉNS! Você acertou!* ✅\n💰 +30 moedas!\n💵 Saldo: ${dadosUsuarios[remetente].saldo} moedas!\n\nQuer jogar de novo? Use ${PREFIXO}emoji`
        });
      } else {
        await sock.sendMessage(idChat, {
          text: `❌ Errou! Tente de novo 😉\nExemplo: *${jogo.linha} ${jogo.coluna}*`
        });
      }
      return true;
    }
  }
};

