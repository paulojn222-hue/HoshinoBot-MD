const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const PREFIXO = config.prefixo || "!";

// 📂 Caminho do RPG (mesmo do !saldo)
const CAMINHO_RPG = path.join(__dirname, "..", "dados", "rpg.json");

// 📖 Carrega os dados do RPG
function carregarRPG() {
  try {
    if (!fs.existsSync(CAMINHO_RPG)) return {};
    return JSON.parse(fs.readFileSync(CAMINHO_RPG, "utf-8"));
  } catch { return {}; }
}

function salvarRPG(dados) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify(dados, null, 2));
}

// ==========================================
// ✏️ AQUI VOCÊ COLOCA SUAS PALAVRAS!
// ==========================================
const LISTA_PALAVRAS = [
  // 💻 TECNOLOGIA
  { palavra: "javascript", dica: "Linguagem de programação" },
  { palavra: "python", dica: "Linguagem de programação" },
  { palavra: "computador", dica: "Máquina usada para acessar programas" },
  { palavra: "celular", dica: "Dispositivo usado para comunicação" },
  { palavra: "internet", dica: "Rede mundial de computadores" },
  { palavra: "teclado", dica: "Usado para digitar" },
  { palavra: "mouse", dica: "Dispositivo usado para controlar o cursor" },
  { palavra: "monitor", dica: "Tela do computador" },
  { palavra: "programacao", dica: "Área relacionada à criação de softwares" },
  { palavra: "servidor", dica: "Computador que fornece serviços para outros" },
  { palavra: "codigo", dica: "Conjunto de instruções de um programa" },
  { palavra: "aplicativo", dica: "Programa instalado em um dispositivo" },
  { palavra: "whatsapp", dica: "Aplicativo de mensagem" },
  { palavra: "github", dica: "Plataforma usada por programadores" },

  // 🌎 PAÍSES
  { palavra: "brasil", dica: "País da América do Sul" },
  { palavra: "argentina", dica: "País vizinho do Brasil" },
  { palavra: "japao", dica: "País conhecido pelos samurais" },
  { palavra: "china", dica: "Grande país da Ásia" },
  { palavra: "portugal", dica: "País europeu que fala português" },
  { palavra: "franca", dica: "País famoso pela Torre Eiffel" },
  { palavra: "italia", dica: "País conhecido por suas massas e pizzas" },
  { palavra: "alemanha", dica: "País europeu conhecido pela Oktoberfest" },
  { palavra: "mexico", dica: "País da América do Norte" },
  { palavra: "canada", dica: "País conhecido pelo frio intenso" },
  { palavra: "egito", dica: "País famoso pelas pirâmides" },
  { palavra: "australia", dica: "País conhecido pelos cangurus" },

  // 🐶 ANIMAIS
  { palavra: "cachorro", dica: "Animal conhecido como melhor amigo do homem" },
  { palavra: "gato", dica: "Animal doméstico que mia" },
  { palavra: "leao", dica: "Conhecido como rei da selva" },
  { palavra: "tigre", dica: "Grande felino listrado" },
  { palavra: "elefante", dica: "Maior animal terrestre" },
  { palavra: "girafa", dica: "Animal com pescoço muito comprido" },
  { palavra: "macaco", dica: "Animal que costuma viver em árvores" },
  { palavra: "coelho", dica: "Animal conhecido pelas grandes orelhas" },
  { palavra: "cavalo", dica: "Animal usado para montaria" },
  { palavra: "golfinho", dica: "Mamífero que vive no oceano" },
  { palavra: "tubarao", dica: "Predador dos oceanos" },
  { palavra: "aguia", dica: "Ave conhecida por sua excelente visão" },
  { palavra: "pinguim", dica: "Ave que não voa e vive em regiões frias" },
  { palavra: "cobra", dica: "Réptil que rasteja" },
  { palavra: "borboleta", dica: "Inseto com asas coloridas" },

  // 🍔 COMIDAS
  { palavra: "pizza", dica: "Comida italiana muito popular" },
  { palavra: "hamburguer", dica: "Comida feita geralmente com pão e carne" },
  { palavra: "lasanha", dica: "Prato feito com massa e molho" },
  { palavra: "sushi", dica: "Comida tradicional japonesa" },
  { palavra: "chocolate", dica: "Doce feito a partir do cacau" },
  { palavra: "sorvete", dica: "Doce gelado" },
  { palavra: "pipoca", dica: "Milho que estoura quando aquecido" },
  { palavra: "coxinha", dica: "Salgado brasileiro muito popular" },
  { palavra: "pastel", dica: "Salgado geralmente frito" },
  { palavra: "brigadeiro", dica: "Doce brasileiro feito com chocolate" },
  { palavra: "arroz", dica: "Alimento muito comum nas refeições brasileiras" },
  { palavra: "feijao", dica: "Comida muito consumida no Brasil" },
  { palavra: "macarrao", dica: "Massa muito popular" },

  // ⚽ ESPORTES
  { palavra: "futebol", dica: "Esporte mais popular do Brasil" },
  { palavra: "basquete", dica: "Esporte jogado com uma bola e uma cesta" },
  { palavra: "volei", dica: "Esporte jogado sobre uma rede" },
  { palavra: "natacao", dica: "Esporte praticado dentro da água" },
  { palavra: "tenis", dica: "Esporte jogado com raquete" },
  { palavra: "boxe", dica: "Esporte de combate com luvas" },
  { palavra: "corrida", dica: "Esporte baseado em velocidade" },
  { palavra: "surf", dica: "Esporte praticado sobre ondas" },
  { palavra: "skate", dica: "Esporte praticado sobre uma prancha com rodas" },
  { palavra: "xadrez", dica: "Jogo de estratégia disputado em um tabuleiro" },

  // 🎮 JOGOS
  { palavra: "minecraft", dica: "Jogo de blocos e construção" },
  { palavra: "roblox", dica: "Plataforma com diversos jogos" },
  { palavra: "fortnite", dica: "Jogo famoso pelo modo battle royale" },
  { palavra: "freefire", dica: "Battle royale muito popular nos celulares" },
  { palavra: "pokemon", dica: "Franquia de criaturas que podem ser capturadas" },
  { palavra: "sonic", dica: "Personagem azul muito veloz" },
  { palavra: "mario", dica: "Personagem famoso dos videogames" },
  { palavra: "zelda", dica: "Franquia de aventura da Nintendo" },
  { palavra: "valorant", dica: "Jogo de tiro competitivo" },

  // 🎬 FILMES E SÉRIES
  { palavra: "vingadores", dica: "Grupo de heróis da Marvel" },
  { palavra: "batman", dica: "Herói conhecido como Homem-Morcego" },
  { palavra: "superman", dica: "Herói conhecido por sua capa vermelha" },
  { palavra: "homemaranha", dica: "Herói que lança teias" },
  { palavra: "naruto", dica: "Anime sobre um jovem ninja" },
  { palavra: "onepiece", dica: "Anime sobre piratas e um grande tesouro" },
  { palavra: "dragonball", dica: "Anime famoso pelas esferas do dragão" },
  { palavra: "goku", dica: "Protagonista de Dragon Ball" },

  // 🏠 OBJETOS
  { palavra: "mesa", dica: "Móvel usado para apoiar objetos" },
  { palavra: "cadeira", dica: "Usada para sentar" },
  { palavra: "cama", dica: "Móvel usado para dormir" },
  { palavra: "geladeira", dica: "Usada para conservar alimentos" },
  { palavra: "televisao", dica: "Aparelho usado para assistir programas" },
  { palavra: "espelho", dica: "Objeto que reflete nossa imagem" },
  { palavra: "relogio", dica: "Usado para ver as horas" },
  { palavra: "mochila", dica: "Usada para carregar objetos nas costas" },
  { palavra: "guardachuva", dica: "Usado para se proteger da chuva" },
  { palavra: "oculos", dica: "Objeto usado diante dos olhos" },

  // 🌳 NATUREZA
  { palavra: "arvore", dica: "Planta grande com tronco" },
  { palavra: "flor", dica: "Parte colorida de algumas plantas" },
  { palavra: "rio", dica: "Curso natural de água" },
  { palavra: "montanha", dica: "Grande elevação natural do terreno" },
  { palavra: "cachoeira", dica: "Queda natural de água" },
  { palavra: "floresta", dica: "Grande área coberta por árvores" },
  { palavra: "oceano", dica: "Grande extensão de água salgada" },
  { palavra: "praia", dica: "Lugar com areia próximo ao mar" },
  { palavra: "vulcao", dica: "Estrutura que pode liberar lava" },
  { palavra: "deserto", dica: "Região com pouca chuva" },
  { palavra: "nuvem", dica: "Conjunto de pequenas gotas ou cristais no céu" },
  { palavra: "chuva", dica: "Água que cai das nuvens" },

  // 🚗 TRANSPORTES
  { palavra: "carro", dica: "Veículo de quatro rodas" },
  { palavra: "moto", dica: "Veículo de duas rodas com motor" },
  { palavra: "bicicleta", dica: "Veículo de duas rodas movido por pedais" },
  { palavra: "aviao", dica: "Veículo que voa" },
  { palavra: "navio", dica: "Grande veículo que navega pelo mar" },
  { palavra: "onibus", dica: "Veículo usado para transportar várias pessoas" },
  { palavra: "trem", dica: "Veículo que anda sobre trilhos" },
  { palavra: "helicoptero", dica: "Aeronave com hélices" },
  { palavra: "submarino", dica: "Veículo que viaja debaixo da água" },

  // 👨‍🚀 PROFISSÕES
  { palavra: "medico", dica: "Profissional que cuida da saúde" },
  { palavra: "professor", dica: "Profissional que ensina" },
  { palavra: "bombeiro", dica: "Profissional que combate incêndios" },
  { palavra: "policial", dica: "Profissional responsável pela segurança pública" },
  { palavra: "advogado", dica: "Profissional que atua na área jurídica" },
  { palavra: "engenheiro", dica: "Profissional que trabalha com engenharia" },
  { palavra: "programador", dica: "Profissional que desenvolve programas" },
  { palavra: "cozinheiro", dica: "Profissional que prepara alimentos" },
  { palavra: "piloto", dica: "Profissional que conduz aeronaves" },
  { palavra: "jornalista", dica: "Profissional que trabalha com notícias" },

  // 🎨 CORES
  { palavra: "vermelho", dica: "Cor associada ao fogo" },
  { palavra: "azul", dica: "Cor muito presente no céu" },
  { palavra: "verde", dica: "Cor comum nas folhas" },
  { palavra: "amarelo", dica: "Cor do Sol em muitos desenhos" },
  { palavra: "roxo", dica: "Cor formada pela combinação de vermelho e azul" },
  { palavra: "laranja", dica: "Cor que também é nome de uma fruta" },
  { palavra: "rosa", dica: "Cor frequentemente associada a flores" },
  { palavra: "preto", dica: "Cor muito escura" },
  { palavra: "branco", dica: "Cor associada à neve" },

  // 🪐 ESPAÇO
  { palavra: "sol", dica: "Estrela do nosso sistema" },
  { palavra: "lua", dica: "Satélite natural da Terra" },
  { palavra: "terra", dica: "Planeta onde vivemos" },
  { palavra: "marte", dica: "Conhecido como planeta vermelho" },
  { palavra: "jupiter", dica: "Maior planeta do Sistema Solar" },
  { palavra: "saturno", dica: "Planeta famoso pelos seus anéis" },
  { palavra: "venus", dica: "Um dos planetas mais próximos do Sol" },
  { palavra: "estrela", dica: "Corpo celeste que emite luz própria" },
  { palavra: "galaxia", dica: "Grande conjunto de estrelas" },
  { palavra: "cometa", dica: "Corpo celeste que pode possuir uma cauda" },

  // 🎵 MÚSICA
  { palavra: "violao", dica: "Instrumento de cordas muito popular" },
  { palavra: "piano", dica: "Instrumento com teclas" },
  { palavra: "bateria", dica: "Instrumento formado por tambores e pratos" },
  { palavra: "guitarra", dica: "Instrumento elétrico de cordas" },
  { palavra: "flauta", dica: "Instrumento de sopro" },
  { palavra: "musica", dica: "Arte formada por sons" },
  { palavra: "cantor", dica: "Pessoa que canta" },
  { palavra: "microfone", dica: "Usado para captar a voz" },

  // 🧠 CONCEITOS
  { palavra: "amizade", dica: "Relação de carinho entre pessoas" },
  { palavra: "felicidade", dica: "Estado de quem está feliz" },
  { palavra: "liberdade", dica: "Direito de agir sem opressão" },
  { palavra: "coragem", dica: "Capacidade de enfrentar o medo" },
  { palavra: "esperanca", dica: "Expectativa de que algo bom aconteça" },
  { palavra: "respeito", dica: "Consideração pelo próximo" },
  { palavra: "amor", dica: "Sentimento de carinho e afeto" },
  { palavra: "paz", dica: "Ausência de conflitos" },
  { palavra: "sucesso", dica: "Resultado positivo de algo" },
  { palavra: "confianca", dica: "Sentimento de segurança em alguém ou algo" }
];

// 📦 Jogos ativos por usuário
const jogosAtivos = {};

// 🎨 Desenhos da forca
const desenhos = [
  `
  +---+
      |
      |
      |
     ===`,
  `
  +---+
  O   |
      |
      |
     ===`,
  `
  +---+
  O   |
  |   |
      |
     ===`,
  `
  +---+
  O   |
 /|   |
      |
     ===`,
  `
  +---+
  O   |
 /|\\  |
      |
     ===`,
  `
  +---+
  O   |
 /|\\  |
 /    |
     ===`,
  `
  +---+
  O   |
 /|\\  |
 / \\  |
     ===`
];

// 🔤 Remove acentos e deixa tudo minúsculo
function normalizarTexto(texto) {
  return texto.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

module.exports = {
  comandos: {
    forca: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;

      if (jogosAtivos[remetente]) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Você já tem um jogo em andamento!\nUse:\n${PREFIXO}cancelar_forca\nPara começar um novo!`
        }, { quoted: msg });
      }

      // 🎮 Sorteia palavra
      const indice = Math.floor(Math.random() * LISTA_PALAVRAS.length);
      const { palavra, dica } = LISTA_PALAVRAS[indice];
      const palavraNormalizada = normalizarTexto(palavra);

      jogosAtivos[remetente] = {
        palavra,
        palavraNormalizada,
        dica,
        letrasCertas: [],
        letrasErradas: [],
        tentativas: 6
      };

      const jogo = jogosAtivos[remetente];
      const palavraOculta = palavraNormalizada.split("").map(l => l === " " ? " " : "_").join(" ");

      await sock.sendMessage(idChat, {
        text: `🎮 *JOGO DA FORCA* 🎮
${desenhos[0]}

📝 Palavra: ${palavraOculta}
💡 Dica: ${dica}

✍️ Responda com uma letra ou a palavra completa!
❌ Erros restantes: ${jogo.tentativas}`
      }, { quoted: msg });
    },

    cancelar_forca: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;

      if (jogosAtivos[remetente]) {
        const { palavra } = jogosAtivos[remetente];
        delete jogosAtivos[remetente];
        return sock.sendMessage(idChat, {
          text: `✅ Jogo cancelado!\nA palavra era: *${palavra}*\nUse ${PREFIXO}forca para jogar de novo!`
        }, { quoted: msg });
      } else {
        return sock.sendMessage(idChat, {
          text: `❌ Você não tem nenhum jogo em andamento!`
        }, { quoted: msg });
      }
    },

    // 🔍 Verifica respostas (letras ou palavra inteira)
    verificarRespostaForca: async (sock, idChat, remetente, texto) => {
      const jogo = jogosAtivos[remetente];
      if (!jogo) return false;

      const entrada = normalizarTexto(texto.trim());
      if (!entrada) return false;

      // 1️⃣ Tentou acertar a palavra inteira
      if (entrada.length > 1) {
        if (entrada === jogo.palavraNormalizada) {
          // ✅ GANHOU!
          const rpg = carregarRPG();
          if (!rpg[remetente]) rpg[remetente] = { moedas: 0 };
          rpg[remetente].moedas += 20;
          salvarRPG(rpg);
          const saldoAtual = rpg[remetente].moedas;
          delete jogosAtivos[remetente];

          await sock.sendMessage(idChat, {
            text: `🎉 *PARABÉNS! Você acertou!* ✅\nA palavra era: *${jogo.palavra}*\n💰 +20 moedas!\n💵 Saldo: ${saldoAtual} moedas\n\nQuer jogar de novo? Use ${PREFIXO}forca`
          });
          return true;
        } else {
          // ❌ Errou a palavra inteira = perde
          delete jogosAtivos[remetente];
          await sock.sendMessage(idChat, {
            text: `😢 *Você errou a palavra!*\nA palavra era: *${jogo.palavra}*\n\nUse ${PREFIXO}forca para tentar de novo!`
          });
          return true;
        }
      }

      // 2️⃣ Tentou com UMA letra
      const letra = entrada[0];

      // ✅ Letra já foi dita antes
      if (jogo.letrasCertas.includes(letra) || jogo.letrasErradas.includes(letra)) {
        await sock.sendMessage(idChat, { text: `⚠️ Você já tentou essa letra! Tente outra 😉` });
        return true;
      }

      // ✅ Letra certa
      if (jogo.palavraNormalizada.includes(letra)) {
        jogo.letrasCertas.push(letra);

        // Monta a palavra com as letras descobertas
        const palavraOculta = jogo.palavraNormalizada.split("").map(l => {
          return l === " " ? " " : jogo.letrasCertas.includes(l) ? l : "_";
        }).join(" ");

        // ✅ Verifica se ganhou
        if (!palavraOculta.includes("_")) {
          const rpg = carregarRPG();
          if (!rpg[remetente]) rpg[remetente] = { moedas: 0 };
          rpg[remetente].moedas += 20;
          salvarRPG(rpg);
          const saldoAtual = rpg[remetente].moedas;
          delete jogosAtivos[remetente];

          await sock.sendMessage(idChat, {
            text: `🎉 *PARABÉNS! Você acertou!* ✅\nA palavra era: *${jogo.palavra}*\n💰 +20 moedas!\n💵 Saldo: ${saldoAtual} moedas\n\nQuer jogar de novo? Use ${PREFIXO}forca`
          });
          return true;
        }

        // Continua jogando
        await sock.sendMessage(idChat, {
          text: `✅ *Letra certa!* ✅\n${desenhos[6 - jogo.tentativas]}

📝 Palavra: ${palavraOculta}
💡 Dica: ${jogo.dica}
❌ Erros restantes: ${jogo.tentativas}
🔤 Letras erradas: ${jogo.letrasErradas.join(", ") || "nenhuma"}`
        });

      } else {
        // ❌ Letra errada
        jogo.letrasErradas.push(letra);
        jogo.tentativas--;

        // 💀 Perdeu
        if (jogo.tentativas <= 0) {
          delete jogosAtivos[remetente];
          await sock.sendMessage(idChat, {
            text: `💀 *VOCÊ FOI ENFORCADO!* 💀
${desenhos[6]}

A palavra era: *${jogo.palavra}*

Use ${PREFIXO}forca para tentar de novo!`
          });
          return true;
        }

        // Ainda tem tentativas
        const palavraOculta = jogo.palavraNormalizada.split("").map(l => {
          return l === " " ? " " : jogo.letrasCertas.includes(l) ? l : "_";
        }).join(" ");

        await sock.sendMessage(idChat, {
          text: `❌ *Letra errada!* ❌
${desenhos[6 - jogo.tentativas]}

📝 Palavra: ${palavraOculta}
💡 Dica: ${jogo.dica}
❌ Erros restantes: ${jogo.tentativas}
🔤 Letras erradas: ${jogo.letrasErradas.join(", ")}`
        });
      }

      return true;
    }
  }
};

