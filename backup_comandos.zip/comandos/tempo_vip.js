const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const CAMINHO_VIPS = path.join(__dirname, "..", "dados", "vips.json");

function carregarVips() {
  if (!fs.existsSync(CAMINHO_VIPS)) return {};
  try { return JSON.parse(fs.readFileSync(CAMINHO_VIPS, "utf-8")); }
  catch { return {}; }
}

function formatarTempo(ms) {
  if (ms <= 0) return "0d 0h 0m 0s";
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  const d = Math.floor(h / 24);
  return `${d}d ${h % 24}h ${m % 60}m ${s % 60}s`;
}

module.exports = {
  nome: "tempo_vip",
  comandos: {
    tempo_vip: async (sock, msg, args, dados) => {
      const idChat = dados.idChat;
      const usuario = dados.remetente;
      const idLimpo = String(usuario).replace(/\D/g, "");
      const vips = carregarVips();
      const donoLimpo = String(config.numeroDono).replace(/\D/g, "");
      
      // É o DONO?
      if (idLimpo === donoLimpo) {
        return sock.sendMessage(idChat, {
          text: `👑 *VOCÊ É O DONO!*\n\n♾️ Acesso ILIMITADO — Vitalício ✅`
        });
      }
      
      // Procura nos VIPs
      let dadosVip = null;
      for (const [id, info] of Object.entries(vips)) {
        if (String(id).replace(/\D/g, "") === idLimpo) {
          dadosVip = info;
          break;
        }
      }
      
      if (!dadosVip) {
        return sock.sendMessage(idChat, {
          text: `💎 *VOCÊ NÃO É VIP!*\n\nUse !vip para ver os planos e aproveitar! ✨`
        });
      }
      
      // Vitalício?
      if (!dadosVip.fim) {
        return sock.sendMessage(idChat, {
          text: `💎 *SEU STATUS VIP* 🕸\n\n👤 Usuário: ${msg.pushName || "Você"}\n🎯 Status: ✅ ATIVO\n♾️ Tipo: VITALÍCIO\n\n✨ Aproveite sempre! 💜`
        });
      }
      
      const restante = dadosVip.fim - Date.now();
      const ativo = restante > 0;
      const tempoFormatado = formatarTempo(Math.max(0, restante));
      
      const texto = `
💎 *SEU STATUS VIP* 🕸

👤 *Usuário:* ${msg.pushName || "Você"}
🎯 *Status:* ${ativo ? "✅ ATIVO" : "⚠️ VENCIDO"}
⏳ *Tempo restante:* ${tempoFormatado}
📅 *Válido até:* ${new Date(dadosVip.fim).toLocaleString("pt-BR")}

${ativo ? "✨ Aproveite seus benefícios!" : "Entre em contato para renovar! 💜"}
`.trim();
      
      return sock.sendMessage(idChat, { text: texto });
    }
  }
};

