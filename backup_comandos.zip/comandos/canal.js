const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const PREFIXO = config.prefixo || "!";
const NOME_BOT = config.nomeBot || "SukunaBot-MD";
const DONO_PRINCIPAL_LIMPO = String(config.numeroDono).replace(/\D/g, "");

// 📁 Caminho das configurações do canal
const CAMINHO_CANAL = path.join(__dirname, "..", "dados", "canal.json");

// ✅ Garante arquivo
if (!fs.existsSync(path.dirname(CAMINHO_CANAL))) {
  fs.mkdirSync(path.dirname(CAMINHO_CANAL), { recursive: true });
}
if (!fs.existsSync(CAMINHO_CANAL)) {
  fs.writeFileSync(CAMINHO_CANAL, JSON.stringify({
    canalAtivo: false,
    jidCanal: "",
    linkCanal: ""
  }, null, 2));
}

// ✅ Funções auxiliares
function ehDonoPrincipal(idUsuario) {
  if (!idUsuario) return false;
  const limpo = String(idUsuario).replace(/\D/g, "");
  return limpo === DONO_PRINCIPAL_LIMPO;
}

function carregarCanal() {
  try {
    return JSON.parse(fs.readFileSync(CAMINHO_CANAL, "utf-8"));
  } catch {
    return { canalAtivo: false, jidCanal: "", linkCanal: "" };
  }
}

function salvarCanal(dados) {
  fs.writeFileSync(CAMINHO_CANAL, JSON.stringify(dados, null, 2), "utf-8");
}

module.exports = {
  carregarCanal,

  nome: "canal",
  comandos: {

    // 📢 !channel / !setchannel — SÓ DONO
    channel: {
      nome: "channel",
      alternativos: ["setchannel", "canal", "config_canal"],
      executar: async (sock, msg, args, dados) => {
        if (!ehDonoPrincipal(dados.remetente)) return;

        const link = args[0];

        // ❌ Desativar canal
        if (link === "0" || link === "off" || link === "desativar") {
          salvarCanal({
            canalAtivo: false,
            jidCanal: "",
            linkCanal: ""
          });
          return sock.sendMessage(dados.idChat, {
            text: `⚠️ *CANAL DESATIVADO!* 📢\n\nO canal não será mais compartilhado nas mensagens.`
          });
        }

        // ⚠️ Sem link
        if (!link) {
          const cfg = carregarCanal();
          if (cfg.canalAtivo) {
            return sock.sendMessage(dados.idChat, {
              text: `📢 *CANAL JÁ ATIVO!* ✅\n\n🆔 ID: ${cfg.jidCanal}\n🔗 Link: ${cfg.linkCanal}\n\nPara desativar:\n${PREFIXO}channel 0`
            });
          }
          return sock.sendMessage(dados.idChat, {
            text: `⚠️ *USO INCORRETO!* 📢\n\nAtivar:\n${PREFIXO}channel <link_do_canal>\n\nDesativar:\n${PREFIXO}channel 0\n\n💡 Exemplo:\n${PREFIXO}channel https://whatsapp.com/channel/0029VbXYZ...`
          });
        }

        // 🔍 Extrai o código do canal
        const codigoCanal = link
          .trim()
          .replace(/.*whatsapp\.com\/channel\//, "")
          .replace(/.*wa\.me\/channel\//, "")
          .split(/[\/?\s]/)[0];

        if (!codigoCanal) {
          return sock.sendMessage(dados.idChat, {
            text: `❌ *LINK INVÁLIDO!* ⚠️\n\nEnvie o link completo do canal do WhatsApp!`
          });
        }

        try {
          // 🔍 Busca metadados do canal
          const meta = await sock.newsletterMetadata("invite", codigoCanal);
          const jidReal = meta?.jid || meta?.id;

          if (!jidReal) {
            return sock.sendMessage(dados.idChat, {
              text: `❌ *Não foi possível encontrar o canal!* ⚠️\nVerifique o link e tente novamente.`
            });
          }

          const linkCanal = `https://whatsapp.com/channel/${codigoCanal}`;

          // 💾 Salva as configurações
          salvarCanal({
            canalAtivo: true,
            jidCanal: jidReal,
            linkCanal: linkCanal
          });

          // ✅ Resposta com botão de ver canal
          return sock.sendMessage(dados.idChat, {
            text: `⚠️ *CHANNEL* ⚠️\n\n✅ *CHANNEL ATIVO COM SUCESSO SENHOR(A)!* ✨\n\n🏅 → ID: ${jidReal}\n📎 → LINK: ${linkCanal}`,
            contextInfo: {
              forwardingScore: 999,
              isForwarded: true,
              forwardedNewsletterMessageInfo: {
                newsletterJid: jidReal,
                newsletterName: `${NOME_BOT} — Canal Oficial`,
                serverMessageId: 1
              }
            }
          });

        } catch (e) {
          console.log("❌ Erro ao buscar canal:", e);
          return sock.sendMessage(dados.idChat, {
            text: `❌ *ERRO AO BUSCAR CANAL!* ⚠️\n\nVerifique o link e tente novamente.\nErro: ${e.message}`
          });
        }
      }
    }
  }
};

