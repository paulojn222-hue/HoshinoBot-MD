const config = require("../config.js");
const fs = require("fs");
const path = require("path");

// 📁 CAMINHOS
const CAMINHO_ALUGUEIS = path.join(__dirname, "..", "dados", "alugueis.json");
const CAMINHO_SUBDONOS = path.join(__dirname, "..", "dados", "subdonos.json");
const CAMINHO_CONFIG_GLOBAL = path.join(__dirname, "..", "dados", "aluguel_global.json");

// ⚙️ DADOS
const PREFIXO = config.prefixo || "!";
const NOME_BOT = config.nomeBot || "SukunaBot-MD";
const DONO_PRINCIPAL_LIMPO = String(config.numeroDono).replace(/\D/g, "");
const CRIADOR_NOME = "Moon";
const CRIADOR_NUMERO = "+55 81 9564-7053";

// ✅ Garante pastas
if (!fs.existsSync(path.dirname(CAMINHO_ALUGUEIS))) {
  fs.mkdirSync(path.dirname(CAMINHO_ALUGUEIS), { recursive: true });
}

// ✅ Garante arquivo de configuração global
function garantirArquivoGlobal() {
  const pasta = path.dirname(CAMINHO_CONFIG_GLOBAL);
  if (!fs.existsSync(pasta)) fs.mkdirSync(pasta, { recursive: true });
  if (!fs.existsSync(CAMINHO_CONFIG_GLOBAL)) {
    fs.writeFileSync(CAMINHO_CONFIG_GLOBAL, JSON.stringify({
      aluguelGlobalAtivo: false
    }, null, 2));
  }
}
garantirArquivoGlobal();

// ✅ Carrega configuração global
function carregarConfigGlobal() {
  try {
    return JSON.parse(fs.readFileSync(CAMINHO_CONFIG_GLOBAL, "utf-8"));
  } catch {
    return { aluguelGlobalAtivo: false };
  }
}
function salvarConfigGlobal(dados) {
  fs.writeFileSync(CAMINHO_CONFIG_GLOBAL, JSON.stringify(dados, null, 2), "utf-8");
}

// ✅ Carrega Sub-Donos
function carregarSubdonos() {
  if (!fs.existsSync(CAMINHO_SUBDONOS)) return [];
  try { return JSON.parse(fs.readFileSync(CAMINHO_SUBDONOS, "utf-8")); }
  catch { return []; }
}

// ✅ Verifica permissões
function ehDonoPrincipal(idUsuario) {
  if (!idUsuario) return false;
  return String(idUsuario).replace(/\D/g, "") === DONO_PRINCIPAL_LIMPO;
}
function ehDonoOuSubdono(idUsuario) {
  if (!idUsuario) return false;
  const usuarioLimpo = String(idUsuario).replace(/\D/g, "");
  if (usuarioLimpo === DONO_PRINCIPAL_LIMPO) return true;
  return carregarSubdonos().some(s => String(s).replace(/\D/g, "") === usuarioLimpo);
}

// ✅ Conversor de tempo
function converterTempoParaMs(texto) {
  const m = texto.match(/^(\d+)([smhd])$/);
  if (!m) return null;
  const v = parseInt(m[1]);
  const u = m[2];
  if (u === 's') return v * 1000;
  if (u === 'm') return v * 60 * 1000;
  if (u === 'h') return v * 60 * 60 * 1000;
  if (u === 'd') return v * 24 * 60 * 60 * 1000;
  return null;
}
function formatarTempo(ms) {
  if (ms < 60000) return `${Math.floor(ms / 1000)} segundos`;
  if (ms < 3600000) return `${Math.floor(ms / 60000)} minutos`;
  if (ms < 86400000) return `${Math.floor(ms / 3600000)} horas`;
  return `${Math.floor(ms / 86400000)} dias`;
}

// ✅ Pega LINK DE CONVITE do grupo
async function pegarLinkConviteReal(sock, idGrupo) {
  try {
    const codigoConvite = await sock.groupInviteCode(idGrupo);
    return `https://chat.whatsapp.com/${codigoConvite}`;
  } catch (erro) {
    console.log("⚠️ Não consegui pegar o link do grupo:", erro?.message);
    const numero = idGrupo.split("@")[0];
    return `https://wa.me/${numero}`;
  }
}

// ✅ Carrega e salva alugueis
function carregarAlugueis() {
  if (!fs.existsSync(CAMINHO_ALUGUEIS)) {
    fs.writeFileSync(CAMINHO_ALUGUEIS, "{}", "utf-8");
    return {};
  }
  try { return JSON.parse(fs.readFileSync(CAMINHO_ALUGUEIS, "utf-8")); }
  catch { return {}; }
}
function salvarAlugueis(dados) {
  fs.writeFileSync(CAMINHO_ALUGUEIS, JSON.stringify(dados, null, 2), "utf-8");
}

// ✅ Verifica aluguel
function verificarAluguelAtivo(idGrupo) {
  const cfgGlobal = carregarConfigGlobal();
  if (!cfgGlobal.aluguelGlobalAtivo) {
    return true;
  }
  const alugueis = carregarAlugueis();
  if (!alugueis[idGrupo]) {
    return false;
  }
  const fim = alugueis[idGrupo].fim;
  if (Date.now() > fim) {
    delete alugueis[idGrupo];
    salvarAlugueis(alugueis);
    return { venceu: true };
  }
  return true;
}

// ✅ Extrai usuário marcado
function extrairUsuarioMarcado(msg) {
  const citada = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  if (citada?.participant) return citada.participant;
  const mencoes = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
  return mencoes[0] || null;
}

module.exports = {
  nome: "aluguel",
  verificarAluguelAtivo,

  comandos: {

    // 🌐 !aluguel_global on/off
    aluguel_global: async (sock, msg, args, dados) => {
      if (!ehDonoOuSubdono(dados.remetente)) return;
      const idChat = dados.idChat;
      const opcao = args[0]?.toLowerCase();
      const cfg = carregarConfigGlobal();

      if (opcao === "on" || opcao === "ativar") {
        cfg.aluguelGlobalAtivo = true;
        salvarConfigGlobal(cfg);
        return sock.sendMessage(idChat, {
          text: `🔒 *ALUGUEL GLOBAL ATIVADO!*\n\nAgora o bot só funciona em grupos que tenham aluguel registrado!`
        });
      }

      if (opcao === "off" || opcao === "desativar") {
        cfg.aluguelGlobalAtivo = false;
        salvarConfigGlobal(cfg);
        return sock.sendMessage(idChat, {
          text: `🔓 *ALUGUEL GLOBAL DESATIVADO!*\n\nO bot funciona em TODOS os grupos sem restrição!`
        });
      }

      const status = cfg.aluguelGlobalAtivo ? "🔒 ATIVADO" : "🔓 DESATIVADO";
      return sock.sendMessage(idChat, {
        text: `🌐 *ALUGUEL GLOBAL*\n\nStatus atual: ${status}\n\nComandos:\n├─ ${PREFIXO}aluguel_global on — Bloquear para só grupos com aluguel\n└─ ${PREFIXO}aluguel_global off — Liberar para todos os grupos`
      });
    },

    // ⚙️ !add_aluguel @user 1d
    add_aluguel: async (sock, msg, args, dados) => {
      if (!ehDonoOuSubdono(dados.remetente)) return;
      const idChat = dados.idChat;

      if (!idChat.includes("@g.us")) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Use este comando apenas dentro de grupos!`
        });
      }

      const usuarioAlugou = extrairUsuarioMarcado(msg);
      const tempoTexto = args.find(a => /^\d+[smhd]$/.test(a));

      if (!usuarioAlugou) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Marque quem está alugando!\n\nUso: ${PREFIXO}add_aluguel @usuario 7d`
        });
      }

      const tempoMs = converterTempoParaMs(tempoTexto);
      if (!tempoMs) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Tempo inválido!\n\nUso: ${PREFIXO}add_aluguel @usuario 1m / 1h / 1d\n\nExemplos:\n├─ 7d = 7 dias\n├─ 30d = 30 dias\n└─ 1h = 1 hora`
        });
      }

      const alugueis = carregarAlugueis();
      const nomeGrupo = (await sock.groupMetadata(idChat)).subject;
      const numeroAlugou = usuarioAlugou.split("@")[0];
      const linkConviteReal = await pegarLinkConviteReal(sock, idChat);

      alugueis[idChat] = {
        nomeGrupo,
        idGrupo: idChat,
        linkGrupo: linkConviteReal,
        inicio: Date.now(),
        fim: Date.now() + tempoMs,
        alugadoPor: usuarioAlugou,
        alugadoPorNumero: numeroAlugou
      };
      salvarAlugueis(alugueis);

      return sock.sendMessage(idChat, {
        text: `✅ *ALUGUEL ADICIONADO!*\n\n👥 Grupo: ${nomeGrupo}\n🔗 Link: ${linkConviteReal}\n👤 Alugado por: @${numeroAlugou}\n⏳ Duração: ${formatarTempo(tempoMs)}\n📅 Válido até: ${new Date(alugueis[idChat].fim).toLocaleString("pt-BR")}`
      }, { mentions: [usuarioAlugou] });
    },

    // 🗑️ !rmaluguel 1,2,3
    rmaluguel: async (sock, msg, args, dados) => {
      if (!ehDonoOuSubdono(dados.remetente)) return;
      const idChat = dados.idChat;
      const alugueis = carregarAlugueis();
      const idsGrupos = Object.keys(alugueis);

      if (idsGrupos.length === 0) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Não há nenhum aluguel ativo para remover!`
        });
      }

      const entrada = args[0]?.trim();
      if (!entrada) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Informe o(s) número(s) da lista!\n\nExemplo: ${PREFIXO}rmaluguel 1,2,3\nVeja os números com: ${PREFIXO}alugueis`
        });
      }

      const numeros = entrada.split(",").map(n => parseInt(n.trim()) - 1);
      const removidos = [];
      const naoExistem = [];

      numeros.forEach(num => {
        if (num >= 0 && num < idsGrupos.length) {
          removidos.push(alugueis[idsGrupos[num]].nomeGrupo);
          delete alugueis[idsGrupos[num]];
        } else {
          naoExistem.push(num + 1);
        }
      });
      salvarAlugueis(alugueis);

      let resposta = "";
      if (removidos.length > 0) {
        resposta += `✅ *Removido(s):*\n${removidos.map(nome => `• ${nome}`).join("\n")}\n`;
      }
      if (naoExistem.length > 0) {
        resposta += `\n⚠️ *Não encontrado(s):* ${naoExistem.join(", ")}`;
      }

      return sock.sendMessage(idChat, { text: resposta });
    },

    // 📋 !alugueis
    alugueis: async (sock, msg, args, dados) => {
      if (!ehDonoOuSubdono(dados.remetente)) return;
      const idChat = dados.idChat;
      const alugueis = carregarAlugueis();
      const ids = Object.keys(alugueis);

      if (ids.length === 0) {
        return sock.sendMessage(idChat, {
          text: `📋 *GRUPOS COM ALUGUEL*\n\n⚠️ Nenhum grupo com aluguel ativo no momento!`
        });
      }

      const cfgGlobal = carregarConfigGlobal();
      let texto = `📋 *GRUPOS COM ALUGUEL* ${ids.length} ativo(s)\n🌐 Aluguel Global: ${cfgGlobal.aluguelGlobalAtivo ? "🔒 ATIVADO" : "🔓 DESATIVADO"}\n\n`;

      for (let i = 0; i < ids.length; i++) {
        const id = ids[i];
        const a = alugueis[id];

        if (!a.linkGrupo || a.linkGrupo.includes("wa.me/")) {
          a.linkGrupo = await pegarLinkConviteReal(sock, id);
        }

        const restante = a.fim - Date.now();
        texto += `${i + 1}. ${a.nomeGrupo}\n`;
        texto += `   🔗 Link: ${a.linkGrupo}\n`;
        if (a.alugadoPor) {
          texto += `   👤 Alugado por: @${a.alugadoPorNumero || a.alugadoPor.split("@")[0]}\n`;
        }
        texto += `   ⏳ Restante: ${restante > 0 ? formatarTempo(restante) : '⚠️ Vencido!'}\n\n`;
      }

      salvarAlugueis(alugueis);
      texto += `🗑️ Remover: ${PREFIXO}rmaluguel 1,2,3`;

      return sock.sendMessage(idChat, { text: texto });
    },

    // 📦 !alugar
    alugar: async (sock, msg, args, dados) => {
      const idChat = dados.idChat;
      const planos = config.planosAluguel || [
        { id: 1, nome: "Semanal", valor: "R$ XX,XX" },
        { id: 2, nome: "Mensal", valor: "R$ XX,XX" },
        { id: 3, nome: "Anual", valor: "R$ XX,XX" }
      ];

      const escolha = args[0]?.trim();

      if (!escolha || !/^\d+$/.test(escolha)) {
        let texto = `📦 *PLANOS DE ALUGUEL DO ${NOME_BOT}*\n\nEscolha o número do plano e entre em contato:\n\n`;
        planos.forEach(p => {
          texto += `${p.id}. ${p.nome} — ${p.valor}\n`;
        });
        texto += `\n💡 Use: ${PREFIXO}alugar 1 para receber os dados de contato!`;
        return sock.sendMessage(idChat, { text: texto });
      }

      const planoEscolhido = planos.find(p => p.id === parseInt(escolha));
      if (!planoEscolhido) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Plano não encontrado!\n\nEscolha um número da lista com: ${PREFIXO}alugar`
        });
      }

      const contatoDono = config.numeroDonoVisivel || config.numeroDono || "+55 XX XXXXX-XXXX";
      const linkContato = `https://wa.me/${String(config.numeroDono).replace(/\D/g, "")}`;

      return sock.sendMessage(idChat, {
        text: `✅ *PLANO SELECIONADO!*\n\n📋 Plano: ${planoEscolhido.nome}\n💰 Valor: ${planoEscolhido.valor}\n\n👑 Entre em contato para concluir:\n📱 ${contatoDono}\n🔗 ${linkContato}\n\nObrigado por escolher o ${NOME_BOT}!`
      });
    },

    // ℹ️ !info_aluguel
    info_aluguel: async (sock, msg, args, dados) => {
      const cfgGlobal = carregarConfigGlobal();
      return sock.sendMessage(dados.idChat, {
        text: `ℹ️ *SISTEMA DE ALUGUEL*\n\n🌐 Aluguel Global: ${cfgGlobal.aluguelGlobalAtivo ? "🔒 ATIVADO" : "🔓 DESATIVADO"}\n\nComo funciona:\n\n🔓 Se DESATIVADO → bot funciona em TODOS os grupos\n🔒 Se ATIVADO → bot só funciona em grupos com aluguel registrado\n\nComandos:\n├─ 🌐 ${PREFIXO}aluguel_global on/off — Liga/desliga restrição global\n├─ ⚙️ ${PREFIXO}add_aluguel @user 7d — Adiciona aluguel marcando quem alugou\n├─ 🗑️ ${PREFIXO}rmaluguel 1,2,3 — Remove aluguel por número da lista\n├─ 📋 ${PREFIXO}alugueis — Lista grupos com link e quem alugou\n├─ 📦 ${PREFIXO}alugar — Ver planos e contatar dono\n└─ ℹ️ ${PREFIXO}info_aluguel — Esta mensagem\n\n👑 Somente Dono e Sub-Donos podem gerenciar!`
      });
    },

    // 🚪 !entrar link
    entrar: async (sock, msg, args, dados) => {
      const idChat = dados?.idChat || msg.key?.remoteJid;
      const remetente = dados?.remetente || msg.key?.participant || msg.key?.remoteJid;

      if (!ehDonoOuSubdono(remetente)) return;

      const link = args[0]?.trim();
      const regexLink = /chat\.whatsapp\.com\/(invite\/)?([a-zA-Z0-9_-]+)/;
      if (!link || !regexLink.test(link)) {
        return sock.sendMessage(idChat, {
          text: `⚠️ Link inválido!\n\nUso: ${PREFIXO}entrar https://chat.whatsapp.com/invite/xxxxxx`
        }, { quoted: msg });
      }

      try {
        const match = link.match(regexLink);
        const codigoConvite = match[2];
        await sock.groupAcceptInvite(codigoConvite);
        return sock.sendMessage(idChat, {
          text: `✅ *Solicitação enviada / Entrei!*\n\nO bot entrou no grupo com sucesso!`
        }, { quoted: msg });
      } catch (erro) {
        console.log("❌ Erro ao entrar no grupo:", erro);
        return sock.sendMessage(idChat, {
          text: `❌ Não consegui entrar!\nMotivo: ${erro?.message || "Erro desconhecido"}`
        }, { quoted: msg });
      }
    },

    // 📱 !canal_bot
    canal_bot: async (sock, msg, args, dados) => {
      return sock.sendMessage(dados.idChat, {
        text: `📱 *CANAL DO BOT*\n\n🔗 ${config.linkCanal || "⚠️ Link não definido no config.js"}`
      });
    },

    // 👥 !grupo_bot
    grupo_bot: async (sock, msg, args, dados) => {
      return sock.sendMessage(dados.idChat, {
        text: `👥 *GRUPO DO BOT*\n\n🔗 ${config.linkGrupo || "⚠️ Link não definido no config.js"}`
      });
    },

    // 👑 !dono
    dono: async (sock, msg, args, dados) => {
      return sock.sendMessage(dados.idChat, {
        text: `👑 *DONO DO BOT*\n\n👤 Nome: ${config.donoNome || "Moon"}\n📞 Contato: wa.me/${config.numeroDono}\n📱 Número: ${config.numeroDonoVisivel || config.numeroDono}`
      });
    },

    // 🛠️ !criador
    criador: async (sock, msg, args, dados) => {
      return sock.sendMessage(dados.idChat, {
        text: `✨️*𝐴𝑞𝑢𝑖 𝑒𝑠𝑡𝑎́ 𝑜 𝑐𝑜𝑛𝑡𝑎𝑡𝑜 𝑑𝑜 𝑚𝑒𝑢 𝑐𝑟𝑖𝑎𝑑𝑜𝑟:*${CRIADOR_NUMERO}`
      });
    }
  }
};

