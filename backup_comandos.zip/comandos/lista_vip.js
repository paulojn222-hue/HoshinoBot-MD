const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const CAMINHO_VIPS = path.join(__dirname, "..", "dados", "vips.json");

function carregarVips() {
  if (!fs.existsSync(CAMINHO_VIPS)) return {};
  try { return JSON.parse(fs.readFileSync(CAMINHO_VIPS, "utf-8")); }
  catch { return {}; }
}

function formatarTempo(ms) {
  if (!ms) return "♾️ Vitalício";
  if (ms <= Date.now()) return "⚠️ Vencido";
  const r = ms - Date.now();
  return `${Math.floor(r / 86400000)}d ${Math.floor((r % 86400000) / 3600000)}h restantes`;
}

function ehDono(id) {
  return String(id).replace(/\D/g, "") === String(config.numeroDono).replace(/\D/g, "");
}

module.exports = {
  nome: "lista_vip",
  comandos: {
    lista_vip: async (sock, msg, args, dados) => {
      const vips = carregarVips();
      
      // ✅ DONO — formato igual no addvip
      const donoCompleto = String(config.numeroDono).includes("@") 
        ? config.numeroDono 
        : `${config.numeroDono}@s.whatsapp.net`;
      const donoNum = donoCompleto.replace(/\D/g, "");
      
      let texto = `💎 *LISTA DE VIPS* 🕸\n\n`;
      const mencoes = [];
      let n = 1;
      
      // 👑 DONO — MARCAÇÃO IGUAL DO !addvip
      texto += `${n}. 👑 @${donoNum}\n   └─ ♾️ DONO — Acesso ilimitado\n\n`;
      mencoes.push(donoCompleto);
      n++;
      
      // 💎 DEMAIS VIPs — MESMO PADRÃO
      for (const [jidCompleto, info] of Object.entries(vips)) {
        // Garante que é o formato jid@...
        const jid = jidCompleto.includes("@") 
          ? jidCompleto 
          : `${jidCompleto}@s.whatsapp.net`;
        
        // SÓ os dígitos para o texto
        const numeroPuro = jid.replace(/@.*/, "").replace(/\D/g, "");
        
        const ativo = !info.fim || info.fim > Date.now();
        const tempo = formatarTempo(info.fim);
        
        texto += `${n}. 💎 @${numeroPuro}\n   └─ ${ativo ? "✅" : "⚠️"} ${tempo}\n\n`;
        mencoes.push(jid); // ✅ AQUI É O SEGREDO: usa o JID completo!
        n++;
      }
      
      if (Object.keys(vips).length === 0) {
        texto += `Nenhum VIP cadastrado!`;
      }
      
      return sock.sendMessage(dados.idChat, {
        text: texto.trim(),
        mentions: mencoes
      });
    }
  }
};

