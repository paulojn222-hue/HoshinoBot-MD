const config = require("../config.js");
const fs = require("fs");
const path = require("path");
const fetch = require("node-fetch");

const PREFIXO = config.prefixo || "!";
const API_BRONXY_URL = config.API_BRONXY_URL || "https://api.bronxyshost.com.br/api-bronxys";
const API_BRONXY_KEY = config.API_BRONXY_KEY || "";

const CAMINHO_MENU = path.join(__dirname, "..", "menus", "menu_pesquisas.txt");
const CAMINHO_FOTO_MENU = path.join(__dirname, "..", "midias", "foto_menu.jpg");

// 📂 Playlist
const CAMINHO_PLAYLIST = path.join(__dirname, "..", "dados", "playlist.json");

function carregarPlaylist() {
  try {
    if (!fs.existsSync(CAMINHO_PLAYLIST)) return [];
    return JSON.parse(fs.readFileSync(CAMINHO_PLAYLIST, "utf-8"));
  } catch { return []; }
}

function salvarPlaylist(lista) {
  fs.writeFileSync(CAMINHO_PLAYLIST, JSON.stringify(lista, null, 2));
}

function extrairDados(texto) {
  if (!texto || typeof texto !== "string") return null;

  console.log("📝 Texto recebido:", JSON.stringify(texto));

  // ✅ Reconhece a seta exata do seu formato: ╰─➤
  const nomeMatch = texto.match(/Título[\s\S]*?╰─➤\s*(.+?)\s*(?=\n|$)/i);
  const duracaoMatch = texto.match(/Duração[\s\S]*?╰─➤\s*(\d+:\d+)/i);

  const resultado = {
    nome: nomeMatch ? nomeMatch[1].trim() : "Música sem nome",
    duracao: duracaoMatch ? duracaoMatch[1] : "Desconhecido"
  };

  console.log("✅ Extraído:", resultado);
  return resultado;
}
module.exports = {
  nome: "pesquisas",
  comandos: {

    // 📋 Menu
    menupesquisas: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const mencao = `@${remetente.split("@")[0]}`;
      let textoMenu = "";

      if (fs.existsSync(CAMINHO_MENU)) {
        textoMenu = fs.readFileSync(CAMINHO_MENU, "utf-8");
        textoMenu = textoMenu.replace(/{NOME_BOT}/g, config.nomeBot || "MoonBot-MDv1");
        textoMenu = textoMenu.replace(/{PREFIXO}/g, PREFIXO);
        textoMenu = textoMenu.replace(/{USUARIO}/g, mencao);
      } else {
        textoMenu = `╭━━━━━━━━━━ 🎵 PESQUISAS 🎵 ━━━━━━━━━━╮
┃
┃ 🎵 ${config.nomeBot || "MoonBot-MDv1"} — MENU
┃
┃ 📥 DOWNLOADS
┃ ├─ 🎶 ${PREFIXO}play nome → Baixa áudio
┃ ├─ 🎬 ${PREFIXO}play_video nome → Baixa vídeo
┃ ├─ 📱 ${PREFIXO}tiktok_video link → Vídeo TikTok
┃ ├─ 🎵 ${PREFIXO}tiktok_audio link → Áudio TikTok
┃ ├─ 📘 ${PREFIXO}face_video link → Vídeo Facebook
┃ ├─ 🎵 ${PREFIXO}face_audio link → Áudio Facebook
┃ ├─ 📷 ${PREFIXO}instagram link → Baixa do Instagram
┃
┃ 📋 PLAYLIST
┃ ├─ ➕ ${PREFIXO}add_playlist → Salva música marcada
┃ ├─ 📋 ${PREFIXO}playlist → Ver todas salvas
┃ ├─ 🗑️ ${PREFIXO}rmplaylist 1,2 → Apaga da lista
┃
┃ 🔍 PESQUISAS
┃ ├─ 🌤️ ${PREFIXO}clima cidade → Ver clima
┃ ├─ 🎉 ${PREFIXO}feriados [ano] → Feriados Brasil
┃ ├─ 🌍 ${PREFIXO}infopais país → Dados do país
┃ ├─ 📝 ${PREFIXO}letra → Letra de música
┃ ├─ 🤖 ${PREFIXO}pergunta → Pergunta à IA
┃ ├─ 📱 ${PREFIXO}celular → Dados de celular
┃ ├─ 🖼️ ${PREFIXO}gimage → Imagem Google
┃ ├─ 📌 ${PREFIXO}pinterest → Imagem Pinterest
┃ ├─ 💑 ${PREFIXO}metadinha → Metadinhas
┃ ├─ ✨ ${PREFIXO}gerarnick → Nome estilizado
┃ ├─ 🖼️ ${PREFIXO}print url → Print de site
┃ ├─ 😀 ${PREFIXO}attp texto → Figurinha de texto
┃ ├─ 🎨 ${PREFIXO}ttp_white / ttp_brat → Figurinha estilo
┃
┃ 📋 Usado por: ${mencao}
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯`;
      }

      if (fs.existsSync(CAMINHO_FOTO_MENU)) {
        return await sock.sendMessage(idChat, { image: fs.readFileSync(CAMINHO_FOTO_MENU), caption: textoMenu, mentions: [remetente] });
      }
      return await sock.sendMessage(idChat, { text: textoMenu, mentions: [remetente] });
    },

    // 🎵 Play
    play: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const q = args.join(" ").trim();
      if (!API_BRONXY_KEY || API_BRONXY_KEY === "" || API_BRONXY_KEY === "COLOQUE_SUA_CHAVE_AQUI") {
        return await sock.sendMessage(idChat, { text: `⚠️ Configure a chave API no config.js 🔑` });
      }
      if (!q) return await sock.sendMessage(idChat, { text: `🎵 Exemplo: ${PREFIXO}play Believer` });

      try {
        const urlPesquisa = `${API_BRONXY_URL}/pesquisa_ytb?nome=${encodeURIComponent(q)}&apikey=${API_BRONXY_KEY}`;
        const res = await fetch(urlPesquisa);
        const data = await res.json();
        const musica = Array.isArray(data) ? data[0] : (data.resultado || data);
        if (!musica || !musica.titulo) return await sock.sendMessage(idChat, { text: `❌ Não encontrado: ${q}` });
        if (musica.tempo && musica.tempo.length >= 7) return await sock.sendMessage(idChat, { text: "⏰ Vídeo muito longo (mais de 1h)" });

        const N_E = "❌ Não encontrado";
        const mensagem = `╭━━━〔 🎵 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃 𝐃𝐄 𝐌𝐈𝐃𝐈𝐀 〕━━━╮
┃
┃ 🎶 𝐓í𝐭𝐮𝐥𝐨
┃ ╰─➤ ${musica.titulo || N_E}
┃
┃ ⏱️ 𝐃𝐮𝐫𝐚çã𝐨
┃ ╰─➤ ${musica.tempo || N_E}
┃
┃ 📅 𝐏𝐮𝐛𝐥𝐢𝐜𝐚𝐝𝐨
┃ ╰─➤ ${musica.postado || N_E}
┃
┃ 📝 𝐃𝐞𝐬𝐜𝐫𝐢çã𝐨
┃ ╰─➤ ${musica.desc || N_E}
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯

╭─〔 🎶 𝐏𝐑𝐎𝐂𝐄𝐒𝐒𝐀𝐍𝐃𝐎 〕
┃
┃ ⏳️𝐄𝐧𝐯𝐢𝐚𝐧𝐝𝐨 𝐚́𝐮𝐝𝐢𝐨...
┃ ▰▰▰▰▰▰▰▰▰▰ 𝟏𝟎𝟎%
╰━━━━━━━━━━━━━━━━━━━━━━╯`;

        if (musica.thumb) await sock.sendMessage(idChat, { image: { url: musica.thumb }, caption: mensagem });
        else await sock.sendMessage(idChat, { text: mensagem });

        const urlAudio = `${API_BRONXY_URL}/play?nome_url=${encodeURIComponent(musica.url || q)}&apikey=${API_BRONXY_KEY}`;
        await sock.sendMessage(idChat, { audio: { url: urlAudio }, mimetype: "audio/mpeg", fileName: (musica.titulo || "musica") + ".mp3" });
      } catch (erro) {
        console.log(erro);
        await sock.sendMessage(idChat, { text: "🔍 Seja mais específico ou tente outro nome" });
      }
    },

    // 🎬 Play Video
    play_video: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const q = args.join(" ").trim();
      if (!API_BRONXY_KEY || API_BRONXY_KEY === "" || API_BRONXY_KEY === "COLOQUE_SUA_CHAVE_AQUI") {
        return await sock.sendMessage(idChat, { text: `⚠️ Configure a chave API no config.js 🔑` });
      }
      if (!q) return await sock.sendMessage(idChat, { text: `🎬 Exemplo: ${PREFIXO}play_video nome do vídeo` });

      try {
        const urlPesquisa = `${API_BRONXY_URL}/pesquisa_ytb?nome=${encodeURIComponent(q)}&apikey=${API_BRONXY_KEY}`;
        const res = await fetch(urlPesquisa);
        const data = await res.json();
        const musica = Array.isArray(data) ? data[0] : (data.resultado || data);
        if (!musica || !musica.titulo) return await sock.sendMessage(idChat, { text: `❌ Não encontrado: ${q}` });
        if (musica.tempo && musica.tempo.length >= 7) return await sock.sendMessage(idChat, { text: "⏰ Vídeo muito longo (mais de 1h)" });

        const N_E = "❌ Não encontrado";
        const mensagem = `╭━━━〔 🎬 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃 𝐃𝐄 𝐕Í𝐃𝐄𝐎 〕━━━╮
┃
┃ 🎞️ 𝐓í𝐭𝐮𝐥𝐨
┃ ╰─➤ ${musica.titulo || N_E}
┃
┃ ⏱️ 𝐓𝐞𝐦𝐩𝐨
┃ ╰─➤ ${musica.tempo || N_E}
┃
┃ 📅 𝐏𝐨𝐬𝐭𝐚𝐝𝐨
┃ ╰─➤ ${musica.postado || N_E}
┃
┃ 📝 𝐃𝐞𝐬𝐜𝐫𝐢çã𝐨
┃ ╰─➤ ${musica.desc || N_E}
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯

╭─〔 🎶 𝐏𝐑𝐎𝐂𝐄𝐒𝐒𝐀𝐍𝐃𝐎 〕
┃
┃ 🎬 𝐄𝐧𝐯𝐢𝐚𝐧𝐝𝐨 𝐯í𝐝𝐞𝐨...
┃ ▰▰▰▰▰▰▰▰▰▰ 𝟏𝟎𝟎%
╰━━━━━━━━━━━━━━━━━━━━━━╯`;

        if (musica.thumb) await sock.sendMessage(idChat, { image: { url: musica.thumb }, caption: mensagem });
        else await sock.sendMessage(idChat, { text: mensagem });

        const urlVideo = `${API_BRONXY_URL}/play_video?nome_url=${encodeURIComponent(musica.url || q)}&apikey=${API_BRONXY_KEY}`;
        await sock.sendMessage(idChat, { video: { url: urlVideo }, mimetype: "video/mp4", fileName: (musica.titulo || "video") + ".mp4" });
      } catch (erro) {
        console.log(erro);
        await sock.sendMessage(idChat, { text: "🔍 Seja mais específico ou tente outro nome" });
      }
    },

    // 🤖 GPT / Pergunta
    gpt: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const pergunta = args.join(" ").trim();
      if (!pergunta) {
        return await sock.sendMessage(idChat, { text: `💬 *USO:* ${PREFIXO}gpt <pergunta>\n🩸 *Ex:* ${PREFIXO}gpt como fazer café?` });
      }

      try {
        await sock.sendMessage(idChat, { text: "⏳ Aguarde, estou pensando... 🩸" });
        const res = await fetch(
          `${API_BRONXY_URL}/PERGUNTE_E_EU_RESPONDO?q=${encodeURIComponent(pergunta)}&apikey=${API_BRONXY_KEY}`,
          { timeout: 30000 }
        );
        const data = await res.json();
        const resposta = data?.resposta || data?.msg || data?.pergunta || data?.texto || JSON.stringify(data);
        await sock.sendMessage(idChat, { text: `🤖 *RESPOSTA:*\n\n${resposta}` });
      } catch (erro) {
        console.log("❌ ERRO GPT:", erro);
        await sock.sendMessage(idChat, { text: `❌ Erro ao consultar a IA 🩸\n\nVerifique sua chave ou tente novamente mais tarde.\nMensagem: ${erro.message}` });
      }
    },
    pergunta: async (sock, msg, args, dados) => await exports.comandos.gpt(sock, msg, args, dados),
    openai: async (sock, msg, args, dados) => await exports.comandos.gpt(sock, msg, args, dados),
    chatgpt: async (sock, msg, args, dados) => await exports.comandos.gpt(sock, msg, args, dados),

    // 🌤️ Clima
    clima: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const cidade = args.join(" ");
      if (!cidade) {
        return await sock.sendMessage(idChat, { text: `🌤️ *CLIMA* 🌤️\n\nUso: ${PREFIXO}clima [cidade]\nExemplo: ${PREFIXO}clima Recife` });
      }

      try {
        const geoRes = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(cidade)}&count=1&language=pt&format=json`);
        const geoData = await geoRes.json();
        if (!geoData.results || geoData.results.length === 0) {
          return await sock.sendMessage(idChat, { text: `⚠️ Não encontrei essa cidade! Verifique o nome.` });
        }

        const { latitude, longitude, name, country } = geoData.results[0];
        const climaRes = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m&timezone=America%2FSao_Paulo`);
        const climaData = await climaRes.json();
        const atual = climaData.current;

        const cod = atual.weather_code;
        let tempoTexto = "❓ Desconhecido";
        if (cod === 0) tempoTexto = "☀️ Ensolarado";
        else if (cod <= 3) tempoTexto = "⛅ Parcialmente nublado";
        else if (cod <= 48) tempoTexto = "☁️ Nublado";
        else if (cod <= 67) tempoTexto = "🌧️ Chuva";
        else if (cod <= 77) tempoTexto = "🌨️ Granizo/Neve";
        else if (cod <= 86) tempoTexto = "❄️ Neve";
        else tempoTexto = "⛈️ Tempestade";

        await sock.sendMessage(idChat, {
          text: `🌤️ *CLIMA — ${name} / ${country}*\n\n${tempoTexto}\n🌡️ Temperatura: ${atual.temperature_2m}°C\n🤗 Sensação: ${atual.apparent_temperature}°C\n💧 Umidade: ${atual.relative_humidity_2m}%\n💨 Vento: ${atual.wind_speed_10m} km/h\n🌧️ Precipitação: ${atual.precipitation} mm\n\n📅 Atualizado agora!`,
          mentions: [remetente]
        });
      } catch (err) {
        console.error(err);
        await sock.sendMessage(idChat, { text: `❌ Erro ao buscar clima! Tente novamente mais tarde.` });
      }
    },

    // 🎉 Feriados
    feriados: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const ano = args[0] && /^\d{4}$/.test(args[0]) ? args[0] : new Date().getFullYear();

      try {
        const res = await fetch(`https://date.nager.at/api/v3/PublicHolidays/${ano}/BR`);
        if (!res.ok) throw new Error("Erro na API");
        const feriados = await res.json();
        let texto = `🎉 *FERIADOS NACIONAIS — Brasil ${ano}*\n\n`;
        if (feriados.length === 0) texto += `Nenhum feriado encontrado para ${ano}.`;
        else feriados.forEach(f => { texto += `📅 ${f.date} — ${f.localName}\n`; });
        texto += `\n📌 Fonte: Nager.Date`;
        await sock.sendMessage(idChat, { text: texto, mentions: [remetente] });
      } catch (err) {
        console.error(err);
        await sock.sendMessage(idChat, { text: `❌ Erro ao buscar feriados!\nUso: ${PREFIXO}feriados\nOu: ${PREFIXO}feriados 2027` });
      }
    },

    // 🌍 Info País
    infopais: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      let busca = args.join(" ").trim();
      if (!busca) {
        return await sock.sendMessage(idChat, { text: `🌍 *INFO PAÍS* 🌍\n\nUso: ${PREFIXO}infopais [país]\nExemplo: ${PREFIXO}infopais Brasil` });
      }

      const mapa = {
        "brasil": "Brazil", "portugal": "Portugal", "japão": "Japan", "china": "China",
        "estados unidos": "United States", "eua": "United States", "frança": "France",
        "alemanha": "Germany", "espanha": "Spain", "argentina": "Argentina",
        "méxico": "Mexico", "inglaterra": "United Kingdom", "reino unido": "United Kingdom",
        "rússia": "Russia", "itália": "Italy", "holanda": "Netherlands"
      };
      const buscaLower = busca.toLowerCase();
      if (mapa[buscaLower]) busca = mapa[buscaLower];

      try {
        const res = await fetch(`https://restcountries.com/v3.1/name/${encodeURIComponent(busca)}`, {
          headers: { "Accept": "application/json", "User-Agent": "Mozilla/5.0" }
        });
        if (!res.ok) throw new Error(`Status: ${res.status}`);
        const dadosPais = await res.json();
        if (!Array.isArray(dadosPais) || dadosPais.length === 0) throw new Error("Sem resultado");

        const pais = dadosPais[0];
        const nomePt = pais?.translations?.por?.common || pais?.name?.common || busca;
        const capital = pais?.capital?.[0] || "❌ Sem capital";
        const regiao = pais?.subregion || pais?.region || "❌ Não disponível";
        const populacao = pais?.population ? pais.population.toLocaleString("pt-BR") : "❌ Não disponível";
        const area = pais?.area ? `${pais.area.toLocaleString("pt-BR")} km²` : "❌ Não disponível";

        let moeda = "❌ Não disponível";
        if (pais?.currencies) moeda = Object.entries(pais.currencies).map(([k, v]) => `${v?.name || k}${v?.symbol ? ` (${v.symbol})` : ""}`).join(", ");

        let idiomas = "❌ Não disponível";
        if (pais?.languages) idiomas = Object.values(pais.languages).join(", ");

        const fuso = pais?.timezones?.[0] || "❌ Não disponível";
        const bandeira = pais?.flag || "";

        await sock.sendMessage(idChat, {
          text: `${bandeira} 🌍 *${nomePt}*\n\n🏛️ Capital: ${capital}\n📍 Região: ${regiao}\n👥 População: ${populacao}\n📐 Área: ${area}\n💰 Moeda: ${moeda}\n🗣️ Idioma(s): ${idiomas}\n🕐 Fuso horário: ${fuso}`,
          mentions: [remetente]
        });
      } catch (err) {
        console.error("❌ Erro infopais:", err.message);
        await sock.sendMessage(idChat, {
          text: `❌ Não consegui buscar esse país 😕\n\nTente digitar em inglês: ${PREFIXO}infopais Brazil\nErro: ${err.message}`
        });
      }
    },

// ➕ Add Playlist
add_playlist: async (sock, msg, args, dados) => {
  const idChat = dados.idChat || msg.key.remoteJid;

  const mensagemCitada =
    msg.message?.extendedTextMessage?.contextInfo?.quotedMessage ||
    msg.message?.contextInfo?.quotedMessage ||
    msg.quoted;

  if (!mensagemCitada) {
    return await sock.sendMessage(idChat, {
      text: `➕ *USO:* ${PREFIXO}add_playlist\n\nMarque/responda a mensagem com os dados da música!`
    });
  }

  const textoCitado =
    mensagemCitada.conversation ||
    mensagemCitada.extendedTextMessage?.text ||
    mensagemCitada.imageMessage?.caption ||
    mensagemCitada.videoMessage?.caption ||
    "";

  const dadosMusica = extrairDados(textoCitado);
  if (!dadosMusica) {
    return await sock.sendMessage(idChat, {
      text: `⚠️ Não consegui extrair os dados da música!`
    });
  }

  const lista = carregarPlaylist();
  lista.push(dadosMusica);
  salvarPlaylist(lista);

  await sock.sendMessage(idChat, {
    text: `✅ Adicionada!\n\n🎵 ${dadosMusica.nome}\n⏱️ ${dadosMusica.duracao}\n\n📋 Total: ${lista.length} música(s)`
  });
},

// 📋 Playlist
playlist: async (sock, msg, args, dados) => {
  const idChat = dados.idChat || msg.key.remoteJid;
  const lista = carregarPlaylist();

  if (lista.length === 0) {
    return await sock.sendMessage(idChat, {
      text: `📋 *Playlist Vazia!*\n\nUse ${PREFIXO}add_playlist marcando uma mensagem para salvar!`
    });
  }

  let texto = `📋 *SUA PLAYLIST* — ${lista.length} música(s)\n\n`;
  lista.forEach((musica, i) => {
    texto += `${i + 1}. 🎵 ${musica.nome}\n   ⏱️ ${musica.duracao}\n\n`;
  });
  texto += `✏️ Remover: ${PREFIXO}rmplaylist 1,3,5`;

  await sock.sendMessage(idChat, { text: texto });
},

// 🗑️ Remover Playlist
rmplaylist: async (sock, msg, args, dados) => {
  const idChat = dados.idChat || msg.key.remoteJid;
  const entrada = args.join("").trim();

  if (!entrada) {
    return await sock.sendMessage(idChat, {
      text: `🗑️ *USO:* ${PREFIXO}rmplaylist <número(s)>\n\nExemplos:\n${PREFIXO}rmplaylist 2\n${PREFIXO}rmplaylist 1,3,5`
    });
  }

  let lista = carregarPlaylist();
  if (lista.length === 0) {
    return await sock.sendMessage(idChat, { text: `❌ A playlist já está vazia!` });
  }

  const indices = entrada.split(",")
    .map(n => parseInt(n.trim(), 10) - 1)
    .filter(n => !isNaN(n) && n >= 0 && n < lista.length);

  if (indices.length === 0) {
    return await sock.sendMessage(idChat, {
      text: `❌ Números inválidos! Use de 1 a ${lista.length}`
    });
  }

  indices.sort((a, b) => b - a).forEach(i => lista.splice(i, 1));
  salvarPlaylist(lista);

  await sock.sendMessage(idChat, {
    text: `🗑️ Removida!\n\n📋 Restantes: ${lista.length} música(s)`
  });
},

    // 📱 TikTok Video
    tiktok_video: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const q = args.join(" ").trim();
      if (!API_BRONXY_KEY || API_BRONXY_KEY === "" || API_BRONXY_KEY === "COLOQUE_SUA_CHAVE_AQUI") {
        return await sock.sendMessage(idChat, { text: `⚠️ Configure a chave API no config.js 🔑` });
      }
      if (!q.includes("tiktok")) return await sock.sendMessage(idChat, { text: `🎬 Exemplo: ${PREFIXO}tiktok_video link do TikTok` });

      try {
        await sock.sendMessage(idChat, { text: "🎬 Baixando vídeo do TikTok..." });
        const url = `${API_BRONXY_URL}/tiktok?url=${encodeURIComponent(q)}&apikey=${API_BRONXY_KEY}`;
        await sock.sendMessage(idChat, { video: { url: url }, mimetype: "video/mp4" });
      } catch (erro) {
        console.log(erro);
        await sock.sendMessage(idChat, { text: "❌ Erro ao baixar vídeo do TikTok" });
      }
    },

    // 🎵 TikTok Audio
    tiktok_audio: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const q = args.join(" ").trim();
      if (!API_BRONXY_KEY || API_BRONXY_KEY === "" || API_BRONXY_KEY === "COLOQUE_SUA_CHAVE_AQUI") {
        return await sock.sendMessage(idChat, { text: `⚠️ Configure a chave API no config.js 🔑` });
      }
      if (!q.includes("tiktok")) return await sock.sendMessage(idChat, { text: `🎵 Exemplo: ${PREFIXO}tiktok_audio link do TikTok` });

      try {
        await sock.sendMessage(idChat, { text: "🎵 Extraindo áudio do TikTok..." });
        const url = `${API_BRONXY_URL}/tiktok?url=${encodeURIComponent(q)}&apikey=${API_BRONXY_KEY}`;
        await sock.sendMessage(idChat, { audio: { url: url }, mimetype: "audio/mpeg" });
      } catch (erro) {
        console.log(erro);
        await sock.sendMessage(idChat, { text: "❌ Erro ao extrair áudio do TikTok" });
      }
    },

    // 📘 Facebook Video
    face_video: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const q = args.join(" ").trim();
      if (!API_BRONXY_KEY || API_BRONXY_KEY === "" || API_BRONXY_KEY === "COLOQUE_SUA_CHAVE_AQUI") {
        return await sock.sendMessage(idChat, { text: `⚠️ Configure a chave API no config.js 🔑` });
      }
      if (!q.includes("facebook") && !q.includes("fb.watch")) {
        return await sock.sendMessage(idChat, { text: `📘 Exemplo: ${PREFIXO}face_video link do Facebook` });
      }

      try {
        await sock.sendMessage(idChat, { text: "📘 Baixando vídeo do Facebook..." });
        const url = `${API_BRONXY_URL}/face_video?url=${encodeURIComponent(q)}&apikey=${API_BRONXY_KEY}`;
        await sock.sendMessage(idChat, { video: { url: url }, mimetype: "video/mp4" });
      } catch (erro) {
        console.log(erro);
        await sock.sendMessage(idChat, { text: "❌ Erro ao baixar vídeo do Facebook" });
      }
    },

    // 🎵 Facebook Audio
    face_audio: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const q = args.join(" ").trim();
      if (!API_BRONXY_KEY || API_BRONXY_KEY === "" || API_BRONXY_KEY === "COLOQUE_SUA_CHAVE_AQUI") {
        return await sock.sendMessage(idChat, { text: `⚠️ Configure a chave API no config.js 🔑` });
      }
      if (!q.includes("facebook") && !q.includes("fb.watch")) {
        return await sock.sendMessage(idChat, { text: `🎵 Exemplo: ${PREFIXO}face_audio link do Facebook` });
      }

      try {
        await sock.sendMessage(idChat, { text: "🎵 Extraindo áudio do Facebook..." });
        const url = `${API_BRONXY_URL}/face_audio?url=${encodeURIComponent(q)}&apikey=${API_BRONXY_KEY}`;
        await sock.sendMessage(idChat, { audio: { url: url }, mimetype: "audio/mpeg" });
      } catch (erro) {
        console.log(erro);
        await sock.sendMessage(idChat, { text: "❌ Erro ao extrair áudio do Facebook" });
      }
    },

    // 📷 Instagram
    instagram: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const q = args.join(" ").trim();
      if (!API_BRONXY_KEY || API_BRONXY_KEY === "" || API_BRONXY_KEY === "COLOQUE_SUA_CHAVE_AQUI") {
        return await sock.sendMessage(idChat, { text: `⚠️ Configure a chave API no config.js 🔑` });
      }
      if (q.length < 5 || !q.includes("instagram.com")) {
        return await sock.sendMessage(idChat, { text: `📷 Exemplo: ${PREFIXO}instagram https://www.instagram.com/reel/...` });
      }

      try {
        await sock.sendMessage(idChat, { text: "📷 Baixando do Instagram..." });
        const urlCodificada = encodeURIComponent(q);
        const urlApi = `${API_BRONXY_URL}/instagram?url=${urlCodificada}&apikey=${API_BRONXY_KEY}`;
        const res = await fetch(urlApi);
        const textoResposta = await res.text();
        let dadosIg;
        try { dadosIg = JSON.parse(textoResposta); } catch {
          console.log("❌ API retornou inválido:", textoResposta.substring(0, 200));
          return await sock.sendMessage(idChat, { text: "❌ Link inválido ou a API não conseguiu acessar. Tente novamente mais tarde 📷" });
        }

        if (!dadosIg.msg || !dadosIg.msg[0]) {
          return await sock.sendMessage(idChat, { text: "❌ Nenhum conteúdo encontrado no Instagram 📷" });
        }

        const item = dadosIg.msg[0];
        const tipo = item.type === "mp4" ? "video" : item.type === "mp3" ? "audio" : "image";
        const mimetipo = item.type === "mp4" ? "video/mp4" : item.type === "mp3" ? "audio/mpeg" : item.type === "webp" ? "image/webp" : "image/jpeg";

        await sock.sendMessage(idChat, { [tipo]: { url: item.url }, mimetype: mimetipo });
      } catch (erro) {
        console.log("❌ Erro Instagram:", erro.message);
        await sock.sendMessage(idChat, { text: "❌ Erro ao baixar do Instagram. Verifique o link e tente novamente 📷" });
      }
    },

    // 📝 Letra
    letra: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const q = args.join(" ").trim();
      if (!API_BRONXY_KEY || API_BRONXY_KEY === "" || API_BRONXY_KEY === "COLOQUE_SUA_CHAVE_AQUI") {
        return await sock.sendMessage(idChat, { text: `⚠️ Configure a chave API no config.js 🔑` });
      }
      if (!q) return await sock.sendMessage(idChat, { text: `📝 Exemplo: ${PREFIXO}letra nome da música` });

      try {
        await sock.sendMessage(idChat, { text: "📝 Buscando letra..." });
        const urlApi = `${API_BRONXY_URL}/letra_musica?letra=${encodeURIComponent(q)}&apikey=${API_BRONXY_KEY}`;
        const res = await fetch(urlApi);
        const dados = await res.json();
        await sock.sendMessage(idChat, {
          text: `🎵 Título: ${dados.titulo || "Desconhecido"}\n✍️ Compositor: ${dados.compositor || "Desconhecido"}\n\n📝 Letra:\n${dados.letra || "Não encontrada"}`
        });
      } catch (erro) {
        console.log(erro);
        await sock.sendMessage(idChat, { text: "❌ Erro ao buscar letra" });
      }
    },
    liryc: async (sock, msg, args, dados) => await exports.comandos.letra(sock, msg, args, dados),
    letram: async (sock, msg, args, dados) => await exports.comandos.letra(sock, msg, args, dados),
    letramusic: async (sock, msg, args, dados) => await exports.comandos.letra(sock, msg, args, dados),
    letramusica: async (sock, msg, args, dados) => await exports.comandos.letra(sock, msg, args, dados),

    // 📱 Celular
    celular: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const q = args.join(" ").trim();
      if (!API_BRONXY_KEY || API_BRONXY_KEY === "" || API_BRONXY_KEY === "COLOQUE_SUA_CHAVE_AQUI") {
        return await sock.sendMessage(idChat, { text: `⚠️ Configure a chave API no config.js 🔑` });
      }
      if (!q) return await sock.sendMessage(idChat, { text: `📱 Exemplo: ${PREFIXO}celular Galaxy A54` });

      try {
        await sock.sendMessage(idChat, { text: "📱 Buscando informações..." });
        const urlApi = `${API_BRONXY_URL}/info_celular?celular=${encodeURIComponent(q)}&apikey=${API_BRONXY_KEY}`;
        const res = await fetch(urlApi);
        const dados = await res.json();
        await sock.sendMessage(idChat, {
          text: `📱 Celular: ${dados.celular || "Não encontrado"}\n\n📋 Informações:\n${dados.resumo || dados.infoc || "Não encontrado, seja mais específico"}`
        });
      } catch (erro) {
        console.log(erro);
        await sock.sendMessage(idChat, { text: "❌ Erro ao buscar dados do celular" });
      }
    },

    // 🖼️ Print
    print: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const q = args.join(" ").trim();
      if (!API_BRONXY_KEY || API_BRONXY_KEY === "" || API_BRONXY_KEY === "COLOQUE_SUA_CHAVE_AQUI") {
        return await sock.sendMessage(idChat, { text: `⚠️ Configure a chave API no config.js 🔑` });
      }
      if (!q) return await sock.sendMessage(idChat, { text: `🖼️ Exemplo: ${PREFIXO}print https://google.com` });

      try {
        const url = `${API_BRONXY_URL}/print_de_site?url=${encodeURIComponent(q)}&apikey=${API_BRONXY_KEY}`;
        await sock.sendMessage(idChat, { image: { url: url } });
      } catch (erro) {
        console.log(erro);
        await sock.sendMessage(idChat, { text: "❌ Erro ao gerar print" });
      }
    },
    printdesite: async (sock, msg, args, dados) => await exports.comandos.print(sock, msg, args, dados),

    // 🖼️ GImage
    gimage: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const q = args.join(" ").trim();
      if (!API_BRONXY_KEY || API_BRONXY_KEY === "" || API_BRONXY_KEY === "COLOQUE_SUA_CHAVE_AQUI") {
        return await sock.sendMessage(idChat, { text: `⚠️ Configure a chave API no config.js 🔑` });
      }
      if (!q) return await sock.sendMessage(idChat, { text: `🖼️ Exemplo: ${PREFIXO}gimage naruto` });

      try {
        const urlApi = `${API_BRONXY_URL}/google-img?nome=${encodeURIComponent(q)}&apikey=${API_BRONXY_KEY}`;
        const res = await fetch(urlApi);
        const dados = await res.json();
        if (!dados || !dados.length) return await sock.sendMessage(idChat, { text: "❌ Nenhuma imagem encontrada" });
        const aleatoria = dados[Math.floor(Math.random() * dados.length)];
        await sock.sendMessage(idChat, { image: { url: aleatoria.url } });
      } catch (erro) {
        console.log(erro);
        await sock.sendMessage(idChat, { text: "❌ Erro ao buscar imagem" });
      }
    },

    // 📌 Pinterest
    pinterest: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const q = args.join(" ").trim();
      if (!API_BRONXY_KEY || API_BRONXY_KEY === "" || API_BRONXY_KEY === "COLOQUE_SUA_CHAVE_AQUI") {
        return await sock.sendMessage(idChat, { text: `⚠️ Configure a chave API no config.js 🔑` });
      }
      if (!q) return await sock.sendMessage(idChat, { text: `📌 Exemplo: ${PREFIXO}pinterest paisagem` });

      try {
        const urlApi = `${API_BRONXY_URL}/pinterest?nome=${encodeURIComponent(q)}&apikey=${API_BRONXY_KEY}`;
        const res = await fetch(urlApi);
        const dados = await res.json();
        if (!dados || !dados.length) return await sock.sendMessage(idChat, { text: "❌ Nenhuma imagem encontrada" });
        const aleatoria = dados[Math.floor(Math.random() * dados.length)];
        await sock.sendMessage(idChat, { image: { url: aleatoria.url } });
      } catch (erro) {
        console.log(erro);
        await sock.sendMessage(idChat, { text: "❌ Erro ao buscar imagem" });
      }
    },

    // 💑 Metadinha
    metadinha: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      if (!API_BRONXY_KEY || API_BRONXY_KEY === "" || API_BRONXY_KEY === "COLOQUE_SUA_CHAVE_AQUI") {
        return await sock.sendMessage(idChat, { text: `⚠️ Configure a chave API no config.js 🔑` });
      }

      try {
        await sock.sendMessage(idChat, { text: `💑 Gerando metadinha...` });
        const urlApi = `${API_BRONXY_URL}/metadinha?apikey=${API_BRONXY_KEY}`;
        const res = await fetch(urlApi);
        const data = await res.json();
        if (!data.link1 || !data.link2) return await sock.sendMessage(idChat, { text: `❌ API não retornou as imagens` });
        await sock.sendMessage(idChat, { image: { url: data.link1 }, caption: "💑 Metadinha — Parte 1" });
        await sock.sendMessage(idChat, { image: { url: data.link2 }, caption: "💑 Metadinha — Parte 2" });
      } catch (erro) {
        console.log(erro);
        await sock.sendMessage(idChat, { text: "❌ Erro ao gerar metadinha" });
      }
    },

    // ✨ Gerar Nick
    gerarnick: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const q = args.join(" ").trim();
      if (!API_BRONXY_KEY || API_BRONXY_KEY === "" || API_BRONXY_KEY === "COLOQUE_SUA_CHAVE_AQUI") {
        return await sock.sendMessage(idChat, { text: `⚠️ Configure a chave API no config.js 🔑` });
      }
      if (!q) return await sock.sendMessage(idChat, { text: `✨ Exemplo: ${PREFIXO}gerarnick Moon` });

      try {
        const urlApi = `${API_BRONXY_URL}/gerar_nick?nick=${encodeURIComponent(q)}&apikey=${API_BRONXY_KEY}`;
        const res = await fetch(urlApi);
        const dados = await res.json();
        if (!dados || !dados.length) return await sock.sendMessage(idChat, { text: "❌ Nenhum estilo encontrado" });
        let lista = `✨ Estilos para: *${q}*\n\n`;
        for (const estilo of dados) lista += `${estilo}\n\n`;
        await sock.sendMessage(idChat, { text: lista });
      } catch (erro) {
        console.log(erro);
        await sock.sendMessage(idChat, { text: "❌ Erro ao gerar nick" });
      }
    },

    // 😀 ATTP
    attp: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const q = args.join(" ").trim();
      if (!API_BRONXY_KEY || API_BRONXY_KEY === "" || API_BRONXY_KEY === "COLOQUE_SUA_CHAVE_AQUI") {
        return await sock.sendMessage(idChat, { text: `⚠️ Configure a chave API no config.js 🔑` });
      }
      if (!q) return await sock.sendMessage(idChat, { text: `😀 Exemplo: ${PREFIXO}attp Olá` });

      try {
        await sock.sendMessage(idChat, { text: "😀 Gerando figurinha..." });
        const url = `${API_BRONXY_URL}/attp_edit?texto=${encodeURIComponent(q)}&fonte=Noto Emoji, Noto Sans Mono&apikey=${API_BRONXY_KEY}`;
        await sock.sendMessage(idChat, { sticker: { url: url } });
      } catch (erro) {
        console.log(erro);
        await sock.sendMessage(idChat, { text: "❌ Erro ao gerar figurinha" });
      }
    },

    attp2: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const q = args.join(" ").trim();
      if (!API_BRONXY_KEY || API_BRONXY_KEY === "" || API_BRONXY_KEY === "COLOQUE_SUA_CHAVE_AQUI") {
        return await sock.sendMessage(idChat, { text: `⚠️ Configure a chave API no config.js 🔑` });
      }
      if (!q) return await sock.sendMessage(idChat, { text: `😀 Exemplo: ${PREFIXO}attp2 Olá` });

      try {
        await sock.sendMessage(idChat, { text: "😀 Gerando figurinha..." });
        const url = `${API_BRONXY_URL}/attp_edit?texto=${encodeURIComponent(q)}&fonte=Roboto&apikey=${API_BRONXY_KEY}`;
        await sock.sendMessage(idChat, { sticker: { url: url } });
      } catch (erro) {
        console.log(erro);
        await sock.sendMessage(idChat, { text: "❌ Erro ao gerar figurinha" });
      }
    },

    // 🎨 TTP White
    ttp_white: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const q = args.join(" ").trim();
      if (!API_BRONXY_KEY || API_BRONXY_KEY === "" || API_BRONXY_KEY === "COLOQUE_SUA_CHAVE_AQUI") {
        return await sock.sendMessage(idChat, { text: `⚠️ Configure a chave API no config.js 🔑` });
      }
      if (!q) return await sock.sendMessage(idChat, { text: `🎨 Exemplo: ${PREFIXO}ttp_white seu texto` });

      try {
        await sock.sendMessage(idChat, { text: "🎨 Gerando figurinha..." });
        const url = `${API_BRONXY_URL}/ttp_white?texto=${encodeURIComponent(q)}&fonte=Arial&apikey=${API_BRONXY_KEY}`;
        await sock.sendMessage(idChat, { sticker: { url: url } });
      } catch (erro) {
        console.log(erro);
        await sock.sendMessage(idChat, { text: "❌ Erro ao gerar figurinha" });
      }
    },

    // 🎨 TTP Brat
    ttp_brat: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const q = args.join(" ").trim();
      if (!API_BRONXY_KEY || API_BRONXY_KEY === "" || API_BRONXY_KEY === "COLOQUE_SUA_CHAVE_AQUI") {
        return await sock.sendMessage(idChat, { text: `⚠️ Configure a chave API no config.js 🔑` });
      }
      if (!q) return await sock.sendMessage(idChat, { text: `🎨 Exemplo: ${PREFIXO}ttp_brat seu texto` });

      try {
        await sock.sendMessage(idChat, { text: "🎨 Gerando figurinha..." });
        const url = `${API_BRONXY_URL}/ttp_brat?texto=${encodeURIComponent(q)}&fonte=Arial&apikey=${API_BRONXY_KEY}`;
        await sock.sendMessage(idChat, { sticker: { url: url } });
      } catch (erro) {
        console.log(erro);
        await sock.sendMessage(idChat, { text: "❌ Erro ao gerar figurinha" });
      }
    }
  }
};

