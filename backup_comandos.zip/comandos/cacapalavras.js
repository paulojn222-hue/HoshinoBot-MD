const fs = require("fs");
const path = require("path");
const config = require("../config.js");

// 📁 Caminhos — ajuste conforme seu sistema de moedas
const CAMINHO_RPG = path.join(__dirname, "..", "dados", "rpg.json");

// ⚙️ Palavras que vão aparecer no jogo
const LISTA_PALAVRAS = [
  // 🌎 Natureza
  { nome: "lua", dica: "Brilha à noite 🌙" },
  { nome: "sol", dica: "Nos dá calor e luz ☀️" },
  { nome: "céu", dica: "Lá em cima, azul quando está bom tempo ☁️" },
  { nome: "mar", dica: "Água salgada, enorme 🌊" },
  { nome: "terra", dica: "Planeta onde vivemos 🌍" },
  { nome: "fogo", dica: "Queima, dá calor 🔥" },
  { nome: "água", dica: "Precisamos pra viver, sem cor 💧" },
  { nome: "ar", dica: "Respiramos, não vemos 🌬️" },
  { nome: "rio", dica: "Água corrente que desce da montanha 🏞️" },
  { nome: "montanha", dica: "Elevação alta do terreno ⛰️" },
  { nome: "nuvem", dica: "Passa no céu, parece algodão ☁️" },
  { nome: "chuva", dica: "Cai do céu, molha tudo 🌧️" },
  { nome: "vento", dica: "Ar que se move 💨" },
  { nome: "neve", dica: "Gelo branco que cai no frio ❄️" },
  { nome: "tempestade", dica: "Chuva forte com vento 🌩️" },
  { nome: "trovão", dica: "Barulho forte na tempestade ⛈️" },
  { nome: "raio", dica: "Luz que desce do céu ⚡" },
  { nome: "vulcão", dica: "Montanha que cospe fogo 🌋" },
  { nome: "floresta", dica: "Muitas árvores juntas 🌳" },
  { nome: "selva", dica: "Floresta quente e densa 🌴" },
  { nome: "deserto", dica: "Muito areia, quase não chove 🏜️" },
  { nome: "praia", dica: "Areia junto ao mar 🏖️" },
  { nome: "ilha", dica: "Terra cercada de água 🏝️" },
  { nome: "oceano", dica: "Mar bem grande, imenso 🌊" },
  { nome: "lago", dica: "Água parada, menor que o mar 🏞️" },
  { nome: "cachoeira", dica: "Água que cai de altura 💦" },
  { nome: "caverna", dica: "Buraco grande na rocha 🦇" },
  { nome: "árvore", dica: "Tronco com galhos e folhas 🌳" },
  { nome: "folha", dica: "Verde, cai no outono 🍃" },
  { nome: "flor", dica: "Bonita, tem perfume 🌸" },
  { nome: "grama", dica: "Pequenas plantas verdes 🌱" },
  { nome: "areia", dica: "Na praia, grão pequeno 🏜️" },
  { nome: "pedra", dica: "Dura, encontrada na rua 🪨" },
  { nome: "rocha", dica: "Pedra grande e forte 🗿" },
  { nome: "estrela", dica: "Brilha no céu à noite ⭐" },
  { nome: "planeta", dica: "Gira ao redor do sol 🌍" },
  { nome: "galáxia", dica: "Conjunto de estrelas 🌌" },
  { nome: "universo", dica: "Tudo que existe, espaço inteiro 🌌" },
  { nome: "cometa", dica: "Corpo celeste com cauda ☄️" },
  { nome: "meteoro", dica: "Pedra que cai do espaço ☄️" },
  { nome: "espaço", dica: "Onde ficam as estrelas 🚀" },
  { nome: "escuridão", dica: "Sem luz, tudo preto 🌑" },
  { nome: "luz", dica: "O oposto do escuro 💡" },
  { nome: "brilho", dica: "Reflete luz ✨" },
  { nome: "sombra", dica: "O que fica escuro atrás de algo 👤" },
  { nome: "fumaça", dica: "Sobe do fogo 🌫️" },
  { nome: "gelo", dica: "Água congelada, duro ❄️" },

  // 🐶 Animais
  { nome: "gato", dica: "Mia, gosta de dormir 🐱" },
  { nome: "cão", dica: "Late, homem tem como melhor amigo 🐶" },
  { nome: "cachorro", dica: "O mesmo que cão 🐕" },
  { nome: "leão", dica: "Rei da selva 🦁" },
  { nome: "tigre", dica: "Tem listras, grande e forte 🐅" },
  { nome: "elefante", dica: "Maior animal terrestre, tem tromba 🐘" },
  { nome: "girafa", dica: "Pescoço muito longo 🦒" },
  { nome: "macaco", dica: "Gosta de banana, pula de árvore em árvore 🐒" },
  { nome: "gorila", dica: "Grande e forte, parente do macaco 🦍" },
  { nome: "zebra", dica: "Branca com listras pretas 🦓" },
  { nome: "cavalo", dica: "Nós montamos nele 🐴" },
  { nome: "vaca", dica: "Nos dá leite 🐄" },
  { nome: "porco", dica: "Tem focinho chato 🐷" },
  { nome: "ovelha", dica: "Dá lã 🐑" },
  { nome: "cabra", dica: "Tem chifres 🐐" },
  { nome: "coelho", dica: "Orelhas compridas 🐰" },
  { nome: "rato", dica: "Pequeno, vive em buracos 🐀" },
  { nome: "hamster", dica: "Pequeno, roedor de estimação 🐭" },
  { nome: "panda", dica: "Branco e preto, come bambu 🐼" },
  { nome: "urso", dica: "Grande, hibernar no inverno 🐻" },
  { nome: "lobo", dica: "Uiva para a lua 🐺" },
  { nome: "raposa", dica: "Esperta, tem cauda grande 🦊" },
  { nome: "veado", dica: "Tem chifres bonitos 🦌" },
  { nome: "onça", dica: "Felino brasileiro 🐆" },
  { nome: "jacaré", dica: "Parece crocodilo 🐊" },
  { nome: "crocodilo", dica: "Boca grande, vive na água 🐊" },
  { nome: "cobra", dica: "Não tem pernas, rasteja 🐍" },
  { nome: "tartaruga", dica: "Anda devagar, tem casco 🐢" },
  { nome: "lagarto", dica: "Parece cobra com pernas 🦎" },
  { nome: "sapo", dica: "Pula, vive perto da água 🐸" },
  { nome: "baleia", dica: "Maior animal do mar 🐋" },
  { nome: "golfinho", dica: "Inteligente, salta na água 🐬" },
  { nome: "tubarão", dica: "Perigoso, rei dos mares 🦈" },
  { nome: "polvo", dica: "Tem oito braços 🐙" },
  { nome: "peixe", dica: "Nada, tem escamas 🐟" },
  { nome: "caranguejo", dica: "Anda de lado, tem pinça 🦀" },
  { nome: "camarão", dica: "Pequeno, rosa quando cozido 🦐" },
  { nome: "águia", dica: "Voa alto, enxerga longe 🦅" },
  { nome: "coruja", dica: "Vê à noite, tem olhos grandes 🦉" },
  { nome: "papagaio", dica: "Fala, tem penas coloridas 🦜" },
  { nome: "pombo", dica: "Voa na cidade 🕊️" },
  { nome: "galinha", dica: "Bota ovo 🐔" },
  { nome: "galo", dica: "Canta de madrugada 🐓" },
  { nome: "pato", dica: "Nada, tem bico amarelo 🦆" },
  { nome: "pinguim", dica: "Parece de smoking, não voa 🐧" },
  { nome: "flamingo", dica: "Rosa, fica de pé numa perna só 🦩" },
  { nome: "abelha", dica: "Faz mel, tem ferrão 🐝" },
  { nome: "borboleta", dica: "Colorida, voa de flor em flor 🦋" },
  { nome: "formiga", dica: "Pequena, trabalha muito 🐜" },
  { nome: "aranha", dica: "Faz teia 🕷️" },
  { nome: "mosquito", dica: "Pequeno, pica e faz barulho 🦟" },

  // 🍔 Comidas
  { nome: "pizza", dica: "Massa com queijo e molho 🍕" },
  { nome: "hambúrguer", dica: "Pão com carne e salada 🍔" },
  { nome: "sanduíche", dica: "Pão com recheio 🥪" },
  { nome: "batata", dica: "Frita ou cozida, gostosa 🥔" },
  { nome: "arroz", dica: "Comemos todo dia, branco 🍚" },
  { nome: "feijão", dica: "Com arroz é sucesso 🫘" },
  { nome: "macarrão", dica: "Massa longa ou curta 🍝" },
  { nome: "lasanha", dica: "Camadas de massa com molho 🫕" },
  { nome: "sushi", dica: "Comida japonesa com arroz 🍣" },
  { nome: "cachorro-quente", dica: "Pão com salsicha 🌭" },
  { nome: "pipoca", dica: "Milho estourado 🍿" },
  { nome: "chocolate", dica: "Marrom, doce, viciante 🍫" },
  { nome: "sorvete", dica: "Gelado, nos dias quentes 🍦" },
  { nome: "bolo", dica: "Aniversário tem dele 🎂" },
  { nome: "brigadeiro", dica: "Doce brasileiro, leite condensado 🍫" },
  { nome: "pudim", dica: "Sobremesa com calda de caramelo 🍮" },
  { nome: "biscoito", dica: "Seco ou recheado, crocante 🍪" },
  { nome: "cookie", dica: "Biscoito com gotas de chocolate 🍪" },
  { nome: "doce", dica: "Açucarado, gostoso 🍬" },
  { nome: "bala", dica: "Pequena, chupa sem mastigar 🍬" },
  { nome: "chiclete", dica: "Mastiga mas não engole 🦷" },
  { nome: "maçã", dica: "Vermelha ou verde, fruta 🍎" },
  { nome: "banana", dica: "Amarela, macia 🍌" },
  { nome: "laranja", dica: "Tem vitamina C 🍊" },
  { nome: "uva", dica: "Pequena, vem em cacho 🍇" },
  { nome: "morango", dica: "Vermelho, com sementes por fora 🍓" },
  { nome: "melancia", dica: "Verde por fora, vermelha por dentro 🍉" },
  { nome: "abacaxi", dica: "Tem coroa, azedo e doce 🍍" },
  { nome: "manga", dica: "Amarela, doce, com caroço 🥭" },
  { nome: "limão", dica: "Azedo, verde ou amarelo 🍋" },
  { nome: "coco", dica: "Tem água dentro, casca dura 🥥" },
  { nome: "mel", dica: "As abelhas fazem, doce 🍯" },
  { nome: "queijo", dica: "Feito de leite 🧀" },
  { nome: "ovo", dica: "Da galinha, café da manhã 🥚" },
  { nome: "carne", dica: "Vem do animal, proteína 🥩" },
  { nome: "frango", dica: "Carne de ave 🍗" },
  { nome: "peixe", dica: "Vem do mar 🐟" },

  // 🏠 Objetos
  { nome: "mesa", dica: "Comemos em cima dela 🪑" },
  { nome: "cadeira", dica: "Sentamos nela 🪑" },
  { nome: "cama", dica: "Dormimos nela 🛏️" },
  { nome: "sofá", dica: "Assento grande e macio 🛋️" },
  { nome: "porta", dica: "Abre e fecha, entra e sai 🚪" },
  { nome: "janela", dica: "Vê o céu por ela 🪟" },
  { nome: "parede", dica: "Divide os ambientes 🏠" },
  { nome: "telhado", dica: "Cobre a casa de cima 🏠" },
  { nome: "chave", dica: "Abre a fechadura 🔑" },
  { nome: "cadeado", dica: "Fecha com senha ou chave 🔒" },
  { nome: "mochila", dica: "Levamos coisas nas costas 🎒" },
  { nome: "livro", dica: "Tem histórias e páginas 📖" },
  { nome: "caderno", dica: "Escrevemos nele 📓" },
  { nome: "caneta", dica: "Escreve com tinta 🖊️" },
  { nome: "lápis", dica: "Aponta com ponta de grafite ✏️" },
  { nome: "borracha", dica: "Apaga o que escrevemos 🧽" },
  { nome: "tesoura", dica: "Corta coisas ✂️" },
  { nome: "régua", dica: "Medir e fazer linha reta 📏" },
  { nome: "telefone", dica: "Falamos com quem está longe ☎️" },
  { nome: "celular", dica: "Telefone de bolso 📱" },
  { nome: "computador", dica: "Tela, teclado e processador 💻" },
  { nome: "teclado", dica: "Digita letras e números ⌨️" },
  { nome: "mouse", dica: "Controla o cursor do PC 🖱️" },
  { nome: "monitor", dica: "Tela do computador 🖥️" },
  { nome: "televisão", dica: "Vemos notícias e filmes 📺" },
  { nome: "controle", dica: "Aponta pra TV e muda canal 🎮" },
  { nome: "fone", dica: "Ouve som sem incomodar outros 🎧" },
  { nome: "relógio", dica: "Marca as horas ⌚" },
  { nome: "óculos", dica: "Usamos pra enxergar melhor 👓" },
  { nome: "espelho", dica: "Vê seu reflexo nele 🪞" },
  { nome: "garrafa", dica: "Guarda líquido 🍾" },
  { nome: "copo", dica: "Bebemos nele 🥛" },
  { nome: "prato", dica: "Comemos em cima 🍽️" },
  { nome: "colher", dica: "Para sopa e coisas líquidas 🥄" },
  { nome: "garfo", dica: "Pega a comida, tem dentes 🍴" },
  { nome: "faca", dica: "Corta os alimentos 🔪" },
  { nome: "guarda-chuva", dica: "Protege da chuva ☔" },
  { nome: "lanterna", dica: "Ilumina no escuro 🔦" },
  { nome: "câmera", dica: "Tira foto e grava vídeo 📷" },
  { nome: "carteira", dica: "Guarda dinheiro e documentos 👛" },
  { nome: "moeda", dica: "Dinheiro de metal 🪙" },
  { nome: "dinheiro", dica: "Precisamos pra comprar coisas 💵" },

  // 🚗 Transportes
  { nome: "carro", dica: "Quatro rodas, motor 🚗" },
  { nome: "moto", dica: "Duas rodas, mais rápida 🏍️" },
  { nome: "bicicleta", dica: "Pedala, sem motor 🚲" },
  { nome: "ônibus", dica: "Muitas pessoas juntas 🚌" },
  { nome: "trem", dica: "Vai nos trilhos 🚆" },
  { nome: "metrô", dica: "Trem que passa embaixo da cidade 🚇" },
  { nome: "avião", dica: "Voa alto, vai longe ✈️" },
  { nome: "helicóptero", dica: "Voa com hélices 🚁" },
  { nome: "navio", dica: "Barco grande, oceano 🚢" },
  { nome: "barco", dica: "Vai na água 🚤" },
  { nome: "iate", dica: "Barco de luxo 🛥️" },
  { nome: "canoa", dica: "Barco pequeno, rema 🛶" },
  { nome: "foguete", dica: "Vai pro espaço 🚀" },
  { nome: "patinete", dica: "Uma prancha com rodas 🛴" },
  { nome: "skate", dica: "Prancha, quatro rodas 🛹" },
  { nome: "caminhão", dica: "Carrega carga pesada 🚛" },
  { nome: "trator", dica: "Máquina na fazenda 🚜" },
  { nome: "ambulância", dica: "Levar doente pro hospital 🚑" },
  { nome: "táxi", dica: "Paga pra te levar onde quiser 🚕" },

  // 💻 Tecnologia
  { nome: "programar", dica: "Escrever instruções pro computador 💻" },
  { nome: "código", dica: "Linguagem que o computador entende 👨‍💻" },
  { nome: "bot", dica: "Robô que responde sozinho 🤖" },
  { nome: "whatsapp", dica: "App de mensagens 📱" },
  { nome: "javascript", dica: "Linguagem de programação 💛" },
  { nome: "node", dica: "Rodar JS fora do navegador 💚" },
  { nome: "servidor", dica: "Computador que guarda sites 🖥️" },
  { nome: "internet", dica: "Rede mundial de conexões 🌐" },
  { nome: "site", dica: "Página na internet 🌐" },
  { nome: "aplicativo", dica: "Programa no celular 📲" },
  { nome: "jogo", dica: "Diversão, entretenimento 🎮" },
  { nome: "tecnologia", dica: "Uso de conhecimentos práticos 🔧" },
  { nome: "software", dica: "Programas que rodam no PC 💿" },
  { nome: "hardware", dica: "Parte física do computador 🛠️" },
  { nome: "arquivo", dica: "Documento guardado no computador 📁" },
  { nome: "pasta", dica: "Guarda arquivos juntos 📂" },
  { nome: "senha", dica: "Segurança, segredo 🔐" },
  { nome: "login", dica: "Entrar numa conta 🔑" },
  { nome: "usuário", dica: "Pessoa que usa o sistema 👤" },
  { nome: "sistema", dica: "Conjunto de partes funcionando ⚙️" },
  { nome: "programa", dica: "Software que executa tarefa 💻" },
  { nome: "terminal", dica: "Tela de comando, texto puro 💻" },
  { nome: "termux", dica: "App de terminal no celular 📱" },
  { nome: "github", dica: "Guarda códigos, colabora 🐙" },
  { nome: "banco", dica: "Guarda dinheiro ou dados 🏦" },
  { nome: "dados", dica: "Informações armazenadas 📊" },
  { nome: "rede", dica: "Conexão entre aparelhos 🌐" },
  { nome: "wifi", dica: "Internet sem fio 📶" },
  { nome: "bluetooth", dica: "Conectar aparelhos próximos 📲" },
  { nome: "processador", dica: "Cérebro do computador 🧠" },
  { nome: "memória", dica: "Guarda dados temporários 📦" },
  { nome: "download", dica: "Baixar algo da internet ⬇️" },
  { nome: "upload", dica: "Enviar algo pra internet ⬆️" },
  { nome: "link", dica: "Endereço de site 🔗" },
  { nome: "navegador", dica: "Programa pra ver sites na internet 🌐" },
  { nome: "robô", dica: "Máquina que faz coisas sozinha 🤖" },

  // ❤️ Sentimentos
  { nome: "amizade", dica: "Ligação entre amigos 🤝" },
  { nome: "felicidade", dica: "Sentir-se bem, alegria 😊" },
  { nome: "liberdade", dica: "Poder fazer o que quiser 🕊️" },
  { nome: "amor", dica: "Sentimento mais forte ❤️" },
  { nome: "carinho", dica: "Atenção e afeto 🤗" },
  { nome: "alegria", dica: "Sorriso no rosto 😄" },
  { nome: "tristeza", dica: "Sentir dor no 😢" },
  { nome: "raiva", dica: "Irritação, fúria 😠" },
  { nome: "medo", dica: "Receio, insegurança 😨" },
  { nome: "coragem", dica: "Enfrentar sem temer 🦁" },
  { nome: "esperança", dica: "Acreditar que vai dar certo ✨" },
  { nome: "saudade", dica: "Sentir falta de alguém 💭" },
  { nome: "confiança", dica: "Acreditar em alguém 🤝" },
  { nome: "respeito", dica: "Tratar bem os outros 🙏" },
  { nome: "paz", dica: "Sem conflito, calma 🕊️" },
  { nome: "calma", dica: "Sem pressa, sem nervosismo 😌" },
  { nome: "ansiedade", dica: "Nervosismo, expectativa 😰" },
  { nome: "surpresa", dica: "Não esperava isso 😲" },
  { nome: "diversão", dica: "Passar tempo agradável 🎉" },
  { nome: "orgulho", dica: "Satisfação com algo feito 😌" },
  { nome: "força", dica: "Poder, vigor 💪" },
  { nome: "sonho", dica: "O que quer alcançar 💭" },
  { nome: "desejo", dica: "Querer muito algo ✨" },
  { nome: "paixão", dica: "Amor intenso ❤️‍🔥" },

  // ⚔️ Aventura
  { nome: "aventura", dica: "Viagem cheia de novidades 🏔️" },
  { nome: "desafio", dica: "Difícil, mas dá pra superar 🏆" },
  { nome: "missão", dica: "Objetivo a cumprir 🎯" },
  { nome: "herói", dica: "Salva o dia, faz o bem 🦸" },
  { nome: "vilão", dica: "Faz o mal, oposto do herói 🦹" },
  { nome: "guerreiro", dica: "Luta com coragem ⚔️" },
  { nome: "mago", dica: "Usa magia, lança feitiço 🧙" },
  { nome: "dragão", dica: "Monstro que cospe fogo 🐉" },
  { nome: "castelo", dica: "Onde mora o rei 🏰" },
  { nome: "espada", dica: "Arma branca, corta ⚔️" },
  { nome: "escudo", dica: "Protege de golpes 🛡️" },
  { nome: "armadura", dica: "Proteção de metal 🥷" },
  { nome: "tesouro", dica: "Ouro, joias, muito valioso 💰" },
  { nome: "mapa", dica: "Guia pra chegar ao lugar 🗺️" },
  { nome: "pirata", dica: "Navega, rouba no mar 🏴‍☠️" },
  { nome: "ninja", dica: "Esperto, silencioso 🥷" },
  { nome: "samurai", dica: "Guerreiro japonês ⚔️" },
  { nome: "monstro", dica: "Criatura feia e assustadora 👹" },
  { nome: "fantasma", dica: "Espírito que aparece 👻" },
  { nome: "zumbi", dica: "Morto que anda devagar 🧟" },
  { nome: "vampiro", dica: "Bebe sangue, tem presa 🧛" },
  { nome: "portal", dica: "Passagem pra outro lugar 🌀" },
  { nome: "magia", dica: "Coisa sobrenatural ✨" },
  { nome: "poder", dica: "Força, capacidade de agir 💪" },
  { nome: "batalha", dica: "Luta entre lados ⚔️" },
  { nome: "guerra", dica: "Conflito grande entre nações ⚔️" },
  { nome: "reino", dica: "Terra governada por rei 👑" },
  { nome: "coroa", dica: "O que o rei usa na cabeça 👑" },
  { nome: "princesa", dica: "Filha do rei 👸" },
  { nome: "príncipe", dica: "Filho do rei 🤴" },

  // 🎮 Jogos
  { nome: "minecraft", dica: "Mundo de blocos 🧱" },
  { nome: "roblox", dica: "Jogos dentro de jogos 🎮" },
  { nome: "fortnite", dica: "Batalha real, construir e lutar 🔫" },
  { nome: "pokemon", dica: "Capturar e treinar criaturas 🎮" },
  { nome: "futebol", dica: "Joga com a bola ⚽" },
  { nome: "xadrez", dica: "Peças no tabuleiro, estratégia ♟️" },
  { nome: "dominó", dica: "Peças com pontos 🁣" },
  { nome: "cartas", dica: "Baralho, vários jogos 🃏" },
  { nome: "dados", dica: "Joga, cai o número 🎲" },
  { nome: "corrida", dica: "Quem chega primeiro 🏁" },
  { nome: "estratégia", dica: "Planejar pra vencer ♟️" },
  { nome: "jogador", dica: "Quem participa do jogo 🎮" },
  { nome: "campeão", dica: "Venceu todos 🏆" },
  { nome: "vitória", dica: "Ganhou, venceu 🏆" },
  { nome: "derrota", dica: "Perdeu o jogo 😔" },
  { nome: "fase", dica: "Parte do jogo a superar 🎮" },
  { nome: "nível", dica: "Grau de dificuldade 📊" },
  { nome: "ponto", dica: "Contagem de acertos 📈" },
  { nome: "recorde", dica: "Melhor marca já feita 🏆" },
  { nome: "troféu", dica: "Prêmio de primeiro lugar 🏆" },
  { nome: "medalha", dica: "Recompensa de metal 🥇" },
  { nome: "partida", dica: "Um jogo completo 🏅" },
  { nome: "equipe", dica: "Grupo jogando junto 👥" },

  // 🏙️ Lugares
  { nome: "cidade", dica: "Lugar com muitas casas e gente 🏙️" },
  { nome: "vila", dica: "Pequena, menor que cidade 🏘️" },
  { nome: "escola", dica: "Lugar de aprender e estudar 🏫" },
  { nome: "hospital", dica: "Onde cuidam de doentes 🏥" },
  { nome: "mercado", dica: "Comprar comida e coisas 🏪" },
  { nome: "shopping", dica: "Lojas juntas, pra passear 🛍️" },
  { nome: "parque", dica: "Árvores, bancos, ar puro 🏞️" },
  { nome: "praça", dica: "Lugar aberto no centro da cidade 🏙️" },
  { nome: "igreja", dica: "Lugar de religião ⛪" },
  { nome: "hotel", dica: "Onde visitantes dormem 🏨" },
  { nome: "restaurante", dica: "Comida pronta pra comer 🍽️" },
  { nome: "cinema", dica: "Assistir filme na tela grande 🎬" },
  { nome: "biblioteca", dica: "Muitos livros 📚" },
  { nome: "museu", dica: "Obras antigas e histórias 🏛️" },
  { nome: "estádio", dica: "Onde joga futebol ⚽" },
  { nome: "fazenda", dica: "Cria animais e planta 🌾" },
  { nome: "casa", dica: "Onde moramos 🏠" },
  { nome: "quarto", dica: "Dormimos nele 🛏️" },
  { nome: "cozinha", dica: "Onde fazemos comida 🍳" },
  { nome: "banheiro", dica: "Lavar, tomar banho 🚿" },
  { nome: "garagem", dica: "Guarda o carro 🚗" },
  { nome: "jardim", dica: "Plantas e flores 🌷" },
  { nome: "escritório", dica: "Lugar de trabalho 💼" },

  // 👨‍🚀 Pessoas e profissões
  { nome: "professor", dica: "Ensina na escola 👨‍🏫" },
  { nome: "aluno", dica: "Aprende na escola 👨‍🎓" },
  { nome: "médico", dica: "Cuida da saúde 👨‍⚕️" },
  { nome: "enfermeiro", dica: "Ajuda o médico e cuida de pacientes 🩺" },
  { nome: "policial", dica: "Mantém a ordem 👮" },
  { nome: "bombeiro", dica: "Apaga fogo e salva vidas 👨‍🚒" },
  { nome: "motorista", dica: "Dirige veículos 🚗" },
  { nome: "cozinheiro", dica: "Faz comida 👨‍🍳" },
  { nome: "artista", dica: "Cria obras de arte 🎨" },
  { nome: "cantor", dica: "Canta músicas 🎤" },
  { nome: "ator", dica: "Faz teatro e filmes 🎭" },
  { nome: "programador", dica: "Escreve código de computador 👨‍💻" },
  { nome: "engenheiro", dica: "Projeta e constrói coisas 🏗️" },
  { nome: "cientista", dica: "Estuda o mundo e descobre coisas 🔬" },
  { nome: "piloto", dica: "Comanda avião ou nave ✈️" },
  { nome: "fotógrafo", dica: "Tira fotos 📷" },
  { nome: "vendedor", dica: "Vende produtos 💰" },
  { nome: "empresário", dica: "Comanda negócios 💼" },
  { nome: "agricultor", dica: "Planta e colhe alimentos 🌱" },
  { nome: "pescador", dica: "Pega peixes no mar 🎣" },
  { nome: "músico", dica: "Toca instrumentos musicais 🎵" },

  // 🎨 Cores
  { nome: "vermelho", dica: "Cor do fogo e do sangue 🔴" },
  { nome: "azul", dica: "Cor do céu e do mar 🔵" },
  { nome: "verde", dica: "Cor das plantas e folhas 🟢" },
  { nome: "amarelo", dica: "Cor do sol e da banana 🟡" },
  { nome: "roxo", dica: "Cor da uva 🟣" },
  { nome: "rosa", dica: "Cor suave, como flor 🌸" },
  { nome: "laranja", dica: "Cor da fruta de mesmo nome 🟠" },
  { nome: "preto", dica: "Cor da noite 🌑" },
  { nome: "branco", dica: "Cor da neve e do papel ⚪" },
  { nome: "cinza", dica: "Meio termo entre preto e branco 🩶" },
  { nome: "marrom", dica: "Cor da terra e do chocolate 🟤" },
  { nome: "dourado", dica: "Cor do ouro ✨" },
  { nome: "prata", dica: "Cor da prata, brilhante ⚪" },

  // ⏰ Tempo
  { nome: "hoje", dica: "O dia em que estamos agora 📅" },
  { nome: "amanhã", dica: "O dia que vem depois de hoje 🌅" },
  { nome: "ontem", dica: "O dia que já passou 📜" },
  { nome: "manhã", dica: "Primeira parte do dia 🌅" },
  { nome: "tarde", dica: "Depois do meio-dia 🌤️" },
  { nome: "noite", dica: "Quando escurece 🌙" },
  { nome: "madrugada", dica: "Meio da noite, antes do sol nascer 🌃" },
  { nome: "segundo", dica: "Unidade pequena de tempo ⏱️" },
  { nome: "minuto", dica: "Sessenta segundos ⏰" },
  { nome: "hora", dica: "Sessenta minutos ⌚" },
  { nome: "dia", dica: "Vinte e quatro horas 🌅" },
  { nome: "semana", dica: "Sete dias 📅" },
  { nome: "mês", dica: "Trinta dias aproximadamente 📆" },
  { nome: "ano", dica: "Trezentos e sessenta e cinco dias 🗓️" },
  { nome: "verão", dica: "Estação mais quente ☀️" },
  { nome: "inverno", dica: "Estação mais fria ❄️" },
  { nome: "outono", dica: "Folhas caem das árvores 🍂" },
  { nome: "primavera", dica: "Florescem as plantas 🌸" },

  // 🧠 Palavras aleatórias
  { nome: "mistério", dica: "Algo difícil de entender 🕵️" },
  { nome: "segredo", dica: "Só você sabe, não conta pra ninguém 🤫" },
  { nome: "enigma", dica: "Pergunta que precisa decifrar 🧩" },
  { nome: "sorte", dica: "Dar certo sem esforço 🎰" },
  { nome: "azar", dica: "Dar errado sem querer 🎲" },
  { nome: "velocidade", dica: "Quão rápido algo vai 🏎️" },
  { nome: "energia", dica: "Força pra fazer coisas ⚡" },
  { nome: "dimensão", dica: "Comprimento, largura, altura 📐" },
  { nome: "tempo", dica: "Passa, não para ⏳" },
  { nome: "memória", dica: "Guardar lembranças 🧠" },
  { nome: "história", dica: "O que aconteceu no passado 📖" },
  { nome: "futuro", dica: "O que ainda vai acontecer 🔮" },
  { nome: "passado", dica: "O que já aconteceu ⏮️" },
  { nome: "presente", dica: "Agora, neste momento 🎁" },
  { nome: "mundo", dica: "O planeta inteiro 🌍" },
  { nome: "vida", dica: "Existir, estar vivo ❤️" },
  { nome: "morte", dica: "Fim da vida 💀" },
  { nome: "começo", dica: "O início de algo 🔛" },
  { nome: "fim", dica: "O final de algo 🏁" },
  { nome: "início", dica: "O mesmo que começo 🔛" },
  { nome: "segurança", dica: "Estar protegido 🛡️" },
  { nome: "perigo", dica: "Algo ruim pode acontecer ⚠️" },
  { nome: "fantasia", dica: "Coisas imaginárias, não reais 🦄" },
  { nome: "realidade", dica: "O que realmente existe 🌍" },
  { nome: "criatividade", dica: "Criar coisas novas 💡" },
  { nome: "inteligência", dica: "Capacidade de entender e raciocinar 🧠" },
  { nome: "conhecimento", dica: "O que aprendeu estudando 📚" },
  { nome: "sabedoria", dica: "Experiência e conhecimento juntos 🧙" },
  { nome: "curiosidade", dica: "Querer saber mais de algo 🤔" },
  { nome: "imaginação", dica: "Criar coisas na mente 💭" },
  { nome: "risada", dica: "Sinal de alegria 😂" },
  { nome: "piada", dica: "Coisa engraçada que se conta 😄" }
];

// ⚙️ Configurações por tamanho
const CONFIG_NIVEIS = {
  8: { linhas: 8, colunas: 8, palavrasQtd: 5, recompensa: 15 },
  16: { linhas: 12, colunas: 16, palavrasQtd: 10, recompensa: 30 },
  32: { linhas: 16, colunas: 32, palavrasQtd: 15, recompensa: 70 }
};

// 📦 Carregar/Salvar dados do RPG
function carregarRPG() {
  try {
    if (!fs.existsSync(CAMINHO_RPG)) return {};
    return JSON.parse(fs.readFileSync(CAMINHO_RPG, "utf-8"));
  } catch { return {}; }
}

function salvarRPG(dados) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify(dados, null, 2));
}

// 📦 Jogos ativos por usuário
const jogosAtivos = {};

// 🔤 Gerar grade de letras aleatórias
function gerarGrade(linhas, colunas) {
  const letras = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const grade = [];
  for (let i = 0; i < linhas; i++) {
    const linha = [];
    for (let j = 0; j < colunas; j++) {
      linha.push(letras[Math.floor(Math.random() * letras.length)]);
    }
    grade.push(linha);
  }
  return grade;
}

// 📝 Escolher palavras aleatórias
function escolherPalavras(qtd) {
  const palavrasUnicas = [...new Set(LISTA_PALAVRAS)];
  const embaralhadas = palavrasUnicas.sort(() => Math.random() - 0.5);
  return embaralhadas.slice(0, qtd).map(p => p.nome.toUpperCase());
}

// 🔤 Inserir palavras na grade
function inserirPalavrasNaGrade(grade, palavras) {
  const linhas = grade.length;
  const colunas = grade[0].length;
  const direcoes = ["horizontal", "vertical", "diagonal"];

  palavras.forEach(palavra => {
    let inserido = false;
    let tentativas = 0;
    
    while (!inserido && tentativas < 100) {
      tentativas++;
      const dir = direcoes[Math.floor(Math.random() * direcoes.length)];
      let x, y;

      if (dir === "horizontal" && palavra.length <= colunas) {
        x = Math.floor(Math.random() * (colunas - palavra.length + 1));
        y = Math.floor(Math.random() * linhas);
        for (let i = 0; i < palavra.length; i++) {
          grade[y][x + i] = palavra[i];
        }
        inserido = true;
      } else if (dir === "vertical" && palavra.length <= linhas) {
        x = Math.floor(Math.random() * colunas);
        y = Math.floor(Math.random() * (linhas - palavra.length + 1));
        for (let i = 0; i < palavra.length; i++) {
          grade[y + i][x] = palavra[i];
        }
        inserido = true;
      } else if (dir === "diagonal" && palavra.length <= linhas && palavra.length <= colunas) {
        x = Math.floor(Math.random() * (colunas - palavra.length + 1));
        y = Math.floor(Math.random() * (linhas - palavra.length + 1));
        if (y + palavra.length <= linhas && x + palavra.length <= colunas) {
          for (let i = 0; i < palavra.length; i++) {
            grade[y + i][x + i] = palavra[i];
          }
          inserido = true;
        }
      }
    }
  });

  return grade;
}

// 📋 Formatar grade para texto
function formatarGrade(grade) {
  return grade.map(linha => linha.join(" ")).join("\n");
}

// 🎮 Iniciar novo jogo
function iniciarJogo(usuario, nivel) {
  const config = CONFIG_NIVEIS[nivel];
  if (!config) return null;

  const palavras = escolherPalavras(config.palavrasQtd);
  let grade = gerarGrade(config.linhas, config.colunas);
  grade = inserirPalavrasNaGrade(grade, palavras);

  jogosAtivos[usuario] = {
    nivel,
    palavras,
    encontradas: [],
    grade,
    recompensa: config.recompensa,
    inicio: Date.now()
  };

  return jogosAtivos[usuario];
}

// ✅ Verificar palavra
function verificarPalavra(usuario, palavra) {
  const jogo = jogosAtivos[usuario];
  if (!jogo) return { status: "sem_jogo" };

  palavra = palavra.toUpperCase().trim();
  
  // Já foi encontrada?
  if (jogo.encontradas.includes(palavra)) {
    return { status: "ja_encontrada" };
  }

  // Está na lista?
  if (jogo.palavras.includes(palavra)) {
    jogo.encontradas.push(palavra);
    
    // Completou todas?
    if (jogo.encontradas.length === jogo.palavras.length) {
      return { status: "completo", jogo };
    }
    return { status: "encontrada", restantes: jogo.palavras.length - jogo.encontradas.length };
  }

  return { status: "nao_existe" };
}

// ❌ Cancelar jogo
function cancelarJogo(usuario) {
  if (jogosAtivos[usuario]) {
    delete jogosAtivos[usuario];
    return true;
  }
  return false;
}

// 💰 Adicionar moedas
function adicionarMoedas(usuario, quantidade) {
  const dados = carregarRPG();
  if (!dados[usuario]) dados[usuario] = { moedas: 0 };
  dados[usuario].moedas = (dados[usuario].moedas || 0) + quantidade;
  salvarRPG(dados);
  return dados[usuario].moedas;
}

// 🔍 Verificar se tem jogo ativo
function temJogoAtivo(usuario) {
  return !!jogosAtivos[usuario];
}

function getJogo(usuario) {
  return jogosAtivos[usuario];
}

module.exports = {
  iniciarJogo,
  verificarPalavra,
  cancelarJogo,
  adicionarMoedas,
  temJogoAtivo,
  getJogo,
  formatarGrade,
  CONFIG_NIVEIS
};

