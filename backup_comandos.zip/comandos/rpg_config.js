const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const PREFIXO = config.prefixo || "!";
const CAMINHO_CFG_RPG = path.join(__dirname, "..", "dados", "config_rpg_grupos.json");
const CAMINHO_RPG = path.join(__dirname, "..", "dados", "rpg_dados.json");

// 📂 Garante arquivos
if (!fs.existsSync(path.dirname(CAMINHO_CFG_RPG))) fs.mkdirSync(path.dirname(CAMINHO_CFG_RPG), { recursive: true });
if (!fs.existsSync(CAMINHO_CFG_RPG)) fs.writeFileSync(CAMINHO_CFG_RPG, JSON.stringify({}));
if (!fs.existsSync(CAMINHO_RPG)) fs.writeFileSync(CAMINHO_RPG, JSON.stringify({}));

// 📖 Funções
function carregarCfgRPG() {
  try { return JSON.parse(fs.readFileSync(CAMINHO_CFG_RPG, "utf-8")); }
  catch { return {}; }
}
function salvarCfgRPG(dados) {
  fs.writeFileSync(CAMINHO_CFG_RPG, JSON.stringify(dados, null, 2));
}
function carregarDadosRPG() {
  try { return JSON.parse(fs.readFileSync(CAMINHO_RPG, "utf-8")); }
  catch { return {}; }
}
function salvarDadosRPG(dados) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify(dados, null, 2));
}
function formatarUsuario(jid) {
  return jid?.split("@")[0]?.split(":")[0] || "Desconhecido";
}
function ehGrupo(idChat) { return idChat.includes("@g.us"); }
async function ehAdmin(sock, idGrupo, idUsuario) {
  try {
    const meta = await sock.groupMetadata(idGrupo);
    return meta.participants.some(p => p.id === idUsuario && p.admin);
  } catch { return false; }
}

module.exports = {
  // ✅ Verifica se RPG está ativo no grupo
  rpgAtivoNoGrupo: function(idGrupo) {
    const cfg = carregarCfgRPG();
    return !!cfg[idGrupo]?.ativo;
  },

  // ✅ Inicializa dados do usuário se não existir
  inicializarUsuario: function(usuario) {
    const dados = carregarDadosRPG();
    if (!dados[usuario]) {
      dados[usuario] = {
        saldo: 0,
        nivel: 1,
        xp: 0,
        ultimoAcesso: null,
        ultimoTrabalho: 0,
        ultimoCrime: 0,
        ultimoPesca: 0,
        ultimoMineracao: 0,
        presoAte: 0,
        itens: [],
        pet: null,
        ultimoInvestimento: null,
        bonusCarteiraAte: 0,
        contagemDiaria: {
          brincarPet: 0,
          treinarPet: 0,
          primeiraMensagemDia: null
        }
      };
      salvarDadosRPG(dados);
    }
    return dados[usuario];
  },

  // ✅ Adicionar/remover moedas (compartilhado com jogos!)
  alterarSaldo: function(usuario, valor) {
    const dados = carregarDadosRPG();
    this.inicializarUsuario(usuario);
    dados[usuario].saldo = Math.max(0, dados[usuario].saldo + valor);
    salvarDadosRPG(dados);
    return dados[usuario].saldo;
  },

  comandos: {
    // ⚙️ !rpg on/off — Ativa/desativa RPG no grupo (só admin)
    rpg: async function(sock, msg, args) {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;

      if (!ehGrupo(idChat)) {
        return sock.sendMessage(idChat, { text: `⚠️ Use apenas em grupos!` }, { quoted: msg });
      }
      if (!(await ehAdmin(sock, idChat, remetente))) {
        return sock.sendMessage(idChat, { text: `⛔ Apenas administradores!` }, { quoted: msg });
      }

      const acao = args[0]?.toLowerCase();
      const cfg = carregarCfgRPG();
      if (!cfg[idChat]) cfg[idChat] = {};

      if (acao === "on" || acao === "ativar") {
        cfg[idChat].ativo = true;
        salvarCfgRPG(cfg);
        return sock.sendMessage(idChat, {
          text: `✅ *RPG ATIVADO NO GRUPO!* 🎮

Todos os comandos de RPG agora estão disponíveis!
Use ${PREFIXO}saldo para ver seus ganhos.`
        }, { quoted: msg });
      }

      if (acao === "off" || acao === "desativar") {
        cfg[idChat].ativo = false;
        salvarCfgRPG(cfg);
        return sock.sendMessage(idChat, {
          text: `❌ *RPG DESATIVADO!*

Os comandos de RPG foram desligados neste grupo.`
        }, { quoted: msg });
      }

      const status = cfg[idChat]?.ativo ? "✅ ATIVADO" : "❌ DESATIVADO";
      return sock.sendMessage(idChat, {
        text: `⚙️ *STATUS DO RPG* ⚙️

Atualmente: ${status}

Use:
${PREFIXO}rpg on  — Ativar
${PREFIXO}rpg off — Desativar`
      }, { quoted: msg });
    }
  }
};

