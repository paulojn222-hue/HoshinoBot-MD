const config = require("../config.js");
const { downloadMediaMessage } = require("@whiskeysockets/baileys");
const { execFile } = require("child_process");
const fs = require("fs");
const path = require("path");

const PREFIXO = config.prefixo || "!";
const NOME_BOT = config.nomeBot || "SukunaBot-MD";
const NOME_AUTOR_PADRAO = config.nomeDono || "MoonDev";

const CAMINHO_MENU_FIG = path.join(__dirname, "..", "menus", "figurinhas.txt");
const CAMINHO_FOTO_MENU = path.join(__dirname, "..", "midias", "video_menu.mp4");
const CAMINHO_AUTOFIG = path.join(__dirname, "..", "dados", "autofig.json");

function carregarAutoFig() {
  try {
    if (!fs.existsSync(CAMINHO_AUTOFIG)) return {};
    return JSON.parse(fs.readFileSync(CAMINHO_AUTOFIG, "utf‑8"));
  } catch { return {}; }
}

function salvarAutoFig(dados) {
  fs.writeFileSync(CAMINHO_AUTOFIG, JSON.stringify(dados, null, 2));
}

// 📝 Frases aleatórias para exibir enquanto cria
const FRASES_CRIANDO = [
  "🎨 Preparando a arte...",
  "✨ Deixando tudo bonito...",
  "🖌️ Aplicando os detalhes...",
  "📐 Ajustando o tamanho...",
  "💾 Salvando a figurinha...",
  "🌟 Quase pronta...",
  "🤩 Ficou incrível!",
  "🎯 Criando com carinho...",
  "🪄 Fazendo a mágica acontecer...",
  "⚡ Trabalhando rapidinho..."
];

// 📝 Fatos e mensagens finais
const FRASES_FINAL = [
  "✅ Prontinho! Sua figurinha está criada!",
  "🎉 Figurinha pronta para usar!",
  "💫 Mais uma obra de arte concluída!",
  "🎭 Aqui está sua figurinha!",
  "🆕 Figurinha nova em folha!"
];

function fraseAleatoria(lista) {
  return lista[Math.floor(Math.random() * lista.length)];
}

module.exports = {
  nome: "figurinhas",

  comandos: {
    // 📋 !menufig — Menu de figurinhas
    menufig: async (sock, msg, args, dados) => {
      const idChat = dados.idChat;
      const remetente = dados.remetente;
      const mencao = `@${remetente.split("@")[0]}`;
      let textoMenu = "";

      if (fs.existsSync(CAMINHO_MENU_FIG)) {
        textoMenu = fs.readFileSync(CAMINHO_MENU_FIG, "utf-8");
        textoMenu = textoMenu.replace(/{NOME_BOT}/g, NOME_BOT);
        textoMenu = textoMenu.replace(/{PREFIXO}/g, PREFIXO);
      } else {
        textoMenu = `╭━━━━━━━━━━ 🎨 ━━━━━━━━━━╮
┃
┃   🎨 𝙈𝙀𝙉𝙐 𝘿𝙀 𝙁𝙄𝙂𝙐𝙍𝙄𝙉𝙃𝘼𝙎 🎨
┃   ───────────────────────
┃   🖼️ 𝗖𝗥𝗜𝗔𝗥 𝗙𝗜𝗚𝗨𝗥𝗜𝗡𝗛𝗔𝗦
┃   ├─ ${PREFIXO}s — Criar figurinha
┃   ├─ ${PREFIXO}img — Figurinha → Imagem
┃   ├─ ${PREFIXO}togif — Figurinha → Vídeo
┃   ├─ ${PREFIXO}rename — Renomear figurinha
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━╯`;
      }

      if (fs.existsSync(CAMINHO_FOTO_MENU)) {
        return await sock.sendMessage(idChat, {
          image: fs.readFileSync(CAMINHO_FOTO_MENU),
          caption: textoMenu,
          mentions: [remetente]
        });
      }
      return await sock.sendMessage(idChat, {
        text: textoMenu,
        mentions: [remetente]
      });
    },

/*
case(s) abaixo, peço que deixe os devidos créditos.
criador dessa getcase → @Nk Petrøv.
pegue as cases aí e use com moderação.
*/

s: async (sock, msg, args, dados) => {
  const idChat = dados.idChat;
  const remetente = dados.remetente;
  const RSM = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;

  const NOME_PACK = config.nomeBot || "SukunaBot-MD";
  const NOME_AUTOR = config.nomeDono || "MoonDev";

  var boij2 = RSM?.imageMessage || msg.message?.imageMessage || RSM?.viewOnceMessageV2?.message?.imageMessage || msg.message?.viewOnceMessageV2?.message?.imageMessage || msg.message?.viewOnceMessage?.message?.imageMessage || RSM?.viewOnceMessage?.message?.imageMessage;
  var boij = RSM?.videoMessage || msg.message?.videoMessage || RSM?.viewOnceMessageV2?.message?.videoMessage || msg.message?.viewOnceMessageV2?.message?.videoMessage || msg.message?.viewOnceMessage?.message?.videoMessage || RSM?.viewOnceMessage?.message?.videoMessage;

  if (boij2) {
    await sock.sendMessage(idChat, { text: "🎭 Criando figurinha..." });
    const buffer = await downloadMediaMessage(
      { message: RSM || msg.message, key: msg.key },
      "buffer",
      {}
    );

    const pastaTemp = path.join(__dirname, "temp");
    if (!fs.existsSync(pastaTemp)) fs.mkdirSync(pastaTemp, { recursive: true });
    const entrada = path.join(pastaTemp, `entrada_${Date.now()}`);
    const saida = path.join(pastaTemp, `saida_${Date.now()}.webp`);
    fs.writeFileSync(entrada, buffer);

    await new Promise((resolve, reject) => {
      require("child_process").execFile("convert", [
        entrada,
        "-resize", "512x512>",
        "-background", "none",
        "-alpha", "on",
        "-format", "webp",
        "-quality", "90",
        saida
      ], (erro) => erro ? reject(erro) : resolve());
    });

    const figurinha = fs.readFileSync(saida);
    await sock.sendMessage(idChat, {
      sticker: figurinha,
      stickerName: `${NOME_PACK} 💎`,
      stickerAuthor: NOME_AUTOR,
      packname: `${NOME_PACK} 💎`,
      author: NOME_AUTOR
    });
    try { fs.unlinkSync(entrada); fs.unlinkSync(saida); } catch {}
  }
  else if (boij && (RSM?.videoMessage?.seconds || msg.message?.videoMessage?.seconds || 0) < 11) {
    await sock.sendMessage(idChat, { text: "🎭 Criando figurinha animada..." });
    const buffer = await downloadMediaMessage(
      { message: RSM || msg.message, key: msg.key },
      "buffer",
      {}
    );

    const pastaTemp = path.join(__dirname, "temp");
    if (!fs.existsSync(pastaTemp)) fs.mkdirSync(pastaTemp, { recursive: true });
    const entrada = path.join(pastaTemp, `vid_${Date.now()}`);
    const saida = path.join(pastaTemp, `fig_anim_${Date.now()}.webp`);
    fs.writeFileSync(entrada, buffer);

    await new Promise((resolve, reject) => {
      require("child_process").execFile("ffmpeg", [
        "-i", entrada,
        "-vf", "scale=512:512:force_original_aspect_ratio=decrease",
        "-c:v", "libwebp",
        "-pix_fmt", "yuva420p",
        "-loop", "0",
        "-preset", "default",
        "-an",
        "-y",
        saida
      ], (erro) => erro ? reject(erro) : resolve());
    });

    const figurinha = fs.readFileSync(saida);
    await sock.sendMessage(idChat, {
      sticker: figurinha,
      stickerName: `${NOME_PACK} 💎`,
      stickerAuthor: NOME_AUTOR,
      packname: `${NOME_PACK} 💎`,
      author: NOME_AUTOR
    });
    try { fs.unlinkSync(entrada); fs.unlinkSync(saida); } catch {}
  }
  else {
    await sock.sendMessage(idChat, {
      text: "⚠️ Marque uma imagem ou vídeo curto (até 10s)!\nUso: responda com " + PREFIXO + "s"
    });
  }
},
//Nk' Petrøv

// ⚙️ !autofig — Ativa/desativa criação automática de figurinhas
autofig: async (sock, msg, args, dados) => {
  const idChat = dados.idChat;
  const remetente = dados.remetente;
  const grupo = idChat.endsWith("@g.us");

  if (!grupo) {
    return await sock.sendMessage(idChat, {
      text: "⚠️ Esse comando só funciona em grupos!"
    });
  }

  const listaAuto = carregarAutoFig();
  const statusAtual = listaAuto[idChat] ?? false;
  const novoStatus = !statusAtual;
  listaAuto[idChat] = novoStatus;
  salvarAutoFig(listaAuto);

  await sock.sendMessage(idChat, {
    text: novoStatus
      ? "✅ Auto‑Fig ativado!\nImagens/vídeos enviados aqui virarão figurinha automaticamente."
      : "❌ Auto‑Fig desativado!"
  });
},

    // 🖼️ !img — Figurinha → Imagem
    img: async (sock, msg, args, dados) => {
      const idChat = dados.idChat;
      const citada = msg.message?.extendedTextMessage?.contextInfo;

      if (!citada?.quotedMessage?.stickerMessage) {
        return await sock.sendMessage(idChat, {
          text: `🖼️ Marque uma figurinha!\nExemplo: ${PREFIXO}img`
        });
      }

      await sock.sendMessage(idChat, { text: "🖼️ Convertendo..." });

      try {
        const buffer = await downloadMediaMessage(
          { message: citada.quotedMessage, key: msg.key },
          "buffer",
          {}
        );
        await sock.sendMessage(idChat, {
          image: buffer,
          mimetype: "image/png"
        });
      } catch (erro) {
        console.log("❌ Erro !img:", erro.message);
        await sock.sendMessage(idChat, {
          text: "❌ Erro ao converter"
        });
      }
    },

    // 🎞️ !togif — Figurinha → Vídeo
    togif: async (sock, msg, args, dados) => {
      const idChat = dados.idChat;
      const citada = msg.message?.extendedTextMessage?.contextInfo;

      if (!citada?.quotedMessage?.stickerMessage) {
        return await sock.sendMessage(idChat, {
          text: `🎞️ Marque uma figurinha!\nExemplo: ${PREFIXO}togif`
        });
      }

      await sock.sendMessage(idChat, { text: "🎞️ Convertendo..." });

      try {
        const buffer = await downloadMediaMessage(
          { message: citada.quotedMessage, key: msg.key },
          "buffer",
          {}
        );

        const pastaTemp = path.join(__dirname, "temp");
        if (!fs.existsSync(pastaTemp)) fs.mkdirSync(pastaTemp, { recursive: true });

        const entradaWebp = path.join(pastaTemp, `fig_${Date.now()}.webp`);
        const saidaMp4 = path.join(pastaTemp, `video_${Date.now()}.mp4`);
        fs.writeFileSync(entradaWebp, buffer);

        await new Promise((resolve, reject) => {
          execFile("ffmpeg", [
            "-i", entradaWebp,
            "-c:v", "libx264",
            "-pix_fmt", "yuv420p",
            "-vf", "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2",
            "-r", "15",
            "-t", "5",
            "-preset", "ultrafast",
            "-crf", "28",
            "-an",
            "-y",
            saidaMp4
          ], (erro, stdout, stderr) => {
            if (erro) {
              console.log("FFmpeg erro:", stderr?.slice(0, 500));
              return reject(erro);
            }
            resolve();
          });
        });

        if (!fs.existsSync(saidaMp4) || fs.statSync(saidaMp4).size < 100) {
          throw new Error("Vídeo não foi gerado corretamente");
        }

        const videoFinal = fs.readFileSync(saidaMp4);
        await sock.sendMessage(idChat, {
          video: videoFinal,
          mimetype: "video/mp4"
        });

        try { fs.unlinkSync(entradaWebp); fs.unlinkSync(saidaMp4); } catch {}
      } catch (erro) {
        console.log("❌ Erro !togif:", erro.message);

        try {
          await sock.sendMessage(idChat, { text: "🎞️ Tentando método alternativo..." });

          const buffer = await downloadMediaMessage(
            { message: citada.quotedMessage, key: msg.key },
            "buffer",
            {}
          );

          const pastaTemp = path.join(__dirname, "temp");
          if (!fs.existsSync(pastaTemp)) fs.mkdirSync(pastaTemp, { recursive: true });

          const entradaPng = path.join(pastaTemp, `fig_${Date.now()}.png`);
          const saidaFinal = path.join(pastaTemp, `video_${Date.now()}.mp4`);
          fs.writeFileSync(entradaPng, buffer);

          await new Promise((resolve, reject) => {
            execFile("ffmpeg", [
              "-i", entradaPng,
              "-vf", "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2",
              "-c:v", "libx264",
              "-pix_fmt", "yuv420p",
              "-t", "5",
              "-r", "15",
              "-y",
              saidaFinal
            ], (erro) => erro ? reject(erro) : resolve());
          });

          const videoFinal = fs.readFileSync(saidaFinal);
          await sock.sendMessage(idChat, {
            video: videoFinal,
            mimetype: "video/mp4"
          });

          try { fs.unlinkSync(entradaPng); fs.unlinkSync(saidaFinal); } catch {}
        } catch (erro2) {
          await sock.sendMessage(idChat, {
            text: "❌ Não foi possível converter!\nA figurinha pode estar corrompida ou em formato incompatível."
          });
        }
      }
    },

/*
case(s) abaixo, peço que deixe os devidos créditos.
criador dessa getcase → @Nk Petrøv.
pegue as cases aí e use com moderação.
*/

/*
case(s) abaixo, peço que deixe os devidos créditos.
criador dessa getcase → @Nk Petrøv.
pegue as cases aí e use com moderação.
*/

/*
case(s) abaixo, peço que deixe os devidos créditos.
criador dessa getcase → @Nk Petrøv.
pegue as cases aí e use com moderação.
*/

/*
case(s) abaixo, peço que deixe os devidos créditos.
criador dessa getcase → @Nk Petrøv.
pegue as cases aí e use com moderação.
*/

rename: async (sock, msg, args, dados) => {
  const idChat = dados.idChat;
  const citada = msg.message?.extendedTextMessage?.contextInfo;
  const isQuotedSticker = citada?.quotedMessage?.stickerMessage;

  if (!isQuotedSticker)
    return await sock.sendMessage(idChat, {
      text: "⚠️ Responda a uma figurinha com:\n" + PREFIXO + "rename NomeDoPacote / Autor"
    });

  const q = args.join(" ").trim();
  if (!q) {
    return await sock.sendMessage(idChat, {
      text: "⚠️ Digite os nomes!\nExemplo: " + PREFIXO + "rename opa / teste"
    });
  }

  const partes = q.split("/");
  const pack = partes[0]?.trim();
  const author2 = partes[1]?.trim();

  if (!pack || !author2) {
    return await sock.sendMessage(idChat, {
      text: "⚠️ Formato inválido!\nUse: " + PREFIXO + "rename Nome / Autor"
    });
  }

  await sock.sendMessage(idChat, { text: "✏️ Renomeando..." });

  try {
    const buffer = await downloadMediaMessage(
      { message: citada.quotedMessage, key: msg.key },
      "buffer",
      {}
    );

    await sock.sendMessage(idChat, {
      sticker: buffer
    }, {
      quoted: msg,
      packname: pack,
      author: author2,
      name: pack
    });

    await sock.sendMessage(idChat, {
      text: `✅ Figurinha renomeada!\n\n📦 Pacote: ${pack}\n✏️ Autor: ${author2}`
    });
  }
  catch (e) {
    console.error("❌ Erro:", e);
    await sock.sendMessage(idChat, { text: "❌ Erro ao renomear!" });
  }
}
//Nk' Petrøv

  }
};

