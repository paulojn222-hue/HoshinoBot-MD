const config = require("../config.js");
const fs = require("fs");
const path = require("path");

// 📦 Funções do sistema de atualização (chamadas do index.js)
let funcoesAtualizar;
function setFuncoes(fns) { funcoesAtualizar = fns; }

const comandos = {
  // 🔄 !atualizar — Apenas dono principal
  atualizar: async (sock, msg, args, dados) => {
    const idChat = dados.idChat || msg.key.remoteJid;
    const remetente = dados.remetente || msg.key.participant || msg.key.remoteJid;
    const DONO = String(config.numeroDono).replace(/\D/g, "");
    const remetenteLimpo = String(remetente).replace(/\D/g, "");

    if (remetenteLimpo !== DONO) {
      return await sock.sendMessage(idChat, { text: "⚠️ Apenas o dono pode usar esse comando!" });
    }
    if (!funcoesAtualizar?.atualizarArquivos) {
      return await sock.sendMessage(idChat, { text: "❌ Sistema de atualização não carregado no index.js!" });
    }

    await sock.sendMessage(idChat, { text: "🔄 Verificando atualizações no GitHub…" });
    const resultado = await funcoesAtualizar.atualizarArquivos();

    if (!resultado.ok) {
      return await sock.sendMessage(idChat, { text: `❌ Falha: ${resultado.mensagem}` });
    }
    if (!resultado.temAtualizacao) {
      return await sock.sendMessage(idChat, {
        text: `✅ Já está na última versão!\n\n📋 Notas da versão:\n${resultado.notas || "Sem anotações."}`
      });
    }

    await sock.sendMessage(idChat, {
      text: `✅ Atualização concluída!\n🆕 Nova versão: ${resultado.novaVersao}\n📋 O que mudou:\n${resultado.notas}\n\n⚠️ Reinicie o bot para aplicar as alterações!`
    });
  }
};

module.exports = { comandos, setFuncoes };

