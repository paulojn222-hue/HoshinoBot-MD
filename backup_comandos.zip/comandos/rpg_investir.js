const config = require("../config.js");
const fs = require("fs");
const path = require("path");
const { inicializarUsuario, alterarSaldo } = require("./rpg_saldo.js");

const PREFIXO = config.prefixo || "!";
const CAMINHO_RPG = path.join(__dirname, "..", "dados", "rpg_dados.json");
const TEMPO_RETORNO = 4 * 60 * 60 * 1000; // ⏰ 4 horas

// 📊 Opções de investimento
const OPCOES_INVESTIMENTO = [
  { id: "jogo", nome: "🎮 Loja de Jogos", valorMin: 100, valorMax: 500 },
  { id: "empresa", nome: "🏢 Empresa", valorMin: 300, valorMax: 1000 },
  { id: "escola", nome: "🏫 Escola/Curso", valorMin: 150, valorMax: 600 },
  { id: "lanches", nome: "🍔 Lanchonete", valorMin: 80, valorMax: 350 },
  { id: "feira", nome: "🛍️ Feira/Comércio", valorMin: 50, valorMax: 250 }
];

if (!fs.existsSync(path.dirname(CAMINHO_RPG))) {
  fs.mkdirSync(path.dirname(CAMINHO_RPG), { recursive: true });
}
if (!fs.existsSync(CAMINHO_RPG)) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify({}));
}

function salvarDados(dados) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify(dados, null, 2));
}

module.exports = {
  comandos: {
    investir: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;

      const dadosUser = inicializarUsuario(remetente);
      const agora = Date.now();

      // 📋 Verifica se tem investimento pendente
      if (dadosUser.investimentosPendentes) {
        const prontos = [];
        const aindaEspera = [];

        dadosUser.investimentosPendentes.forEach(inv => {
          if (agora >= inv.retornoEm) {
            prontos.push(inv);
          } else {
            aindaEspera.push(inv);
          }
        });

        // 💰 Investimentos prontos — calcula resultado
        if (prontos.length > 0) {
          let textoResultado = `📊 *RESULTADO DOS INVESTIMENTOS* 📊\n\n`;

          prontos.forEach(inv => {
            const deuCerto = Math.random() < 0.4; // 40% de lucro, 60% de perda

            if (deuCerto) {
              const lucro = Math.floor(inv.valor * (Math.random() * 0.5 + 0.3)); // +30% a +80%
              alterarSaldo(remetente, inv.valor + lucro);
              textoResultado += `✅ ${inv.opcao.nome}: +${lucro} moedas de lucro! 💰\n`;
            } else {
              const perda = Math.floor(inv.valor * (Math.random() * 0.4 + 0.2)); // perde 20% a 60%
              alterarSaldo(remetente, inv.valor - perda);
              textoResultado += `❌ ${inv.opcao.nome}: perdeu ${perda} moedas... 😔\n`;
            }
          });

          dadosUser.investimentosPendentes = aindaEspera;
          const dados = JSON.parse(fs.readFileSync(CAMINHO_RPG, "utf-8"));
          dados[remetente] = dadosUser;
          salvarDados(dados);

          await sock.sendMessage(idChat, { text: textoResultado }, { quoted: msg });
        }
      } else {
        dadosUser.investimentosPendentes = [];
      }

      // 📜 Sem argumentos = mostra opções e pendentes
      if (args.length === 0) {
        let texto = `📊 *INVESTIMENTOS* 📊\n\n`;
        texto += `Escolha um ramo para investir:\n\n`;

        OPCOES_INVESTIMENTO.forEach((op, i) => {
          texto += `${i + 1}. ${op.nome}\n`;
          texto += `   💸 Valor: ${op.valorMin} a ${op.valorMax} moedas\n\n`;
        });

        texto += `⏰ Retorno em: 4 horas\n`;
        texto += `📈 Chance de lucro: 40% | 📉 Chance de perda: 60%\n\n`;
        texto += `> Use: ${PREFIXO}investir [número] [valor]\n`;
        texto += `> Exemplo: ${PREFIXO}investir 2 500\n\n`;

        if (dadosUser.investimentosPendentes.length > 0) {
          texto += `⏳ *Investimentos em andamento:*\n`;
          dadosUser.investimentosPendentes.forEach(inv => {
            const horasRestantes = Math.ceil((inv.retornoEm - agora) / 3600000);
            texto += `- ${inv.opcao.nome}: ${inv.valor} moedas (${horasRestantes}h restantes)\n`;
          });
        }

        return sock.sendMessage(idChat, { text: texto }, { quoted: msg });
      }

      // 💰 Faz o investimento
      const numeroOpcao = parseInt(args[0]);
      const valorInvestir = parseInt(args[1]);

      if (isNaN(numeroOpcao) || numeroOpcao < 1 || numeroOpcao > OPCOES_INVESTIMENTO.length) {
        return sock.sendMessage(idChat, {
          text: `❌ *Opção inválida!*\n\nEscolha de 1 a ${OPCOES_INVESTIMENTO.length}`
        }, { quoted: msg });
      }

      const opcao = OPCOES_INVESTIMENTO[numeroOpcao - 1];

      if (isNaN(valorInvestir) || valorInvestir < opcao.valorMin || valorInvestir > opcao.valorMax) {
        return sock.sendMessage(idChat, {
          text: `❌ *Valor inválido!*\n\n${opcao.nome}\nInvestimento: ${opcao.valorMin} a ${opcao.valorMax} moedas`
        }, { quoted: msg });
      }

      if (dadosUser.saldo < valorInvestir) {
        return sock.sendMessage(idChat, {
          text: `❌ *Saldo insuficiente!*\n\nVocê tem: ${dadosUser.saldo} moedas\nPrecisa de: ${valorInvestir} moedas`
        }, { quoted: msg });
      }

      // 💾 Deduz e registra investimento
      alterarSaldo(remetente, -valorInvestir);
      dadosUser.investimentosPendentes.push({
        opcao,
        valor: valorInvestir,
        investidoEm: agora,
        retornoEm: agora + TEMPO_RETORNO
      });

      const dados = JSON.parse(fs.readFileSync(CAMINHO_RPG, "utf-8"));
      dados[remetente] = dadosUser;
      salvarDados(dados);

      return sock.sendMessage(idChat, {
        text: `✅ *INVESTIMENTO REALIZADO!* ✅

🏢 Ramo: ${opcao.nome}
💸 Valor: ${valorInvestir} moedas
⏰ Retorno em: 4 horas

> Volte depois para ver o resultado! 📊`
      }, { quoted: msg });
    }
  }
};

