const config = require("../config.js");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const API_KEY_BRONXYS = config.API_KEY_BRONXYS || ""; // ✅ Linha mágica!
// ==============================================
// 📂 CAMINHOS DOS ARQUIVOS
// ==============================================
const CAMINHO_VIPS     = path.join(__dirname, "..", "dados", "vips.json");
const CAMINHO_ANOTACOES = path.join(__dirname, "..", "dados", "anotacoes.json");
const CAMINHO_PERFIL   = path.join(__dirname, "..", "dados", "perfil.json");
const CAMINHO_IDADES   = path.join(__dirname, "..", "dados", "idades.json");
const CAMINHO_ANIVERS   = path.join(__dirname, "..", "dados", "aniversarios.json");
const CAMINHO_LEMBRETES = path.join(__dirname, "..", "dados", "lembretes.json");
const CAMINHO_CMDS_VIP  = path.join(__dirname, "..", "dados", "vip_cmds.json");

// ==============================================
// ✅ FUNÇÕES BASE
// ==============================================
function garantirPasta(caminho) {
  const pasta = path.dirname(caminho);
  if (!fs.existsSync(pasta)) fs.mkdirSync(pasta, { recursive: true });
  if (!fs.existsSync(caminho)) fs.writeFileSync(caminho, "{}");
}
function carregarJson(caminho) {
  garantirPasta(caminho);
  try { return JSON.parse(fs.readFileSync(caminho, "utf-8")); }
  catch { return {}; }
}
function salvarJson(caminho, dados) {
  fs.writeFileSync(caminho, JSON.stringify(dados, null, 2));
}
function ehDono(idUsuario) {
  if (!idUsuario) return false;
  return String(idUsuario).replace(/\D/g, "") === String(config.numeroDono).replace(/\D/g, "");
}
function carregarVips() { return carregarJson(CAMINHO_VIPS); }
function ehVip(idUsuario) {
  if (!idUsuario) return false;
  const idLimpo = String(idUsuario).replace(/\D/g, "");
  if (ehDono(idUsuario)) return true;
  const vips = carregarVips();
  for (const [id, info] of Object.entries(vips)) {
    if (String(id).replace(/\D/g, "") === idLimpo) {
      if (!info.fim || info.fim > Date.now()) return true;
    }
  }
  return false;
}
function pegarNumero(id) { return String(id || "").split("@")[0].replace(/\D/g, ""); }
function parseTempo(str) {
  const m = str.match(/^(\d+)([mhd])$/i);
  if (!m) return null;
  const n = parseInt(m[1]);
  return m[2]==="m" ? n*60000 : m[2]==="h" ? n*3600000 : n*86400000;
}
function formatarTempo(ms) {
  if (!ms) return "♾️ Vitalício";
  if (ms <= Date.now()) return "⚠️ Vencido";
  const r = ms - Date.now();
  return `${Math.floor(r/86400000)}d ${Math.floor((r%86400000)/3600000)}h restantes`;
}

// ==============================================
// 📊 DDD / DDI
// ==============================================
const DDD = {
  "11":"SP","12":"SP","13":"SP","14":"SP","15":"SP","16":"SP","17":"SP","18":"SP","19":"SP",
  "21":"RJ","22":"RJ","24":"RJ","27":"ES","28":"ES","31":"MG","32":"MG","33":"MG","34":"MG",
  "35":"MG","37":"MG","38":"MG","41":"PR","42":"PR","43":"PR","44":"PR","45":"PR","46":"PR",
  "47":"SC","48":"SC","49":"SC","51":"RS","53":"RS","54":"RS","55":"RS","61":"DF","62":"GO",
  "63":"TO","64":"GO","65":"MT","66":"MT","67":"MS","68":"AC","69":"RO","71":"BA","73":"BA",
  "74":"BA","75":"BA","77":"BA","79":"SE","81":"PE","82":"AL","83":"PB","84":"RN","85":"CE",
  "86":"PI","87":"PE","88":"CE","89":"PI","91":"PA","92":"AM","93":"PA","94":"PA","95":"RR",
  "96":"AP","97":"AM","98":"MA","99":"MA"
};
const DDI = {
  // 🌎 AMÉRICA DO SUL
  "55": "🇧🇷 Brasil",
  "54": "🇦🇷 Argentina",
  "56": "🇨🇱 Chile",
  "57": "🇨🇴 Colômbia",
  "58": "🇻🇪 Venezuela",
  "51": "🇵🇪 Peru",
  "591": "🇧🇴 Bolívia",
  "595": "🇵🇾 Paraguai",
  "598": "🇺🇾 Uruguai",
  "593": "🇪🇨 Equador",
  "592": "🇬🇾 Guiana",
  "597": "🇸🇷 Suriname",
  "594": "🇬🇫 Guiana Francesa",

  // 🌎 AMÉRICA DO NORTE
  "1": "🇺🇸🇨🇦 EUA/Canadá",
  "52": "🇲🇽 México",
  "502": "🇬🇹 Guatemala",
  "503": "🇸🇻 El Salvador",
  "504": "🇭🇳 Honduras",
  "505": "🇳🇮 Nicarágua",
  "506": "🇨🇷 Costa Rica",
  "507": "🇵🇦 Panamá",
  "509": "🇭🇹 Haiti",
  "53": "🇨🇺 Cuba",
  "501": "🇧🇿 Belize",

  // 🌎 CARIBE
  "1-242": "🇧🇸 Bahamas",
  "1-246": "🇧🇧 Barbados",
  "1-264": "🇦🇮 Anguilla",
  "1-268": "🇦🇬 Antígua e Barbuda",
  "1-284": "🇻🇬 Ilhas Virgens Britânicas",
  "1-340": "🇻🇮 Ilhas Virgens Americanas",
  "1-441": "🇧🇲 Bermudas",
  "1-649": "🇹🇨 Ilhas Turks e Caicos",
  "1-664": "🇲🇸 Montserrat",
  "1-670": "🇲🇵 Ilhas Marianas do Norte",
  "1-671": "🇬🇺 Guam",
  "1-684": "🇦🇸 Samoa Americana",
  "1-721": "🇸🇽 Sint Maarten",
  "1-758": "🇱🇨 Santa Lúcia",
  "1-767": "🇩🇲 Dominica",
  "1-784": "🇻🇨 São Vicente e Granadinas",
  "1-787": "🇵🇷 Porto Rico",
  "1-809": "🇩🇴 República Dominicana",
  "1-829": "🇩🇴 República Dominicana",
  "1-849": "🇩🇴 República Dominicana",
  "1-868": "🇹🇹 Trinidad e Tobago",
  "1-876": "🇯🇲 Jamaica",

  // 🌍 EUROPA
  "351": "🇵🇹 Portugal",
  "34": "🇪🇸 Espanha",
  "33": "🇫🇷 França",
  "39": "🇮🇹 Itália",
  "49": "🇩🇪 Alemanha",
  "44": "🇬🇧 Reino Unido",
  "353": "🇮🇪 Irlanda",
  "31": "🇳🇱 Países Baixos",
  "32": "🇧🇪 Bélgica",
  "41": "🇨🇭 Suíça",
  "43": "🇦🇹 Áustria",
  "45": "🇩🇰 Dinamarca",
  "46": "🇸🇪 Suécia",
  "47": "🇳🇴 Noruega",
  "358": "🇫🇮 Finlândia",
  "354": "🇮🇸 Islândia",
  "30": "🇬🇷 Grécia",
  "7": "🇷🇺 Rússia/Cazaquistão",
  "48": "🇵🇱 Polônia",
  "40": "🇷🇴 Romênia",
  "380": "🇺🇦 Ucrânia",
  "420": "🇨🇿 República Tcheca",
  "421": "🇸🇰 Eslováquia",
  "36": "🇭🇺 Hungria",
  "359": "🇧🇬 Bulgária",
  "385": "🇭🇷 Croácia",
  "386": "🇸🇮 Eslovênia",
  "381": "🇷🇸 Sérvia",
  "382": "🇲🇪 Montenegro",
  "389": "🇲🇰 Macedônia do Norte",
  "387": "🇧🇦 Bósnia e Herzegovina",
  "355": "🇦🇱 Albânia",
  "375": "🇧🇾 Belarus",
  "370": "🇱🇹 Lituânia",
  "371": "🇱🇻 Letônia",
  "372": "🇪🇪 Estônia",
  "352": "🇱🇺 Luxemburgo",
  "356": "🇲🇹 Malta",
  "357": "🇨🇾 Chipre",
  "377": "🇲🇨 Mônaco",
  "378": "🇸🇲 San Marino",
  "379": "🇻🇦 Vaticano",
  "423": "🇱🇮 Liechtenstein",
  "376": "🇦🇩 Andorra",
  "350": "🇬🇮 Gibraltar",
  "298": "🇫🇴 Ilhas Faroé",
  "299": "🇬🇱 Groenlândia",

  // 🌏 ÁSIA
  "81": "🇯🇵 Japão",
  "86": "🇨🇳 China",
  "82": "🇰🇷 Coreia do Sul",
  "91": "🇮🇳 Índia",
  "92": "🇵🇰 Paquistão",
  "93": "🇦🇫 Afeganistão",
  "94": "🇱🇰 Sri Lanka",
  "95": "🇲🇲 Myanmar",
  "98": "🇮🇷 Irã",
  "964": "🇮🇶 Iraque",
  "972": "🇮🇱 Israel",
  "970": "🇵🇸 Palestina",
  "971": "🇦🇪 Emirados Árabes Unidos",
  "972": "🇮🇱 Israel",
  "973": "🇧🇭 Bahrein",
  "974": "🇶🇦 Catar",
  "975": "🇧🇹 Butão",
  "976": "🇲🇳 Mongólia",
  "977": "🇳🇵 Nepal",
  "966": "🇸🇦 Arábia Saudita",
  "965": "🇰🇼 Kuwait",
  "968": "🇴🇲 Omã",
  "967": "🇾🇪 Iêmen",
  "960": "🇲🇻 Maldivas",
  "961": "🇱🇧 Líbano",
  "962": "🇯🇴 Jordânia",
  "963": "🇸🇾 Síria",
  "90": "🇹🇷 Turquia",
  "66": "🇹🇭 Tailândia",
  "84": "🇻🇳 Vietnã",
  "60": "🇲🇾 Malásia",
  "65": "🇸🇬 Singapura",
  "62": "🇮🇩 Indonésia",
  "63": "🇵🇭 Filipinas",
  "64": "🇳🇿 Nova Zelândia",
  "92": "🇵🇰 Paquistão",
  "880": "🇧🇩 Bangladesh",
  "850": "🇰🇵 Coreia do Norte",
  "855": "🇰🇭 Camboja",
  "856": "🇱🇦 Laos",
  "673": "🇧🇳 Brunei",
  "670": "🇹🇱 Timor-Leste",
  "886": "🇹🇼 Taiwan",

  // 🌍 ÁFRICA
  "20": "🇪🇬 Egito",
  "27": "🇿🇦 África do Sul",
  "212": "🇲🇦 Marrocos",
  "213": "🇩🇿 Argélia",
  "216": "🇹🇳 Tunísia",
  "218": "🇱🇾 Líbia",
  "220": "🇬🇲 Gâmbia",
  "221": "🇸🇳 Senegal",
  "222": "🇲🇷 Mauritânia",
  "223": "🇲🇱 Mali",
  "224": "🇬🇳 Guiné",
  "225": "🇨🇮 Costa do Marfim",
  "226": "🇧🇫 Burkina Faso",
  "227": "🇳🇪 Níger",
  "228": "🇹🇬 Togo",
  "229": "🇧🇯 Benim",
  "230": "🇲🇺 Maurício",
  "231": "🇱🇷 Libéria",
  "232": "🇸🇱 Serra Leoa",
  "233": "🇬🇭 Gana",
  "234": "🇳🇬 Nigéria",
  "235": "🇹🇩 Chade",
  "236": "🇨🇫 República Centro-Africana",
  "237": "🇨🇲 Camarões",
  "238": "🇨🇻 Cabo Verde",
  "239": "🇸🇹 São Tomé e Príncipe",
  "240": "🇬🇶 Guiné Equatorial",
  "241": "🇬🇦 Gabão",
  "242": "🇨🇬 Congo",
  "243": "🇨🇩 RD Congo",
  "244": "🇦🇴 Angola",
  "245": "🇬🇼 Guiné-Bissau",
  "246": "🇮🇴 Território Britânico do Oceano Índico",
  "248": "🇸🇨 Seychelles",
  "249": "🇸🇩 Sudão",
  "250": "🇷🇼 Ruanda",
  "251": "🇪🇹 Etiópia",
  "252": "🇸🇴 Somália",
  "253": "🇩🇯 Djibuti",
  "254": "🇰🇪 Quênia",
  "255": "🇹🇿 Tanzânia",
  "256": "🇺🇬 Uganda",
  "257": "🇧🇮 Burundi",
  "258": "🇲🇿 Moçambique",
  "260": "🇿🇲 Zâmbia",
  "261": "🇲🇬 Madagascar",
  "262": "🇷🇪 Reunião",
  "263": "🇿🇼 Zimbábue",
  "264": "🇳🇦 Namíbia",
  "265": "🇲🇼 Malawi",
  "266": "🇱🇸 Lesoto",
  "267": "🇧🇼 Botsuana",
  "268": "🇸🇿 Eswatini",
  "269": "🇰🇲 Comores",
  "290": "🇸🇭 Santa Helena",
  "291": "🇪🇷 Eritreia",
  "297": "🇦🇼 Aruba",
  "298": "🇫🇴 Ilhas Faroé",
  "299": "🇬🇱 Groenlândia",

  // 🌊 OCEANIA
  "61": "🇦🇺 Austrália",
  "64": "🇳🇿 Nova Zelândia",
  "679": "🇫🇯 Fiji",
  "675": "🇵🇬 Papua-Nova Guiné",
  "676": "🇹🇴 Tonga",
  "677": "🇸🇧 Ilhas Salomão",
  "678": "🇻🇺 Vanuatu",
  "680": "🇵🇼 Palau",
  "681": "🇼🇫 Wallis e Futuna",
  "682": "🇨🇰 Ilhas Cook",
  "683": "🇳🇺 Niue",
  "685": "🇼🇸 Samoa",
  "686": "🇰🇮 Kiribati",
  "687": "🇳🇨 Nova Caledônia",
  "688": "🇹🇻 Tuvalu",
  "689": "🇵🇫 Polinésia Francesa",
  "690": "🇹🇰 Tokelau",
  "691": "🇫🇲 Micronésia",
  "692": "🇲🇭 Ilhas Marshall"
};
// ==============================================
// 🚀 TODOS OS COMANDOS
// ==============================================
module.exports = {
  nome: "sistema_completo",
  comandos: {

    // ==============================================
    // 💎 VIP — FERRAMENTAS
    // ==============================================
    info_ddd: async (sock, msg, args, dados) => {
      if (!ehVip(dados.remetente)) return sock.sendMessage(dados.idChat, {text:"💎 Apenas VIP! Use !vip ✨"});
      const num = args[0] || pegarNumero(dados.remetente);
      const d = num.replace(/^55/,"").slice(0,2);
      return sock.sendMessage(dados.idChat, {text:`📞 DDD ${d}: ${DDD[d]||"Não encontrado"}`});
    },

    info_ddi: async (sock, msg, args, dados) => {
      if (!ehVip(dados.remetente)) return sock.sendMessage(dados.idChat, {text:"💎 Apenas VIP! Use !vip ✨"});
      const num = args[0] || pegarNumero(dados.remetente);
      let ddi = num.match(/^(55|351|44|33|49|81|86|52|54)/)?.[1] || "??";
      return sock.sendMessage(dados.idChat, {text:`🌍 DDI ${ddi}: ${DDI[ddi]||"Desconhecido"}`});
    },

    get_perfil: async (sock, msg, args, dados) => {
      if (!ehVip(dados.remetente)) return sock.sendMessage(dados.idChat, {text:"💎 Apenas VIP! ✨"});
      const alvo = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || `${args[0]||dados.remetente}@s.whatsapp.net`;
      const num = pegarNumero(alvo);
      const perfil = carregarJson(CAMINHO_PERFIL)[num] || {nome:"Desconhecido",bio:"Sem bio",aura:"---"};
      return sock.sendMessage(dados.idChat, {text:`👤 PERFIL\nNome: ${perfil.nome}\nBio: ${perfil.bio}\nAura: ${perfil.aura}`});
    },

    wawe: async (sock, msg, args, dados) => {
      if (!ehVip(dados.remetente)) return sock.sendMessage(dados.idChat, {text:"💎 Apenas VIP! ✨"});
      const num = pegarNumero(dados.remetente);
      return sock.sendMessage(dados.idChat, {text:`📱 WA-WE\nwa.me/${num}`});
    },

    getperfil: async (sock, msg, args, dados) => {
      if (!ehVip(dados.remetente)) return;
      const alvo = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || `${args[0]}@s.whatsapp.net`;
      const num = pegarNumero(alvo);
      return sock.sendMessage(dados.idChat, {text:`👤 @${num}`, mentions:[alvo]});
    },

    getbio: async (sock, msg, args, dados) => {
      if (!ehVip(dados.remetente)) return;
      const alvo = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || `${args[0]}@s.whatsapp.net`;
      const num = pegarNumero(alvo);
      const bio = carregarJson(CAMINHO_PERFIL)[num]?.bio || "Sem bio 📝";
      return sock.sendMessage(dados.idChat, {text:`📝 Bio de @${num}:\n${bio}`, mentions:[alvo]});
    },

    nick: async (sock, msg, args, dados) => {
      if (!ehVip(dados.remetente)) return;
      const alvo = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
      if (!alvo) return sock.sendMessage(dados.idChat, {text:"Uso: !nick @usuario"});
      const num = pegarNumero(alvo);
      const novoNick = args.slice(1).join(" ");
      const perfis = carregarJson(CAMINHO_PERFIL);
      perfis[num] = { ...perfis[num], nome:novoNick };
      salvarJson(CAMINHO_PERFIL, perfis);
      return sock.sendMessage(dados.idChat, {text:`✅ Nick de @${num} alterado!`, mentions:[alvo]});
    },

// ==============================================
 // 🤖 IA — Gemini / GPT (API Bronxys)
 // ==============================================
 gemini: async (sock, msg, args, dados) => {
   if (!ehVip(dados.remetente)) 
     return sock.sendMessage(dados.idChat, { text: "💎 Apenas VIP! Use !vip ✨" });
   
   const pergunta = args.join(" ");
   if (!pergunta) 
     return sock.sendMessage(dados.idChat, { text: "Faça sua pergunta:\n!gemini o que é inteligência artificial?" });
   const idChat = dados.idChat;
   
   // ⏳ Mensagem de espera
   await sock.sendMessage(idChat, { text: "🔮 *Aguarde...* Estou pesquisando sua pergunta!" });
   try {
     const apiKey = config.API_KEY_BRONXYS;
     const url = `https://api.bronxyshost.com.br/api-bronxys/PERGUNTE_E_EU_RESPONDO?q=${encodeURIComponent(pergunta)}&apikey=${apiKey}`;
     
     const resposta = await axios.get(url, { timeout: 30000 });
     const resultado = resposta.data?.msg || resposta.data || "Sem resposta da API";
     return sock.sendMessage(idChat, {
       text: `🔮 *GEMINI* 🤖\n\n❓ Pergunta: ${pergunta}\n💬 Resposta:\n${resultado}`
     });
   } catch (erro) {
     console.log("❌ Erro Gemini:", erro.response?.data || erro.message);
     return sock.sendMessage(idChat, {
       text: `⚠️ *Erro ao consultar!*\nVerifique sua API Key ou tente novamente mais tarde.`
     });
   }
 },

// 🤖 GPT / PERGUNTA
 gpt: {
   nome: "gpt",
   alternativos: ["chatgpt", "openai", "pergunta"],
   executar: async (sock, msg, args) => {
     const idChat = msg.key.remoteJid;
     const pergunta = args.join(" ").trim();
     if (!pergunta) {
       return sock.sendMessage(idChat, {
         text: `💬 *USO:* ${PREFIXO}gpt <pergunta>\n🩸 *Ex:* ${PREFIXO}gpt como fazer café?`,
         quoted: msg
       });
     }
     try {
       await sock.sendMessage(idChat, { text: "⏳ Aguarde, estou pensando... 🩸", quoted: msg });
       const { data } = await axios.get(
         `https://api.bronxyshost.com.br/api-bronxys/PERGUNTE_E_EU_RESPONDO?q=${encodeURIComponent(pergunta)}&apikey=${API_KEY_BRONXYS}`,
         { timeout: 30000 }
       );
       await sock.sendMessage(idChat, {
         text: `🤖 *RESPOSTA:*\n\n${data.msg || data.resposta || "Nenhuma resposta encontrada."}`,
         quoted: msg
       });
     } catch (erro) {
       console.log("❌ ERRO GPT:", erro.response?.data || erro.message);
       await sock.sendMessage(idChat, { text: "❌ Erro ao consultar a IA. 🩸", quoted: msg });
     }
   }
 },
    // 📝 ANOTAÇÕES
    // ==============================================
    anotar: async (sock, msg, args, dados) => {
      const num = pegarNumero(dados.remetente);
      const texto = args.join(" ");
      if (!texto) return sock.sendMessage(dados.idChat, {text:"Uso: !anotar minha anotação"});
      const anots = carregarJson(CAMINHO_ANOTACOES);
      if (!anots[num]) anots[num] = [];
      anots[num].push({texto, data: new Date().toLocaleString("pt-BR")});
      salvarJson(CAMINHO_ANOTACOES, anots);
      return sock.sendMessage(dados.idChat, {text:"✅ Anotado!"});
    },

    anotações: async (sock, msg, args, dados) => {
      const num = pegarNumero(dados.remetente);
      const anots = carregarJson(CAMINHO_ANOTACOES)[num] || [];
      if (!anots.length) return sock.sendMessage(dados.idChat, {text:"📝 Nenhuma anotação!"});
      let txt = "📝 SUAS ANOTAÇÕES:\n\n";
      anots.forEach((a,i) => txt += `${i+1}. ${a.texto}\n📅 ${a.data}\n\n`);
      return sock.sendMessage(dados.idChat, {text:txt.trim()});
    },

    rm_anotação: async (sock, msg, args, dados) => {
      const num = pegarNumero(dados.remetente);
      const indice = parseInt(args[0]) - 1;
      const anots = carregarJson(CAMINHO_ANOTACOES);
      if (!anots[num] || !anots[num][indice]) return sock.sendMessage(dados.idChat, {text:"⚠️ Anotação não encontrada!"});
      anots[num].splice(indice,1);
      salvarJson(CAMINHO_ANOTACOES, anots);
      return sock.sendMessage(dados.idChat, {text:"🗑️ Removida!"});
    },

    // ==============================================
    // 💪 AURA — Sigma / Beta
    // ==============================================
    aura: async (sock, msg, args, dados) => {
      const alvo = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || dados.remetente;
      const num = pegarNumero(alvo);
      const rnd = Math.random();
      let tipo, emoji;
      if (rnd < 0.10) { tipo = "SIGMA SUPREMO"; emoji = "👑"; }
      else if (rnd < 0.30) { tipo = "SIGMA"; emoji = "💪"; }
      else if (rnd < 0.60) { tipo = "BETA"; emoji = "😐"; }
      else { tipo = "BETINHA"; emoji = "🐣"; }
      const perfis = carregarJson(CAMINHO_PERFIL);
      perfis[num] = { ...perfis[num], aura:tipo };
      salvarJson(CAMINHO_PERFIL, perfis);
      return sock.sendMessage(dados.idChat, {text:`${emoji} AURA DE @${num}:\n\n${tipo}`, mentions:[alvo]});
    },

    // ==============================================
    // 🎂 IDADE
    // ==============================================
    idade: async (sock, msg, args, dados) => {
      const entrada = args[0];
      const anoAtual = new Date().getFullYear();
      if (!entrada) {
        const num = pegarNumero(dados.remetente);
        const nasc = carregarJson(CAMINHO_IDADES)[num]?.nascimento;
        if (!nasc) return sock.sendMessage(dados.idChat, {text:"Uso: !idade 1999 → mostra quantos anos tem\n!idade 13 → mostra em que ano nasceu"});
        const idade = anoAtual - nasc;
        return sock.sendMessage(dados.idChat, {text:`🎂 Você nasceu em ${nasc} → ${idade} anos!`});
      }
      if (entrada.length <= 2) {
        const anoNasc = anoAtual - parseInt(entrada);
        return sock.sendMessage(dados.idChat, {text:`🎂 ${entrada} anos → Nasceu em ${anoNasc}`});
      } else {
        const idade = anoAtual - parseInt(entrada);
        const idades = carregarJson(CAMINHO_IDADES);
        idades[pegarNumero(dados.remetente)] = { nascimento:parseInt(entrada) };
        salvarJson(CAMINHO_IDADES, idades);
        return sock.sendMessage(dados.idChat, {text:`🎂 Ano ${entrada} → ${idade} anos! ✅ Salvo!`});
      }
    },

    // ==============================================
    // 🎉 ANIVERSÁRIO
    // ==============================================
    definir_aniversário: async (sock, msg, args, dados) => {
      const num = pegarNumero(dados.remetente);
      const [data, hora] = args.join(" ").split(" ");
      if (!data) return sock.sendMessage(dados.idChat, {text:"Uso: !definir_aniversário 01/01/2001 20:30"});
      const anivers = carregarJson(CAMINHO_ANIVERS);
      anivers[num] = { data, hora, nome:msg.pushName || "Usuário" };
      salvarJson(CAMINHO_ANIVERS, anivers);
      return sock.sendMessage(dados.idChat, {text:`✅ Aniversário salvo: ${data} às ${hora}! 🎉`});
    },

    aniversário: async (sock, msg, args, dados) => {
      const num = pegarNumero(dados.remetente);
      const a = carregarJson(CAMINHO_ANIVERS)[num];
      if (!a) return sock.sendMessage(dados.idChat, {text:"⚠️ Nenhum aniversário salvo! Use !definir_aniversário"});
      return sock.sendMessage(dados.idChat, {text:`🎉 Seu aniversário:\n📅 ${a.data}\n⏰ ${a.hora}`});
    },

    rm_aniversário: async (sock, msg, args, dados) => {
      const num = pegarNumero(dados.remetente);
      const anivers = carregarJson(CAMINHO_ANIVERS);
      delete anivers[num];
      salvarJson(CAMINHO_ANIVERS, anivers);
      return sock.sendMessage(dados.idChat, {text:"🗑️ Aniversário removido!"});
    },

    // ==============================================
    // ⏰ LEMBRETE
    // ==============================================
    Lembrete: async (sock, msg, args, dados) => {
      const num = pegarNumero(dados.remetente);
      const tempo = args[0];
      const texto = args.slice(1).join(" ");
      if (!tempo || !texto) return sock.sendMessage(dados.idChat, {text:"Uso: !Lembrete 00:00 mensagem"});
      const lems = carregarJson(CAMINHO_LEMBRETES);
      lems[num] = { tempo, texto, criado: new Date().toLocaleString("pt-BR") };
      salvarJson(CAMINHO_LEMBRETES, lems);
      return sock.sendMessage(dados.idChat, {text:`⏰ Lembrete definido para ${tempo}!\n📝 ${texto}`});
    },

    // ==============================================
    // 👑 ADMIN VIP — Só Dono
    // ==============================================
    addvip: async (sock, msg, args, dados) => {
      if (!ehDono(dados.remetente)) return;
      const alvo = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || `${args[0]}@s.whatsapp.net`;
      const tempoStr = args[1] || "30d";
      const ms = parseTempo(tempoStr);
      if (!ms && !tempoStr.startsWith("vital")) return sock.sendMessage(dados.idChat, {text:"Uso: !addvip @user 1d / 1h / 1m / vitalicio"});
      const vips = carregarVips();
      vips[alvo] = { nome:msg.pushName, adicionado:Date.now(), fim:tempoStr.startsWith("vital")?null:Date.now()+ms };
      salvarJson(CAMINHO_VIPS, vips);
      return sock.sendMessage(dados.idChat, {text:`✅ VIP ADICIONADO!\n👤 @${pegarNumero(alvo)}\n⏳ ${tempoStr}`, mentions:[alvo]});
    },

    rmvip: async (sock, msg, args, dados) => {
      if (!ehDono(dados.remetente)) return;
      const alvo = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || `${args[0]}@s.whatsapp.net`;
      const vips = carregarVips();
      delete vips[alvo];
      salvarJson(CAMINHO_VIPS, vips);
      return sock.sendMessage(dados.idChat, {text:`❌ REMOVIDO: @${pegarNumero(alvo)}`, mentions:[alvo]});
    },

    addvipcmd: async (sock, msg, args, dados) => {
      if (!ehDono(dados.remetente)) return;
      const cmd = args[0]?.toLowerCase();
      if (!cmd) return sock.sendMessage(dados.idChat, {text:"Uso: !addvipcmd nome"});
      const cmds = carregarJson(CAMINHO_CMDS_VIP);
      cmds[cmd] = {bloqueado:false};
      salvarJson(CAMINHO_CMDS_VIP, cmds);
      return sock.sendMessage(dados.idChat, {text:`✅ Comando VIP "${cmd}" adicionado!`});
    },

    delvipcmd: async (sock, msg, args, dados) => {
      if (!ehDono(dados.remetente)) return;
      const cmd = args[0]?.toLowerCase();
      const cmds = carregarJson(CAMINHO_CMDS_VIP);
      delete cmds[cmd];
      salvarJson(CAMINHO_CMDS_VIP, cmds);
      return sock.sendMessage(dados.idChat, {text:`🗑️ Removido: ${cmd}`});
    },

    listacmdvip: async (sock, msg, args, dados) => {
      if (!ehDono(dados.remetente)) return;
      const cmds = carregarJson(CAMINHO_CMDS_VIP);
      let txt = "📋 COMANDOS VIP:\n\n";
      if (!Object.keys(cmds).length) txt += "Nenhum cadastrado!";
      else for (const [c,i] of Object.entries(cmds)) txt += `${i.bloqueado?"🚫":"✅"} ${c}\n`;
      return sock.sendMessage(dados.idChat, {text:txt.trim()});
    },

    blockcmdvip: async (sock, msg, args, dados) => {
      if (!ehDono(dados.remetente)) return;
      const cmd = args[0]?.toLowerCase();
      const cmds = carregarJson(CAMINHO_CMDS_VIP);
      if (!cmds[cmd]) return sock.sendMessage(dados.idChat, {text:"⚠️ Não encontrado!"});
      cmds[cmd].bloqueado = !cmds[cmd].bloqueado;
      salvarJson(CAMINHO_CMDS_VIP, cmds);
      return sock.sendMessage(dados.idChat, {text:`${cmds[cmd].bloqueado?"🚫 Bloqueado":"✅ Desbloqueado"}: ${cmd}`});
    }
  }
};

