const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const PREFIXO = config.prefixo || "!";
const NOME_BOT = config.nomeBot || "MoonBot-MDv1";

// 📁 Caminhos
const PASTA_DADOS = path.join(__dirname, "..", "dados");
const CAMINHO_EMPREGO = path.join(PASTA_DADOS, "empregos_usuarios.json");
const CAMINHO_RPG = path.join(PASTA_DADOS, "rpg_jogadores.json");

// ✅ Garante pasta e arquivos
if (!fs.existsSync(PASTA_DADOS)) fs.mkdirSync(PASTA_DADOS, { recursive: true });
if (!fs.existsSync(CAMINHO_EMPREGO)) fs.writeFileSync(CAMINHO_EMPREGO, "{}");

// ==========================================
// 🏢 50 EMPREGOS — com nome, salário, emoji e imagem
// ==========================================
const EMPREGOS = [
  { id: 20, nome: "Bibliotecário", salario: 210, emoji: "📚", imagem: "https://i.ibb.co/ksLkvRSX/800c803110b7ec4d2a7115bd4638aebb-1.jpg" },     { id: 21, nome: "Professor", salario: 220, emoji: "👨‍🏫", imagem: "https://i.ibb.co/27xyXRZf/4795030cb1c0f6c7f975556705c31093-1.jpg" },
  { id: 22, nome: "Escritor", salario: 230, emoji: "✍️", imagem: "https://i.ibb.co/j90DV6Kh/cc7b8ea755144235b5d6a60ff3f6bc47.jpg" },
  { id: 23, nome: "Artista", salario: 240, emoji: "🎭", imagem: "https://i.ibb.co/qMQJDswc/a3a24c8e004a4d06fa2388c65ba3a9a6.jpg" },
  { id: 24, nome: "Músico", salario: 250, emoji: "🎸", imagem: "https://i.ibb.co/fdFd9bSF/2b1ab36d500a2efd9832cc8b3de17fd6.jpg" },
  { id: 25, nome: "Fotógrafo", salario: 260, emoji: "📷", imagem: "https://i.ibb.co/zTXF1hRY/ddd0588e1003dea9fc2437a5ae78babb.jpg" },           { id: 26, nome: "Designer", salario: 270, emoji: "💻", imagem: "https://i.ibb.co/HTXvXXDb/6907fa0f7d752f82a8f5837ff0c4ca12-1.jpg" },
  { id: 27, nome: "Programador", salario: 300, emoji: "👨‍💻", imagem: "https://i.ibb.co/nqmGm0PN/ebdb2c8c85976fe92bafd662ed574711.jpg" },
  { id: 28, nome: "Médico", salario: 350, emoji: "👨‍⚕️", imagem: "https://i.ibb.co/B5vgcWtk/11aa6512d38b2f8c39c1c87a561c27dd.jpg" },
  { id: 29, nome: "Enfermeiro", salario: 320, emoji: "💉", imagem: "https://i.ibb.co/Gfdr4DSq/274ede44bc1317eeea56115c2a53aa3f.jpg" },
  { id: 30, nome: "Dentista", salario: 380, emoji: "🦷", imagem: "https://i.ibb.co/5g5B7MKN/bd88bf1d61bc46f51dabe58515706b21.jpg" },
  { id: 31, nome: "Advogado", salario: 400, emoji: "⚖️", imagem: "https://i.ibb.co/4nMbdTmX/9bde6aa0f3b154a20b393df1f13fca3a.jpg" },
  { id: 32, nome: "Contador", salario: 360, emoji: "🧮", imagem: "https://i.ibb.co/C5GqZB1S/70735f7c4d07f7762a0321d6581d9793.jpg" },
  { id: 33, nome: "Empresário", salario: 450, emoji: "💼", imagem: "https://i.ibb.co/rK7CxHtT/9ed645b1c1c4adc28ea593e290a06083-1.jpg" },
  { id: 34, nome: "Gerente", salario: 420, emoji: "📊", imagem: "https://i.ibb.co/0VsgMmxV/ea60fcbbc1b638319d30b65d70ab8f91.jpg" },
  { id: 35, nome: "Chef de Cozinha", salario: 340, emoji: "🍳", imagem: "https://i.ibb.co/6RJmHxj7/e91735a699601794be920662b6f6714e.jpg" },
  { id: 36, nome: "Piloto", salario: 500, emoji: "✈️", imagem: "https://i.ibb.co/1G5TLS17/a0e27f5228a1ec628e8b64e27aad8403.jpg" },
  { id: 37, nome: "Comissário", salario: 380, emoji: "🛫", imagem: "https://i.ibb.co/zWGX5WH9/3de7085d96a89c899e544401be684b2f.jpg" },
  { id: 38, nome: "Astronauta", salario: 600, emoji: "👨‍🚀", imagem: "https://i.ibb.co/X6SnmJ8/acd9a53c3e78ff7799ecf0fc4b3c095f.jpg" },
  { id: 39, nome: "Cientista", salario: 480, emoji: "🔬", imagem: "https://i.ibb.co/992PY4Bt/b44411555aad16c359ca64ef47710ab6.jpg" },
  { id: 40, nome: "Químico", salario: 460, emoji: "🧪", imagem: "https://i.ibb.co/4nkQzJV5/8979e3238d329f41ec5b9204a2850f06.jpg" },
  { id: 41, nome: "Engenheiro", salario: 440, emoji: "🏗️", imagem: "https://i.ibb.co/DHvK3R6Y/477593fdb78a813aafccb3d1cedaa0df.jpg" },
  { id: 42, nome: "Arquiteto", salario: 430, emoji: "🏛️", imagem: "https://i.ibb.co/GvDMtzj9/269dfacea2dffa78b299da7ee976593a.jpg" },
  { id: 43, nome: "Juiz", salario: 520, emoji: "🏛️", imagem: "https://i.ibb.co/Cssb0d8h/02870cbecf3ecfe73f24b6523427b6a1.jpg" },
  { id: 44, nome: "clt", salario: 1000, emoji: "🔵", imagem: "https://i.ibb.co/5x2nBndf/c448d1ad04104dab14ff55f403d9bb49.jpg" },
];
// ⏱️ Tempo entre usos do comando: 2 HORAS
const TEMPO_ESPERA = 2 * 60 * 60 * 1000;

// ✅ Carrega e salva
function carregarJson(caminho, padrao = {}) {
  try {
    if (!fs.existsSync(caminho)) return padrao;
    return JSON.parse(fs.readFileSync(caminho, "utf-8"));
  } catch { return padrao; }
}
function salvarJson(caminho, dados) {
  fs.writeFileSync(caminho, JSON.stringify(dados, null, 2));
}

// ✅ Cria usuário se não existir
function criarUsuarioSeNaoExiste(idUsuario) {
  const dados = carregarJson(CAMINHO_EMPREGO);
  if (!dados[idUsuario]) {
    dados[idUsuario] = {
      saldo: 0,
      ultimoUso: 0,
      investimentos: 0
    };
    salvarJson(CAMINHO_EMPREGO, dados);
  }
  return dados[idUsuario];
}

// ✅ Formata tempo restante
function formatarTempo(ms) {
  if (ms <= 0) return "✅ Já disponível!";
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  if (h > 0) return `${h}h ${m}m`;
  return `${m} minutos`;
}

module.exports = {
  EMPREGOS,

  comandos: {

    // 🎲 !emprego — SORTEIA EMPREGO, GANHA DINHEIRO AUTOMÁTICO, A CADA 2H
    emprego: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const idUsuario = remetente.split("@")[0];
      const mencao = `@${idUsuario}`;

      criarUsuarioSeNaoExiste(idUsuario);
      const todos = carregarJson(CAMINHO_EMPREGO);
      const usuario = todos[idUsuario];

      // ⏰ Verifica se já pode usar
      const agora = Date.now();
      if (agora < usuario.ultimoUso + TEMPO_ESPERA) {
        const restante = formatarTempo(usuario.ultimoUso + TEMPO_ESPERA - agora);
        return await sock.sendMessage(idChat, {
          text: `⏳ ${mencao}, ainda não pode trabalhar!

Próximo emprego em: ${restante}`,
          mentions: [remetente]
        });
      }

      // 🎯 SORTEIA UM EMPREGO ALEATÓRIO
      const indiceAleatorio = Math.floor(Math.random() * EMPREGOS.length);
      const emprego = EMPREGOS[indiceAleatorio];

      // 💰 DINHEIRO CAI AUTOMATICAMENTE NO SALDO!
      usuario.saldo += emprego.salario;
      usuario.ultimoUso = agora;
      todos[idUsuario] = usuario;
      salvarJson(CAMINHO_EMPREGO, todos);

      // 🔄 Também adiciona no RPG
      const rpg = carregarJson(CAMINHO_RPG);
      if (rpg[idUsuario]) {
        rpg[idUsuario].moedas = (rpg[idUsuario].moedas || 0) + emprego.salario;
        salvarJson(CAMINHO_RPG, rpg);
      }

      // 📤 Mostra resultado
      await sock.sendMessage(idChat, {
        image: { url: emprego.imagem },
        caption: `🎲 ${mencao} conseguiu trabalho!

💼 *Emprego:* ${emprego.emoji} ${emprego.nome}
💰 *Ganhou:* +${emprego.salario} moedas de ouro
💵 *Saldo total:* ${usuario.saldo} moedas

⏰ Volte em 2 horas para trabalhar de novo! 🕒`,
        mentions: [remetente]
      });
    },

    // 💳 !saldo — Ver saldo
    saldo: async (sock, msg, args, dados) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;
      const idUsuario = remetente.split("@")[0];
      const mencao = `@${idUsuario}`;

      criarUsuarioSeNaoExiste(idUsuario);
      const todos = carregarJson(CAMINHO_EMPREGO);
      const usuario = todos[idUsuario];

      const agora = Date.now();
      const proximoEmprego = formatarTempo(Math.max(0, usuario.ultimoUso + TEMPO_ESPERA - agora));

      await sock.sendMessage(idChat, {
        text: `╭━━━━━━━━━━ 💳━━━━━━━━━━╮
┃
┃   👤 SALDO DE ${mencao}
┃
┃💵 Saldo: ${usuario.saldo} moedas de ouro
┃📈 Investimentos: ${usuario.investimentos} moedas
┃⏰ Próximo emprego: ${proximoEmprego}
┃
┃💡 Digite !emprego para trabalhar
╰━━━━━━━━━━ 💳━━━━━━━━━━╯`,
        mentions: [remetente]
      });
    }
  }
};

