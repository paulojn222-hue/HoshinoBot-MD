const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const PREFIXO = config.prefixo || "!";
const NOME_BOT = config.nomeBot || "SukunaBot-MD";
const DONO_PRINCIPAL = String(config.numeroDono).replace(/\D/g, "");

// 📂 Configurações
const CAMINHO_CFG_IA = path.join(__dirname, "..", "dados", "config_ia.json");

function garantirCfgIA() {
  const pasta = path.dirname(CAMINHO_CFG_IA);
  if (!fs.existsSync(pasta)) fs.mkdirSync(pasta, { recursive: true });
  if (!fs.existsSync(CAMINHO_CFG_IA)) {
    fs.writeFileSync(CAMINHO_CFG_IA, JSON.stringify({
      iaAtiva: true,
      nomeIA: NOME_BOT.toLowerCase(),
      responderSemNome: true
    }, null, 2));
  }
}
function carregarCfgIA() {
  garantirCfgIA();
  try { return JSON.parse(fs.readFileSync(CAMINHO_CFG_IA, "utf-8")); }
  catch { return { iaAtiva: true, nomeIA: NOME_BOT.toLowerCase(), responderSemNome: true }; }
}
function salvarCfgIA(dados) {
  fs.writeFileSync(CAMINHO_CFG_IA, JSON.stringify(dados, null, 2));
}
function ehDono(remetente) {
  const num = String(remetente).replace(/\D/g, "");
  return num === DONO_PRINCIPAL;
}

// 🧠 SISTEMA INTELIGENTE — +50 FRASES + TODOS OS COMANDOS!
function processarTexto(texto) {
  const t = texto.toLowerCase().trim();
  const hora = new Date().getHours();

  // ==========================================
  // 👋 SAUDAÇÕES (10 frases)
  // ==========================================
  if (/^(bom dia|dia bom|bom dia!)/i.test(t)) {
    return { tipo: "resposta", texto: "Bom dia! ☀️ Que dia lindo! E com você?" };
  }
  if (/^(boa tarde|tarde boa|boa tarde!)/i.test(t)) {
    return { tipo: "resposta", texto: "Boa tarde! 😊 Tudo bem por aí?" };
  }
  if (/^(boa noite|noite boa|boa noite!)/i.test(t)) {
    return { tipo: "resposta", texto: "Boa noite! 🌙 Descanse bem!" };
  }
  if (/^(oi|olá|ola|eae|opa|salve|iai|oi!|olá!)/i.test(t)) {
    return { tipo: "resposta", texto: "Olá! 😄 Tudo bem? Em que posso ajudar?" };
  }
  if (/^(tchau|adeus|até mais|fui|saindo|tchau!)/i.test(t)) {
    return { tipo: "resposta", texto: "Tchau! 👋 Volte sempre! Foi um prazer conversar com você!" };
  }
  if (/^(bom dia gente|bom dia turma)/i.test(t)) {
    return { tipo: "resposta", texto: "Bom dia a todos! ☀️✨ Que dia abençoado para nós!" };
  }
  if (/^(boa tarde turma|boa tarde gente)/i.test(t)) {
    return { tipo: "resposta", texto: "Boa tarde, turma! 😊☀️ Tudo bem com vocês?" };
  }
  if (/^(boa noite turma|boa noite gente)/i.test(t)) {
    return { tipo: "resposta", texto: "Boa noite, pessoal! 🌙✨ Descanse bem!" };
  }
  if (/^(ola|oiii|oii|oie)/i.test(t)) {
    return { tipo: "resposta", texto: "Oiii! 😍 Tudo bem? Como está você?" };
  }
  if (/^(eae|eai|iai|iai tudo bem)/i.test(t)) {
    return { tipo: "resposta", texto: "Eae! 👋 Tudo ótimo por aqui! E com você?" };
  }

  // ==========================================
  // 😊 PERGUNTAS DE CORTESIA (8 frases)
  // ==========================================
  if (/tudo bem|como vai|está bem|tudo bem\?|está bem\?|como está/i.test(t)) {
    return { tipo: "resposta", texto: "Tudo ótimo por aqui! 😄 E com você?" };
  }
  if (/qual seu nome|quem é você|seu nome|como você se chama/i.test(t)) {
    return { tipo: "resposta", texto: `Meu nome é ${NOME_BOT}! 🤖 Sou um bot criado para ajudar no grupo!` };
  }
  if (/quem te criou|seu criador|quem fez você/i.test(t)) {
    return { tipo: "resposta", texto: "Fui criado com muito carinho pelo Moon! 🌙✨" };
  }
  if (/quantos anos|sua idade|você tem quantos anos/i.test(t)) {
    return { tipo: "resposta", texto: "Sou um bot, não tenho idade! 🤖 Mas sou novinho em folha! 😄" };
  }
  if (/onde você mora|de onde é|você é da onde/i.test(t)) {
    return { tipo: "resposta", texto: "Moro na nuvem! ☁️ Mas estou aqui para ajudar você!" };
  }
  if (/você gosta de mim|você me ama|gosta de mim/i.test(t)) {
    return { tipo: "resposta", texto: "Claro que sim! 🥰 Você é muito especial para mim!" };
  }
  if (/obrigado|obrigada|valeu|vlw|muito obrigado/i.test(t)) {
    return { tipo: "resposta", texto: "De nada! 😊 Sempre às ordens!" };
  }
  if (/desculpa|desculpe|perdão|me perdoa/i.test(t)) {
    return { tipo: "resposta", texto: "Tudo bem! 😄 Não precisa pedir desculpas!" };
  }

  // ==========================================
  // 🔒 COMANDOS DE GRUPO (6 frases)
  // ==========================================
  if (/feche o grupo|fechar grupo|tranca o grupo|trancar grupo|bloquear grupo|fecha o grupo/i.test(t)) {
    return { tipo: "fechar_grupo", texto: "🔒 Fechando o grupo agora! Apenas admins podem falar!" };
  }
  if (/abra o grupo|abrir grupo|destranca o grupo|destrancar grupo|liberar grupo|abre o grupo/i.test(t)) {
    return { tipo: "abrir_grupo", texto: "🔓 Abrindo o grupo! Todos podem falar!" };
  }
  // ==========================================
  // ⚙️ INFORMAÇÕES DO BOT (5 frases)
  // ==========================================
  if (/estou te seguindo|seguir|quero seguir você/i.test(t)) {
    return { tipo: "resposta", texto: "Obrigado! 💜 Sempre estou aqui para ajudar!" };
  }
  if (/você está online|está funcionando|tudo bem com você/i.test(t)) {
    return { tipo: "resposta", texto: "Sim! 🟢 Estou 100% online e funcionando! 💪" };
  }
  if (/reiniciar|reinicia|ligar de novo/i.test(t)) {
    return { tipo: "resposta", texto: "Não consigo me reiniciar sozinho! 😅 Peça ao dono para reiniciar!" };
  }

  // ==========================================
  // ❓ NÃO ENTENDI
  // ==========================================
  return null;
}

// 🤖 PROCESSAR MENSAGEM
async function processarComandoIA(sock, idChat, remetente, texto, comandosDisponiveis = {}) {
  const cfg = carregarCfgIA();
  if (!cfg.iaAtiva) return false;

  const textoLower = texto.toLowerCase().trim();
  const nomeIA = cfg.nomeIA.toLowerCase();
  const foiChamado = textoLower.startsWith(nomeIA + " ") || 
                     textoLower.startsWith(nomeIA + ",") ||
                     textoLower.includes(nomeIA + " ") ||
                     textoLower.includes(nomeIA + ",");

  const resposta = processarTexto(texto);
  if (!resposta) return false;

  if (!foiChamado && !cfg.responderSemNome && resposta.tipo !== "resposta") {
    return false;
  }

  console.log(`🤖 [IA Local] "${texto}" → ${resposta.tipo}`);

  switch (resposta.tipo) {
    case "fechar_grupo":
      if (!idChat.includes("@g.us")) {
        await sock.sendMessage(idChat, { text: "⚠️ Só posso fazer isso em grupos!" });
        return true;
      }
      await sock.groupSettingUpdate(idChat, "announcement");
      await sock.sendMessage(idChat, { text: resposta.texto });
      break;

    case "abrir_grupo":
      if (!idChat.includes("@g.us")) {
        await sock.sendMessage(idChat, { text: "⚠️ Só posso fazer isso em grupos!" });
        return true;
      }
      await sock.groupSettingUpdate(idChat, "not_announcement");
      await sock.sendMessage(idChat, { text: resposta.texto });
      break;

    case "abrir_menu":
      await sock.sendMessage(idChat, { text: resposta.texto });
      if (comandosDisponiveis.menu?.executar) {
        await comandosDisponiveis.menu.executar(sock, { key: { remoteJid: idChat } }, [], { idChat, remetente });
      }
      break;

    case "mostrar_prefixo":
      await sock.sendMessage(idChat, { text: resposta.texto });
      break;

    case "comando":
      await sock.sendMessage(idChat, { text: resposta.texto });
      break;

    case "resposta":
    default:
      await sock.sendMessage(idChat, { text: resposta.texto });
      break;
  }

  return true;
}

// 📦 COMANDOS DE CONFIGURAÇÃO
module.exports = {
  carregarCfgIA,
  processarComandoIA,

  comandos: {
    modoia: {
      nome: "modoia",
      alternativos: ["ia", "ligaria", "desligaria"],
      executar: async (sock, msg, args, dados) => {
        if (!ehDono(dados.remetente)) return;
        const op = args[0];
        const cfg = carregarCfgIA();

        if (op === "1" || op === "on" || op === "ligar") {
          cfg.iaAtiva = true;
          salvarCfgIA(cfg);
          return sock.sendMessage(dados.idChat, {
            text: `✅ *IA ATIVADA!* 🤖\n+50 frases e TODOS os comandos integrados!\n• Sem API • Sem chave • Sem erro!`
          });
        }
        if (op === "0" || op === "off" || op === "desligar") {
          cfg.iaAtiva = false;
          salvarCfgIA(cfg);
          return sock.sendMessage(dados.idChat, { text: `❌ *IA desativada!* 🤖` });
        }
        return sock.sendMessage(dados.idChat, {
          text: `⚙️ *Configuração da IA* 🤖\n\nStatus: ${cfg.iaAtiva ? "✅ Ativada" : "❌ Desativada"}\nNome: "${cfg.nomeIA}"\nResponder sem nome: ${cfg.responderSemNome ? "✅ Sim" : "❌ Não"}\n\n${PREFIXO}modoia 1 → Ligar\n${PREFIXO}modoia 0 → Desligar`
        });
      }
    },

    nomeia: {
      nome: "nomeia",
      alternativos: ["nomedaia", "definirnomeia"],
      executar: async (sock, msg, args, dados) => {
        if (!ehDono(dados.remetente)) return;
        const novoNome = args.join(" ").trim();
        const cfg = carregarCfgIA();

        if (!novoNome) {
          return sock.sendMessage(dados.idChat, {
            text: `🤖 *Nome atual:* "${cfg.nomeIA}"\n\nMudar: ${PREFIXO}nomeia <nome>`
          });
        }

        cfg.nomeIA = novoNome;
        salvarCfgIA(cfg);
        return sock.sendMessage(dados.idChat, {
          text: `✅ *Nome da IA: "${novoNome}"* 🤖\nAgora fale: "${novoNome}, fecha o grupo"`
        });
      }
    },

    responder_sem_nome: {
      nome: "responder_sem_nome",
      executar: async (sock, msg, args, dados) => {
        if (!ehDono(dados.remetente)) return;
        const cfg = carregarCfgIA();
        cfg.responderSemNome = !cfg.responderSemNome;
        salvarCfgIA(cfg);
        return sock.sendMessage(dados.idChat, {
          text: `✅ *Responder sem nome:* ${cfg.responderSemNome ? "✅ ATIVADO" : "❌ DESATIVADO"}\n${cfg.responderSemNome ? "Respondo a bom dia/boa tarde mesmo sem me chamar!" : "Só respondo quando me chamam!"}`
        });
      }
    }
  }
};

