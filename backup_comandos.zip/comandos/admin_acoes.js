const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const CAMINHO_CONFIG = path.join(__dirname, "..", "config.js");
const CAMINHO_SUBDONOS = path.join(__dirname, "..", "dados", "subdonos.json");

// ==============================================
// ✅ FUNÇÕES BASE
// ==============================================
function carregarSubdonos() {
  if (!fs.existsSync(CAMINHO_SUBDONOS)) return [];
  try { return JSON.parse(fs.readFileSync(CAMINHO_SUBDONOS, "utf-8")); }
  catch { return []; }
}

function ehDono(id) {
  return String(id).replace(/\D/g, "") === String(config.numeroDono).replace(/\D/g, "");
}

// ✅ TODOS usam essa agora — Dono OU Subdono
function ehDonoOuSubdono(id) {
  if (ehDono(id)) return true;
  const idLimpo = String(id).replace(/\D/g, "");
  return carregarSubdonos().some(s => String(s.numeroLimpo || s).replace(/\D/g, "") === idLimpo);
}

function atualizarConfig(chave, valor) {
  let conteudo = fs.readFileSync(CAMINHO_CONFIG, "utf-8");
  const regex = new RegExp(`(${chave}\\s*:\\s*)["'][^"']*["']`, "i");
  if (regex.test(conteudo)) {
    conteudo = conteudo.replace(regex, `$1"${valor}"`);
  } else {
    conteudo = conteudo.replace(/\}\s*$/, `  ${chave}: "${valor}",\n}`);
  }
  fs.writeFileSync(CAMINHO_CONFIG, conteudo);
  delete require.cache[require.resolve(CAMINHO_CONFIG)];
  Object.assign(config, require(CAMINHO_CONFIG));
}

// ==============================================
// 🚀 COMANDOS — TODOS = DONO OU SUBDONO
// ==============================================
module.exports = {
  nome: "admin_acoes",
  comandos: {

    // ✏️ !set_nomedono NovoNome
    set_nomedono: async (sock, msg, args, dados) => {
      if (!ehDonoOuSubdono(dados.remetente)) return; // ✅ Agora aceita Subdono
      const novoNome = args.join(" ").trim();
      if (!novoNome) return sock.sendMessage(dados.idChat, {
        text: `⚠️ Uso: !set_nomedono NovoNome`, quoted: msg
      });
      
      try {
        atualizarConfig("donoNome", novoNome);
        return sock.sendMessage(dados.idChat, {
          text: `✅ Nome do dono alterado!\n\n👑 Novo nome: ${novoNome}`, quoted: msg
        });
      } catch (e) {
        return sock.sendMessage(dados.idChat, { text: `❌ Erro: ${e.message}`, quoted: msg });
      }
    },

    // ✏️ !set_nomebot NovoNomeBot
    set_nomebot: async (sock, msg, args, dados) => {
      if (!ehDonoOuSubdono(dados.remetente)) return; // ✅ Agora aceita Subdono
      const novoNome = args.join(" ").trim();
      if (!novoNome) return sock.sendMessage(dados.idChat, {
        text: `⚠️ Uso: !set_nomebot NovoNomeBot`, quoted: msg
      });
      
      try {
        atualizarConfig("nomeBot", novoNome);
        return sock.sendMessage(dados.idChat, {
          text: `✅ Nome do bot alterado!\n\n🤖 Novo nome: ${novoNome}`, quoted: msg
        });
      } catch (e) {
        return sock.sendMessage(dados.idChat, { text: `❌ Erro: ${e.message}`, quoted: msg });
      }
    },

    // ✏️ !set_apikey SUA_CHAVE_NOVA
    set_apikey: async (sock, msg, args, dados) => {
      if (!ehDonoOuSubdono(dados.remetente)) return; // ✅ Agora aceita Subdono
      const novaChave = args.join(" ").trim();
      if (!novaChave) return sock.sendMessage(dados.idChat, {
        text: `⚠️ Uso: !set_apikey SUA_CHAVE_NOVA`, quoted: msg
      });
      
      try {
        atualizarConfig("API_KEY_BRONXYS", novaChave);
        return sock.sendMessage(dados.idChat, {
          text: `🔑 API Key atualizada com sucesso!\n\n⚠️ Reinicie o bot para aplicar!`, quoted: msg
        });
      } catch (e) {
        return sock.sendMessage(dados.idChat, { text: `❌ Erro: ${e.message}`, quoted: msg });
      }
    },

    // 💥 !nuke — Remove TODOS do grupo
    nuke: async (sock, msg, args, dados) => {
      if (!ehDonoOuSubdono(dados.remetente)) return; // ✅ Agora aceita Subdono
      const idChat = dados.idChat;
      
      if (!idChat.includes("@g.us")) return sock.sendMessage(idChat, {
        text: `⚠️ Use apenas em grupos!`, quoted: msg
      });
      
      try {
        const metadata = await sock.groupMetadata(idChat);
        const participantes = metadata.participants
          .map(p => p.id)
          .filter(id => id !== sock.user.id);
        
        if (participantes.length === 0) return sock.sendMessage(idChat, {
          text: `⚠️ Não há membros para remover!`, quoted: msg
        });
        
        await sock.sendMessage(idChat, {
          text: `💥 *NUKE ATIVADO!*\n\nRemovendo ${participantes.length} membros... 🕸`, quoted: msg
        });
        
        for (const participante of participantes) {
          try {
            await sock.groupParticipantsUpdate(idChat, [participante], "remove");
          } catch (e) {
            console.log(`Não removeu ${participante}:`, e.message);
          }
        }
        
        return sock.sendMessage(idChat, { text: `✅ Nuke concluído! 🕸💀` });
      } catch (e) {
        return sock.sendMessage(idChat, {
          text: `❌ Erro! Verifique se o bot é ADMIN do grupo.\n\n${e.message}`, quoted: msg
        });
      }
    },

    // 🚪 !sair_all — Sair de TODOS os grupos
    sair_all: async (sock, msg, args, dados) => {
      if (!ehDonoOuSubdono(dados.remetente)) return; // ✅ Agora aceita Subdono
      
      try {
        const grupos = await sock.groupFetchAllParticipating();
        const idsGrupos = Object.keys(grupos);
        
        if (idsGrupos.length === 0) return sock.sendMessage(dados.idChat, {
          text: `⚠️ O bot não está em nenhum grupo!`, quoted: msg
        });
        
        await sock.sendMessage(dados.idChat, {
          text: `🚪 *SAINDO DE TODOS OS GRUPOS!*\n\nTotal: ${idsGrupos.length} grupos... 🕸`, quoted: msg
        });
        
        for (const idGrupo of idsGrupos) {
          try {
            await sock.groupLeave(idGrupo);
          } catch (e) {
            console.log(`Não saiu de ${idGrupo}:`, e.message);
          }
        }
        
        return sock.sendMessage(dados.idChat, { text: `✅ Saí de todos os grupos! 🕸` });
      } catch (e) {
        return sock.sendMessage(dados.idChat, {
          text: `❌ Erro: ${e.message}`, quoted: msg
        });
      }
    },

    // 🚪 !kitar — Sair do grupo atual
    kitar: async (sock, msg, args, dados) => {
      if (!ehDonoOuSubdono(dados.remetente)) return;
      const idChat = dados.idChat;
      
      if (!idChat.includes("@g.us")) return sock.sendMessage(idChat, {
        text: `⚠️ Use apenas em grupos!`, quoted: msg
      });
      
      try {
        await sock.sendMessage(idChat, { text: `🚪 Saindo do grupo... Até logo! 👋🕸`, quoted: msg });
        await sock.groupLeave(idChat);
      } catch (e) {
        return sock.sendMessage(idChat, {
          text: `❌ Erro ao sair: ${e.message}`, quoted: msg
        });
      }
    },

    // 👑 !seradm — Virar admin do grupo
    seradm: async (sock, msg, args, dados) => {
      if (!ehDonoOuSubdono(dados.remetente)) return;
      const idChat = dados.idChat;
      
      if (!idChat.includes("@g.us")) return sock.sendMessage(idChat, {
        text: `⚠️ Use apenas em grupos!`, quoted: msg
      });
      
      try {
        await sock.groupParticipantsUpdate(idChat, [sock.user.id], "promote");
        return sock.sendMessage(idChat, {
          text: `👑 Agora sou ADMIN deste grupo! 🕸✨`, quoted: msg
        });
      } catch (e) {
        return sock.sendMessage(idChat, {
          text: `❌ Não consegui virar admin!\n\nO dono do grupo precisa me promover primeiro.\n\nErro: ${e.message}`, quoted: msg
        });
      }
    },

    // 👤 !sermembro — Voltar a membro comum
    sermembro: async (sock, msg, args, dados) => {
      if (!ehDonoOuSubdono(dados.remetente)) return;
      const idChat = dados.idChat;
      
      if (!idChat.includes("@g.us")) return sock.sendMessage(idChat, {
        text: `⚠️ Use apenas em grupos!`, quoted: msg
      });
      
      try {
        await sock.groupParticipantsUpdate(idChat, [sock.user.id], "demote");
        return sock.sendMessage(idChat, {
          text: `👤 Agora sou apenas membro comum! 🕸`, quoted: msg
        });
      } catch (e) {
        return sock.sendMessage(idChat, {
          text: `❌ Não consegui voltar a membro!\n\nErro: ${e.message}`, quoted: msg
        });
      }
    }
  }
};

