const config = require("../config.js");
const fs = require("fs");
const path = require("path");

const PREFIXO = config.prefixo || "!";
const CAMINHO_RPG = path.join(__dirname, "..", "dados", "rpg_dados.json");

if (!fs.existsSync(path.dirname(CAMINHO_RPG))) {
  fs.mkdirSync(path.dirname(CAMINHO_RPG), { recursive: true });
}
if (!fs.existsSync(CAMINHO_RPG)) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify({}));
}

function salvarDados(dados) {
  fs.writeFileSync(CAMINHO_RPG, JSON.stringify(dados, null, 2));
}

module.exports = {
  comandos: {
    inventario: async (sock, msg, args) => {
      const idChat = msg.key.remoteJid;
      const remetente = msg.key.participant || msg.key.remoteJid;

      const dados = JSON.parse(fs.readFileSync(CAMINHO_RPG, "utf-8"));
      const usuario = dados[remetente] || {};

      if (!usuario.inventario || usuario.inventario.length === 0) {
        return sock.sendMessage(idChat, {
          text: `📦 *Your browser does not support inventário vazio!*\n\n` +
                `Compre itens na ${PREFIXO}loja primeiro! 🛒`
        }, { quoted: msg });
      }

      let texto = `📦 *SEU INVENTÁRIO* 📦\n\n`;
      usuario.inventario.forEach((item, index) => {
        texto += `${index + 1}. ${item.nome}\n`;
        texto += `   ℹ️ ${item.descricao}\n\n`
      });

      return sock.sendMessage(idChat, {
        text: texto,
        mentions: [remetente]
      }, { quoted: msg });
    }
  }
};

